import base64
import datetime
import io
import unittest
from unittest.mock import patch

try:
    from openpyxl import load_workbook
except ImportError:
    load_workbook = None

from odoo import Command, fields
from odoo.addons.account.tests.common import AccountTestInvoicingCommon
from odoo.tests.common import tagged


@tagged('post_install', '-at_install')
@unittest.skipUnless(load_workbook, 'openpyxl is required for XLSX assertions')
class TestAuditExcelExport(AccountTestInvoicingCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.export_date_from = fields.Date.from_string('2025-01-01')
        cls.export_date_to = fields.Date.from_string('2025-12-31')
        cls.aged_as_of_date = fields.Date.from_string('2025-12-31')

        cls.customer_partner = cls.partner_a
        cls.vendor_partner = cls.partner_b

        cls.customer_invoice_posted = cls.init_invoice(
            'out_invoice',
            partner=cls.customer_partner,
            invoice_date=fields.Date.from_string('2025-01-10'),
            post=True,
            amounts=[100.0],
        )
        cls.vendor_bill_posted = cls.init_invoice(
            'in_invoice',
            partner=cls.vendor_partner,
            invoice_date=fields.Date.from_string('2025-01-14'),
            post=True,
            amounts=[80.0],
        )

    def _create_wizard(self, **overrides):
        vals = {
            'company_ids': [Command.set(self.env.company.ids)],
            'date_from': self.export_date_from,
            'date_to': self.export_date_to,
            'aged_as_of_date': self.aged_as_of_date,
            'export_sheet_key': 'all',
            'include_draft_entries': True,
            'unfold_all': True,
            'hide_zero_lines': False,
            'aging_based_on': 'base_on_maturity_date',
            'aging_interval': 30,
            'show_currency': True,
            'show_account': True,
            'include_dynamic_columns': True,
            'invoice_bill_scope': 'all_states',
            'include_refunds': True,
            'partner_ids': [Command.set([self.customer_partner.id, self.vendor_partner.id])],
        }
        vals.update(overrides)
        return self.env['audit.excel.export.wizard'].create(vals)

    def _export_workbook(self, wizard):
        action = wizard.action_export_xlsx()
        self.assertEqual(action.get('type'), 'ir.actions.act_url')
        self.assertTrue(wizard.file_data)
        binary = base64.b64decode(wizard.file_data)
        self.assertGreater(len(binary), 0)
        wb = load_workbook(io.BytesIO(binary), data_only=False)
        return action, wb

    def _sheet_values(self, ws):
        values = []
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is not None:
                    values.append(str(cell.value))
        return values

    def _find_header_position(self, ws, header_name, *, max_scan_rows=80):
        for row_idx in range(1, min(ws.max_row, max_scan_rows) + 1):
            for col_idx in range(1, ws.max_column + 1):
                if ws.cell(row=row_idx, column=col_idx).value == header_name:
                    return row_idx, col_idx
        return None, None

    def _normalize_label(self, value):
        return ''.join(ch for ch in str(value or '').strip().lower() if ch.isalnum())

    def _find_row_by_label(self, ws, label, *, start_row=1, occurrence=1):
        expected = self._normalize_label(label)
        seen = 0
        for row_idx in range(start_row, ws.max_row + 1):
            if self._normalize_label(ws.cell(row=row_idx, column=1).value) != expected:
                continue
            seen += 1
            if seen == occurrence:
                return row_idx
        return None

    def _find_row_by_keys(self, ws, keys, *, start_row=1):
        normalized = {self._normalize_label(key) for key in keys}
        for row_idx in range(start_row, ws.max_row + 1):
            if self._normalize_label(ws.cell(row=row_idx, column=1).value) in normalized:
                return row_idx
        return None

    def _coerce_openpyxl_date(self, value):
        if isinstance(value, datetime.datetime):
            return value.date()
        return value

    def _static_numeric_like_values(self, ws):
        values = []
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 250), min_col=1, max_col=min(ws.max_column, 8)):
            for cell in row:
                value = cell.value
                if value is None:
                    continue
                if isinstance(value, str) and value.startswith('='):
                    continue
                if isinstance(value, (int, float, bool, datetime.date, datetime.datetime)):
                    values.append((cell.coordinate, value))
        return values

    def test_01_export_download_and_sheet_order(self):
        wizard = self._create_wizard()
        action, wb = self._export_workbook(wizard)

        self.assertIn('download=true', action.get('url', ''))
        self.assertTrue(wizard.file_name.endswith('.xlsx'))
        self.assertEqual(
            wb.sheetnames,
            [
                'General Ledger',
                'Customer Invoices',
                'Vendor Bills',
                'Aged Receivables',
                'Aged Payables',
                'VAT Control',
                'Prepayment',
                'Client Details',
                'Summary Sheet',
                'SOFP',
                'SOCI',
                'SOCE',
                'SOCF',
                'Share Capital',
                'Accruals',
                'Trial Balance',
            ],
        )

    def test_02_template_formulas_and_formatting_survive(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        self.assertTrue(str(wb['Summary Sheet']['A1'].value).startswith('='))
        self.assertTrue(str(wb['Summary Sheet']['B7'].value).startswith('='))
        self.assertTrue(str(wb['SOFP']['A1'].value).startswith('='))
        self.assertTrue(str(wb['VAT Control']['B18'].value).startswith('='))

        sofp = wb['SOFP']
        self.assertIn('A2:E2', {str(rng) for rng in sofp.merged_cells.ranges})
        self.assertTrue(sofp['A2'].font.bold)
        self.assertEqual(sofp.page_setup.orientation, 'landscape')
        self.assertEqual(sofp.column_dimensions['B'].width, 18.0)
        self.assertEqual(sofp.row_dimensions[2].height, 28.0)

    def test_03_first_five_sheets_have_data(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        gl_values = self._sheet_values(wb['General Ledger'])
        self.assertIn('Code', gl_values)
        self.assertIn('Account Name', gl_values)
        self.assertIn('Debit', gl_values)
        self.assertIn('Credit', gl_values)
        self.assertIn('Balance', gl_values)
        self.assertGreater(len(gl_values), 20)

        customer_ws = wb['Customer Invoices']
        customer_values = self._sheet_values(customer_ws)
        expected_summary_headers = [
            'Invoice No',
            'Invoice Date',
            'Accounting Date',
            'Currency',
            'Customer',
            'Due Date',
            'Conversion Rate',
        ]
        expected_line_headers = [
            'Label',
            'Account',
            'Quantity',
            'Price',
            'Taxes',
            'VAT Amount',
            'Amount',
            'Currency',
        ]
        for header in expected_summary_headers:
            self.assertIn(header, customer_values)
        for header in expected_line_headers:
            self.assertIn(header, customer_values)
        self.assertGreater(len(customer_values), 20)
        self.assertIn(self.customer_invoice_posted.name, customer_values)

        vendor_ws = wb['Vendor Bills']
        vendor_values = self._sheet_values(vendor_ws)
        for header in ('Invoice No', 'Invoice Date', 'Accounting Date', 'Currency', 'Vendor', 'Due Date', 'Conversion Rate'):
            self.assertIn(header, vendor_values)
        for header in expected_line_headers:
            self.assertIn(header, vendor_values)
        self.assertGreater(len(vendor_values), 20)
        self.assertIn(self.vendor_bill_posted.name, vendor_values)

        for sheet_name, ws in (('Customer Invoices', customer_ws), ('Vendor Bills', vendor_ws)):
            header_row, line_description_col = self._find_header_position(ws, 'Label')
            self.assertIsNotNone(header_row)
            has_line_rows = any(
                ws.cell(row=row_idx, column=line_description_col).value not in (None, '')
                for row_idx in range(header_row + 1, min(ws.max_row, header_row + 250) + 1)
            )
            self.assertTrue(has_line_rows, f'Expected invoice/bill line rows in {sheet_name}')

            for numeric_header in ('Quantity', 'Price', 'VAT Amount', 'Amount'):
                _hdr_row, numeric_col = self._find_header_position(ws, numeric_header)
                self.assertIsNotNone(numeric_col)
                has_numeric_value = any(
                    isinstance(ws.cell(row=row_idx, column=numeric_col).value, (int, float))
                    for row_idx in range(header_row + 1, min(ws.max_row, header_row + 250) + 1)
                )
                self.assertTrue(has_numeric_value, f'Expected numeric values under {numeric_header} in {sheet_name}')

            _hdr_row, conversion_col = self._find_header_position(ws, 'Conversion Rate')
            self.assertIsNotNone(conversion_col)
            has_conversion_value = any(
                isinstance(ws.cell(row=row_idx, column=conversion_col).value, (int, float))
                for row_idx in range(_hdr_row + 1, min(ws.max_row, _hdr_row + 250) + 1)
            )
            self.assertTrue(has_conversion_value, f'Expected conversion rate values in {sheet_name}')

        for sheet_name in ('Aged Receivables', 'Aged Payables'):
            ws = wb[sheet_name]
            values = self._sheet_values(ws)
            self.assertGreater(ws.max_row, 5)
            self.assertGreater(ws.max_column, 5)
            self.assertGreater(len(values), 20)

    def test_04_trial_balance_is_populated(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        ws = wb['Trial Balance']
        values = self._sheet_values(ws)
        self.assertIn('Code', values)
        self.assertIn('Account Name', values)
        self.assertIn('Debit', values)
        self.assertIn('Credit', values)
        self.assertIn('Balance', values)

        has_numeric_tb_rows = any(
            isinstance(cell.value, (int, float)) and abs(cell.value) > 0
            for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 300), min_col=1, max_col=min(ws.max_column, 12))
            for cell in row
        )
        self.assertTrue(has_numeric_tb_rows)

    def test_05_client_details_are_populated(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        ws = wb['Client Details']
        self.assertEqual(ws['B4'].value, self.env.company.name)
        self.assertEqual(self._coerce_openpyxl_date(ws['B5'].value), self.export_date_from)
        self.assertEqual(self._coerce_openpyxl_date(ws['B6'].value), self.export_date_to)

    def test_06_share_capital_rows_are_populated_when_company_data_exists(self):
        self.env.company.write({
            'shareholder_1': 'Owner A',
            'number_of_shares_1': 100,
            'share_value_1': 10.0,
        })

        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        ws = wb['Share Capital']
        self.assertEqual(ws['A7'].value, 'Owner A')
        self.assertEqual(ws['B7'].value, 100)
        self.assertEqual(ws['C7'].value, 10.0)

    def test_07_non_tb_template_sheets_have_no_static_numeric_samples(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        non_tb_template_sheets = [
            'VAT Control',
            'Prepayment',
            'Summary Sheet',
            'SOFP',
            'SOCI',
            'SOCE',
            'SOCF',
            'Accruals',
        ]

        for sheet_name in non_tb_template_sheets:
            ws = wb[sheet_name]
            static_values = self._static_numeric_like_values(ws)
            self.assertFalse(static_values, f'Static sample numeric values found on {sheet_name}: {static_values[:5]}')

    def test_08_trial_balance_forces_flat_unfolded_options(self):
        wizard = self._create_wizard(unfold_all=False)

        with patch.object(type(wizard), '_build_native_report_sheet_payload', autospec=True, return_value={}) as mocked_builder:
            wizard._prepare_trial_balance_payload()

        options = mocked_builder.call_args.kwargs['options']
        self.assertFalse(options.get('hierarchy'))
        self.assertTrue(options.get('unfold_all'))
        self.assertEqual(options.get('unfolded_lines'), [])

    def test_09_customer_invoice_report_options_are_forwarded(self):
        wizard = self._create_wizard(invoice_bill_scope='posted_only', include_refunds=False)

        with patch.object(type(wizard), '_get_invoice_bill_moves', autospec=True, return_value=self.env['account.move']) as mocked_get_moves:
            wizard._prepare_invoice_bill_payload(is_customer=True)

        options = mocked_get_moves.call_args.kwargs['options']
        self.assertEqual(options.get('invoice_bill_report_kind'), 'customer')
        self.assertEqual(options.get('invoice_bill_scope'), 'posted_only')
        self.assertFalse(options.get('include_refunds'))

    def test_10_statement_lines_link_to_trial_balance_and_totals_remain_sheet_driven(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        sofp = wb['SOFP']
        prepayment_row = self._find_row_by_label(sofp, 'Prepayment')
        advances_row = self._find_row_by_label(sofp, 'Advances')
        prepaid_expenses_row = self._find_row_by_label(sofp, 'Prepaid expenses')
        other_receivables_row = self._find_row_by_label(sofp, 'Other receivables')
        current_liabilities_row = self._find_row_by_label(sofp, 'Current liabilities')
        other_payables_row = self._find_row_by_label(sofp, 'Other payables')
        total_current_assets_row = self._find_row_by_label(sofp, 'Total current assets')
        total_liabilities_row = self._find_row_by_label(sofp, 'Total Liabilities')
        total_equity_liabilities_row = self._find_row_by_label(sofp, 'Total Equity and Liabilities')

        self.assertIsNotNone(prepayment_row)
        self.assertIsNotNone(advances_row)
        self.assertIsNotNone(prepaid_expenses_row)
        self.assertIsNotNone(other_receivables_row)
        self.assertIsNotNone(current_liabilities_row)
        self.assertIsNotNone(other_payables_row)
        self.assertIsNone(sofp[f'B{prepayment_row}'].value)
        self.assertIsNone(sofp[f'B{current_liabilities_row}'].value)
        self.assertTrue(str(sofp[f'B{advances_row}'].value).startswith("='Trial Balance'!"))
        self.assertTrue(str(sofp[f'B{prepaid_expenses_row}'].value).startswith("='Trial Balance'!"))
        self.assertTrue(str(sofp[f'B{other_receivables_row}'].value).startswith("='Trial Balance'!"))
        self.assertTrue(str(sofp[f'B{other_payables_row}'].value).startswith("='Trial Balance'!"))
        self.assertTrue(str(sofp[f'B{total_current_assets_row}'].value).startswith('=SUM('))
        self.assertTrue(str(sofp[f'B{total_liabilities_row}'].value).startswith('=SUM('))
        self.assertIn('+', str(sofp[f'B{total_equity_liabilities_row}'].value))

        soci = wb['SOCI']
        operating_heading_row = self._find_row_by_label(soci, 'Operating expenses')
        office_salary_row = self._find_row_by_label(soci, 'Office Staff Salaries')
        audit_heading_row = self._find_row_by_label(soci, 'Audit and accounting')
        total_operating_row = self._find_row_by_label(soci, 'Total operating expenses')
        net_profit_row = self._find_row_by_keys(soci, ['Net profit / (loss)', 'Net profit'])

        self.assertIsNotNone(operating_heading_row)
        self.assertIsNotNone(office_salary_row)
        self.assertIsNotNone(audit_heading_row)
        self.assertIsNotNone(total_operating_row)
        self.assertIsNotNone(net_profit_row)
        self.assertIsNone(soci[f'B{operating_heading_row}'].value)
        self.assertIsNone(soci[f'B{audit_heading_row}'].value)
        self.assertTrue(str(soci[f'B{office_salary_row}'].value).startswith("='Trial Balance'!"))
        self.assertTrue(str(soci[f'B{total_operating_row}'].value).startswith('=SUM('))
        self.assertIn('-', str(soci[f'B{net_profit_row}'].value))
        self.assertIn('+', str(soci[f'B{net_profit_row}'].value))

        soce = wb['SOCE']
        self.assertTrue(str(soce['B14'].value).startswith("='Trial Balance'!"))
        self.assertTrue(str(soce['D12'].value).startswith("='Trial Balance'!"))
        self.assertTrue(str(soce['D18'].value).startswith("='Trial Balance'!"))
        self.assertEqual(soce['F13'].value, '=SUM(F7:F12)')
        self.assertEqual(soce['F19'].value, '=SUM(F13:F18)')

        socf = wb['SOCF']
        self.assertTrue(str(socf['B12'].value).startswith("='Trial Balance'!"))
        self.assertTrue(str(socf['B20'].value).startswith("='Trial Balance'!"))
        self.assertEqual(socf['B14'].value, '=SUM(B10:B13)')
        self.assertEqual(socf['B22'].value, '=SUM(B18:B21)')

    def test_11_last_saved_settings_are_loaded(self):
        default_key_wizard = self._create_wizard()
        settings_key = default_key_wizard._previous_settings_key()
        self.env['ir.config_parameter'].sudo().set_param(settings_key, '')

        custom_wizard = self._create_wizard(
            date_from=fields.Date.from_string('2025-02-01'),
            date_to=fields.Date.from_string('2025-02-28'),
            aged_as_of_date=fields.Date.from_string('2025-02-28'),
            export_sheet_key='general_ledger',
            balance_sheet_date_mode='range',
            prior_year_mode='manual',
            prior_balance_sheet_date_mode='range',
            prior_date_start=fields.Date.from_string('2024-02-01'),
            prior_date_end=fields.Date.from_string('2024-02-29'),
            include_draft_entries=False,
            unfold_all=False,
            hide_zero_lines=True,
            aging_based_on='base_on_invoice_date',
            aging_interval=45,
            show_currency=False,
            show_account=False,
            include_dynamic_columns=False,
            invoice_bill_scope='posted_only',
            include_refunds=False,
            journal_ids=[Command.set(self.company_data['default_journal_sale'].ids)],
            partner_ids=[Command.set([self.customer_partner.id])],
            gl_options_json='{"unfold_all": false}',
            aged_receivable_options_json='{"show_currency": false}',
            aged_payable_options_json='{"show_currency": false}',
        )
        custom_wizard._store_previous_settings()

        field_names = [
            'use_previous_settings',
            'date_from',
            'date_to',
            'aged_as_of_date',
            'export_sheet_key',
            'balance_sheet_date_mode',
            'prior_year_mode',
            'prior_balance_sheet_date_mode',
            'prior_date_start',
            'prior_date_end',
            'include_draft_entries',
            'unfold_all',
            'hide_zero_lines',
            'aging_based_on',
            'aging_interval',
            'show_currency',
            'show_account',
            'include_dynamic_columns',
            'invoice_bill_scope',
            'include_refunds',
            'journal_ids',
            'partner_ids',
            'gl_options_json',
            'aged_receivable_options_json',
            'aged_payable_options_json',
        ]
        defaults = self.env['audit.excel.export.wizard'].default_get(field_names)

        self.assertEqual(defaults.get('date_from'), fields.Date.from_string('2025-02-01'))
        self.assertEqual(defaults.get('date_to'), fields.Date.from_string('2025-02-28'))
        self.assertEqual(defaults.get('aged_as_of_date'), fields.Date.from_string('2025-02-28'))
        self.assertEqual(defaults.get('export_sheet_key'), 'general_ledger')
        self.assertEqual(defaults.get('balance_sheet_date_mode'), 'range')
        self.assertEqual(defaults.get('prior_year_mode'), 'manual')
        self.assertEqual(defaults.get('prior_balance_sheet_date_mode'), 'range')
        self.assertEqual(defaults.get('prior_date_start'), fields.Date.from_string('2024-02-01'))
        self.assertEqual(defaults.get('prior_date_end'), fields.Date.from_string('2024-02-29'))
        self.assertFalse(defaults.get('include_draft_entries'))
        self.assertFalse(defaults.get('unfold_all'))
        self.assertTrue(defaults.get('hide_zero_lines'))
        self.assertEqual(defaults.get('aging_based_on'), 'base_on_invoice_date')
        self.assertEqual(defaults.get('aging_interval'), 45)
        self.assertFalse(defaults.get('show_currency'))
        self.assertFalse(defaults.get('show_account'))
        self.assertFalse(defaults.get('include_dynamic_columns'))
        self.assertEqual(defaults.get('invoice_bill_scope'), 'posted_only')
        self.assertFalse(defaults.get('include_refunds'))
        self.assertEqual(
            defaults.get('journal_ids'),
            [(6, 0, self.company_data['default_journal_sale'].ids)],
        )
        self.assertEqual(
            defaults.get('partner_ids'),
            [(6, 0, [self.customer_partner.id])],
        )
        self.assertEqual(defaults.get('gl_options_json'), '{"unfold_all": false}')
        self.assertEqual(defaults.get('aged_receivable_options_json'), '{"show_currency": false}')
        self.assertEqual(defaults.get('aged_payable_options_json'), '{"show_currency": false}')

    def test_12_can_export_only_general_ledger_sheet(self):
        wizard = self._create_wizard(export_sheet_key='general_ledger')
        _action, wb = self._export_workbook(wizard)

        self.assertEqual(wb.sheetnames, ['General Ledger'])
        values = self._sheet_values(wb['General Ledger'])
        self.assertIn('Code', values)
        self.assertIn('Account Name', values)
        self.assertIn('Debit', values)
        self.assertIn('Credit', values)
        self.assertIn('Balance', values)
        self.assertIn('general_ledger', wizard.file_name)

    def test_13_can_export_only_template_sheet(self):
        wizard = self._create_wizard(export_sheet_key='summary_sheet')
        _action, wb = self._export_workbook(wizard)

        self.assertEqual(wb.sheetnames, ['Summary Sheet'])
        self.assertTrue(str(wb['Summary Sheet']['A1'].value).startswith('='))

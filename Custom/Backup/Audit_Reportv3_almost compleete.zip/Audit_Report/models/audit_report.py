from dateutil.relativedelta import relativedelta
from odoo import models, fields


class AuditReport(models.TransientModel):
    _name = 'audit.report'
    _description = 'Audit Report'

    date_start = fields.Date(string='Date Start', required=True)
    date_end = fields.Date(string='Date End', required=True)
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company,
    )

    def _get_report_data(self):
        """Get report data for the template"""
        prior_date_start = fields.Date.to_date(self.date_start) - relativedelta(years=1)
        prior_date_end = fields.Date.to_date(self.date_end) - relativedelta(years=1)


        def _fetch_account_rows(date_start, date_end):
            def _normalize_code(code):
                return ''.join(ch for ch in code if ch.isdigit())

            domain = [
                ('date', '>=', date_start),
                ('date', '<=', date_end),
                ('company_id', '=', self.company_id.id),
                ('move_id.state', '=', 'posted'),
            ]
            move_line_env = self.env['account.move.line'].with_context(
                allowed_company_ids=[self.company_id.id]
            )
            rows = move_line_env.read_group(
                domain=domain,
                fields=['debit', 'credit', 'balance'],
                groupby=['account_id']
            )

            account_ids = [row['account_id'][0] for row in rows if row.get('account_id')]
            account_env = self.env['account.account'].with_company(self.company_id).with_context(
                allowed_company_ids=[self.company_id.id]
            )
            account_map = {acc.id: acc for acc in account_env.browse(account_ids)}


            final_rows = []
            for row in rows:
                if not row.get('account_id'):
                    continue
                account_id = row['account_id'][0]
                account = account_map.get(account_id)
                if not account:
                    continue
                code_raw = (account.code or account.code_store or '').strip()
                if not code_raw:
                    continue
                code = _normalize_code(code_raw)
                if not code:
                    continue
                final_rows.append({
                    'id': account_id,
                    'code': code,
                    'code_raw': code_raw,
                    'name': account.name,
                    'type': account.account_type,
                    'debit': row['debit'],
                    'credit': row['credit'],
                    'balance': row['balance'],
                })
          
            return final_rows


        def _sum_by_prefix(rows, length):
            totals = {}
            for row in rows:
                code = row.get('code') or ''
                if len(code) < length:
                    continue
                key = code[:length]
                totals[key] = totals.get(key, 0.0) + row.get('balance', 0.0)
            return totals

        def _build_section_totals(group_totals, mapping):
            totals = {}
            for label, codes in mapping.items():
                total = 0.0
                for code in codes:
                    total += group_totals.get(code, 0.0)
                totals[label] = total
            return totals

        def _build_group_label_map(mappings):
            labels = {}
            for mapping in mappings:
                for label, codes in mapping.items():
                    for code in codes:
                        labels[code] = label
            return labels

        def _annotate_rows(rows, group_labels):
            annotated = []
            for row in rows:
                code = row.get('code', '')
                group_code = code[:4] if len(code) >= 4 else ''
                data = dict(row)
                data['group_code'] = group_code
                data['sub_group_code'] = code[:6] if len(code) >= 6 else ''
                data['two_digit_code'] = code[:2] if len(code) >= 2 else ''
                data['one_digit_code'] = code[:1] if len(code) >= 1 else ''
                data['section'] = group_labels.get(group_code, 'Other')
                annotated.append(data)
            return annotated

        def _build_subhead_groups(prefix_totals, subhead_labels):
            grouped = {}
            for code in sorted(prefix_totals):
                name = subhead_labels.get(code)
                if not name:
                    continue
                group_code = code[:4]
                grouped.setdefault(group_code, []).append({
                    'code': code,
                    'name': name,
                    'balance': prefix_totals[code],
                })
            return grouped

        def _label_group_totals(group_totals, labels):
            totals = {}
            for code, label in labels.items():
                totals[label] = totals.get(label, 0.0) + group_totals.get(code, 0.0)
            return totals

        NON_CURRENT_ASSET_GROUPS = {
            'Property and equipment': ['1101'],
            'Right of use of assets': ['1102'],
            'Capital work in progress': ['1103'],
            'Long term investment': ['1104', '1108'],
            'Long term deposits': ['1105'],
            'Long term loans receivable': ['1106'],
            'Intangible assets': ['1107'],
            'Deferred tax': ['1109'],
        }
        CURRENT_ASSET_GROUPS = {
            'Inventory': ['1201'],
            'Accounts receivable': ['1202'],
            'Prepayment, deposits, advances and other receivables': ['1203'],
            'Cash and bank balances': ['1204'],
            'Stripe and other wallets': ['1205'],
            'Interbank transfer': ['1206'],
        }
        NON_CURRENT_LIABILITY_GROUPS = {
            'Long term loan': ['2101'],
            'Long term loans payable - related parties': ['2102'],
            'Deferred tax': ['2103'],
            'Employee benefits': ['2104'],
        }
        CURRENT_LIABILITY_GROUPS = {
            'Short term borrowings': ['2201'],
            'Trade payables': ['2202'],
            'Other payables': ['2203'],
            'Corporate tax liability': ['2204'],
        }
        EQUITY_GROUPS = {
            'Equity': ['3101'],
        }
        REVENUE_GROUPS = {
            'Revenue': ['4101', '4102'],
        }
        OTHER_INCOME_GROUPS = {
            'Other income': ['4103'],
        }
        COST_OF_REVENUE_GROUPS = {
            'Cost of revenue': ['5101'],
        }
        DEPRECIATION_GROUPS = {
            'Depreciation': ['5114'],
        }

        MAIN_HEAD_LABELS = {
            '1101': 'Property Plant And Equipment',
            '1102': 'Right of Use of Assets',
            '1103': 'Capital Work in Progress',
            '1104': 'Long Term Investment',
            '1105': 'Long Term Deposits',
            '1106': 'Long Term Loans Receivable',
            '1107': 'Intangible Assets',
            '1108': 'Long Term Investment',
            '1109': 'Deferred Tax',
            '1201': 'Inventory',
            '1202': 'Trade Receivables',
            '1203': 'Prepayments, Deposits, Advances & Other Receivables',
            '1204': 'Cash And Bank Balances',
            '1205': 'Stripe & Other Wallets',
            '1206': 'Interbank Transfer',
            '2101': 'Long term loan',
            '2102': 'Long Term Loans Payable - Related Parties',
            '2103': 'Deferred Tax',
            '2104': 'Employee Benefits',
            '2201': 'Short Term Borrowings',
            '2202': 'Trade Payables',
            '2203': 'Other Payables',
            '2204': 'Corporate Tax Liability',
            '3101': 'Equity',
            '4101': 'Revenue',
            '4102': 'Revenue - Related Party',
            '4103': 'Other Income',
            '5101': 'Direct Cost',
            '5102': 'Marketing & Advertisement Expenses',
            '5103': 'IT Expenses',
            '5104': 'Telephone & Internet',
            '5105': 'Professional Fee & Consultancy',
            '5106': 'Legal & Government Fee',
            '5107': "Director's Salary",
            '5108': 'Salaries & Wages',
            '5109': 'Audit & Accounting Expense',
            '5110': 'Rent Expense',
            '5111': 'Utilities',
            '5112': 'Printing & Stationary Expense',
            '5113': 'Travel & Accommodation Expense',
            '5114': 'Depreciation & Amortization',
            '5115': 'Courier Expenses',
            '5116': 'Commission Expense',
            '5117': 'Cleaning Expense',
            '5118': 'Repair & Maintenance',
            '5119': 'Other expenses',
            '5120': 'Penalties & Fines',
            '5121': 'Donation & Charity',
            '5122': 'Other expenses',
            '5123': 'Bank Charges',
            '5124': 'Finance Cost',
            '5125': 'Insurance Expense',
            '5126': 'Fees & Subscriptions',
            '5127': 'Tax expense',
            '5128': 'Office Expense',
        }

        SUBHEAD_LABELS = {
            '110101': 'Land & Buildings',
            '110102': 'Furnitures & Fixtures',
            '110103': 'Leasehold Improvements',
            '110104': 'Vehicles',
            '110105': 'IT Equipments',
            '110106': 'Office Equipments',
            '110201': 'ROU Property',
            '110202': 'ROU Vehicles',
            '110203': 'ROU Equipment',
            '110204': 'ROU Property',
            '110205': 'ROU Vehicles',
            '110206': 'ROU Equipment',
            '110301': 'Capital Work in Progress',
            '110401': 'Investments in funds',
            '110501': 'Long Term Deposits',
            '110601': 'Related Parties',
            '110701': 'Software & Licences',
            '110702': 'Website & Blogs',
            '110703': 'Other Intangible Assets',
            '110801': 'Group Investments',
            '110901': 'Deferred Tax',
            '120101': 'Inventory',
            '120201': 'Trade Receivables',
            '120202': 'Retention Receivables',
            '120301': 'Advances',
            '120302': 'Prepaid Expenses',
            '120303': 'Other Receivables',
            '120304': 'VAT Receivable',
            '120401': 'Cash',
            '120402': 'Bank Accounts',
            '120501': 'Payment Gateways',
            '120502': 'Other Wallet',
            '120601': 'Interbank Transfer',
            '210101': 'Bank Loans',
            '210102': 'Related Party Loan',
            '210103': 'Lease Liabilities',
            '210201': 'Long Term Loans Payable - Related Parties',
            '210301': 'Deferred Tax',
            '210401': 'End of Service Benefits',
            '220101': 'Bank Overdraft',
            '220102': 'Short term loan',
            '220103': 'Credit Card Payable',
            '220104': 'Lease Liability',
            '220201': 'Trade Payables',
            '220301': 'Other Payables',
            '220302': 'VAT Payable',
            '220303': 'Accrued Expenses',
            '220401': 'Corporate Tax Liability',
            '310101': 'Share Capital',
            '310102': 'Retained Earnings',
            '310103': 'Reserves',
            '310104': 'Fund Balances',
            '410101': 'Revenue',
            '410201': 'Revenue - Related Party',
            '410301': 'Interest income',
            '410302': 'Dividend income',
            '410303': 'Rental Income',
            '410304': 'Miscellaneous Income',
            '410305': 'Foreign Exchange Gain',
            '410306': 'Fair Value Gains',
            '410307': 'Endowment Income',
            '410308': 'Donations',
            '410309': 'Grants',
            '410310': 'Write Back',
            '510101': 'Cost of Sales',
            '510102': 'Cost of Goods',
            '510103': 'Cost of Sales',
            '510104': 'Event Fee',
            '510201': 'Marketing & Advertisement Expenses',
            '510301': 'IT & Software Expenses',
            '510401': 'Telephone & Internet',
            '510501': 'Professional Fee & Consultancy',
            '510601': 'Legal & Government Fee',
            '510701': "Director's Salary",
            '510801': 'Office Staff Salaries',
            '510802': 'Coaching Staff Salaries',
            '510803': 'Employee Benefits & Allowances',
            '510804': 'Bonus & Incentives',
            '510805': 'Staff Welfare',
            '510901': 'Audit Fee',
            '510902': 'Accounting & Bookkeeping Fee',
            '511001': 'Office Rent',
            '511002': 'Miscellaneous Rent',
            '511101': 'Office Utilities',
            '511201': 'Printing Cost',
            '511202': 'Stationary',
            '511301': 'Travel & Accommodation Expense',
            '511302': 'Local Accommodation Expense',
            '511401': 'Depreciation Expense',
            '511402': 'Amortization Expense',
            '511501': 'Courier Expenses',
            '511601': 'Commission Expense',
            '511701': 'Cleaning Expense',
            '511801': 'Repair & Maintenance',
            '511901': 'Other Expenses',
            '512001': 'Penalties & Fines',
            '512101': 'Donation & Charity',
            '512201': 'Other Expenses',
            '512202': 'Charitable Activities',
            '512301': 'Bank Charges & Fees',
            '512401': 'Interest Expense',
            '512501': 'Business Insurance',
            '512601': 'Trade License',
            '512602': 'Establishment Card',
            '512603': 'Visa Fee',
            '512701': 'Corporate Tax Expense',
            '512801': 'Office Expense',
        }

        group_labels = _build_group_label_map([
            NON_CURRENT_ASSET_GROUPS,
            CURRENT_ASSET_GROUPS,
            NON_CURRENT_LIABILITY_GROUPS,
            CURRENT_LIABILITY_GROUPS,
            EQUITY_GROUPS,
            REVENUE_GROUPS,
            OTHER_INCOME_GROUPS,
            COST_OF_REVENUE_GROUPS,
            DEPRECIATION_GROUPS,
        ])

        # Current year
        current_rows = _fetch_account_rows(self.date_start, self.date_end)
        current_prefix_totals = {
            1: _sum_by_prefix(current_rows, 1),
            2: _sum_by_prefix(current_rows, 2),
            4: _sum_by_prefix(current_rows, 4),
            6: _sum_by_prefix(current_rows, 6),
            8: _sum_by_prefix(current_rows, 8),
        }
        current_group_totals = current_prefix_totals[4]
        current_main_heads = _label_group_totals(current_group_totals, MAIN_HEAD_LABELS)
        current_subheads_by_group = _build_subhead_groups(
            current_prefix_totals[6],
            SUBHEAD_LABELS,
        )
        current_ppe_subheads = {
            row['name']: row['balance']
            for row in current_subheads_by_group.get('1101', [])
        }
        current_ppe_total = sum(current_ppe_subheads.values())

        annotated_rows = _annotate_rows(current_rows, group_labels)
        balance_rows = [row for row in annotated_rows if row['one_digit_code'] in ('1', '2', '3')]
        profit_loss_accounts = [row for row in annotated_rows if row['one_digit_code'] in ('4', '5')]



        current_assets = _build_section_totals(current_group_totals, CURRENT_ASSET_GROUPS)
        non_current_assets = _build_section_totals(current_group_totals, NON_CURRENT_ASSET_GROUPS)
        current_liabilities = _build_section_totals(current_group_totals, CURRENT_LIABILITY_GROUPS)
        non_current_liabilities = _build_section_totals(current_group_totals, NON_CURRENT_LIABILITY_GROUPS)
        equity = _build_section_totals(current_group_totals, EQUITY_GROUPS)

        current_assets_total = sum(current_assets.values())
        non_current_assets_total = sum(non_current_assets.values())
        total_assets = current_assets_total + non_current_assets_total


        current_liabilities_total = sum(current_liabilities.values())
        non_current_liabilities_total = sum(non_current_liabilities.values())
        total_liabilities = -(current_liabilities_total + non_current_liabilities_total)

        total_equity = sum(equity.values())
        total_of_equity_and_liabilities = total_equity + total_liabilities

        # PnL (current year)
        revenue_total = sum(
            current_group_totals.get(code, 0.0)
            for code in REVENUE_GROUPS['Revenue']
        )
        revenue_total = -(revenue_total)
        other_income_total = sum(
            current_group_totals.get(code, 0.0)
            for code in OTHER_INCOME_GROUPS['Other income']
        )
        cost_of_revenue_total = sum(
            current_group_totals.get(code, 0.0)
            for code in COST_OF_REVENUE_GROUPS['Cost of revenue']
        )
        depreciation_total = sum(
            current_group_totals.get(code, 0.0)
            for code in DEPRECIATION_GROUPS['Depreciation']
        )
        expense_total = current_prefix_totals[2].get('51', 0.0)
        operating_expenses_total = expense_total - cost_of_revenue_total - depreciation_total

        gross_profit = revenue_total - cost_of_revenue_total
        net_profit_before_tax = gross_profit - operating_expenses_total + other_income_total
        tax_amount = 0.0
        net_profit_after_tax = 0.0

        if net_profit_before_tax > 375000:
            tax_amount = (net_profit_before_tax - 375000) * 0.09
            net_profit_after_tax = net_profit_before_tax - tax_amount

        # Prior year
        prev_rows = _fetch_account_rows(prior_date_start, prior_date_end)
        prev_prefix_totals = {
            1: _sum_by_prefix(prev_rows, 1),
            2: _sum_by_prefix(prev_rows, 2),
            4: _sum_by_prefix(prev_rows, 4),
            6: _sum_by_prefix(prev_rows, 6),
            8: _sum_by_prefix(prev_rows, 8),
        }
        prev_group_totals = prev_prefix_totals[4]
        prev_main_heads = _label_group_totals(prev_group_totals, MAIN_HEAD_LABELS)
        prev_subheads_by_group = _build_subhead_groups(
            prev_prefix_totals[6],
            SUBHEAD_LABELS,
        )
        prev_ppe_subheads = {
            row['name']: row['balance']
            for row in prev_subheads_by_group.get('1101', [])
        }
        prev_ppe_total = sum(prev_ppe_subheads.values())

        prev_current_assets = _build_section_totals(prev_group_totals, CURRENT_ASSET_GROUPS)
        prev_non_current_assets = _build_section_totals(prev_group_totals, NON_CURRENT_ASSET_GROUPS)
        prev_current_liabilities = _build_section_totals(prev_group_totals, CURRENT_LIABILITY_GROUPS)
        prev_non_current_liabilities = _build_section_totals(prev_group_totals, NON_CURRENT_LIABILITY_GROUPS)
        prev_equity = _build_section_totals(prev_group_totals, EQUITY_GROUPS)

        prev_current_assets_total = sum(prev_current_assets.values())
        prev_non_current_assets_total = sum(prev_non_current_assets.values())
        prev_total_assets = prev_current_assets_total + prev_non_current_assets_total

        prev_current_liabilities_total = sum(prev_current_liabilities.values())
        prev_non_current_liabilities_total = sum(prev_non_current_liabilities.values())
        prev_total_liabilities = -(prev_current_liabilities_total + prev_non_current_liabilities_total)

        prev_equity_total = sum(prev_equity.values())
        prev_total_equity = prev_equity_total
        prev_total_of_equity_and_liabilities = prev_total_equity + prev_total_liabilities

        prev_revenue_total = sum(
            prev_group_totals.get(code, 0.0)
            for code in REVENUE_GROUPS['Revenue']
        )
        prev_revenue_total = -(prev_revenue_total)
        prev_other_income_total = sum(
            prev_group_totals.get(code, 0.0)
            for code in OTHER_INCOME_GROUPS['Other income']
        )
        prev_cost_of_revenue_total = sum(
            prev_group_totals.get(code, 0.0)
            for code in COST_OF_REVENUE_GROUPS['Cost of revenue']
        )
        prev_depreciation_total = sum(
            prev_group_totals.get(code, 0.0)
            for code in DEPRECIATION_GROUPS['Depreciation']
        )
        prev_expense_total = prev_prefix_totals[2].get('51', 0.0)
        prev_operating_expenses_total = prev_expense_total - prev_cost_of_revenue_total - prev_depreciation_total

        prev_gross_profit = prev_revenue_total - prev_cost_of_revenue_total
        prev_net_profit_before_tax = prev_gross_profit - prev_operating_expenses_total + prev_other_income_total
        prev_tax_amount = 0.0
        prev_net_profit_after_tax = prev_net_profit_before_tax

        if prev_net_profit_before_tax > 375000:
            prev_tax_amount = (prev_net_profit_before_tax - 375000) * 0.09
            prev_net_profit_after_tax = prev_net_profit_before_tax - prev_tax_amount

        ###### Variables for Cash Flow Statement ######        
        ############# Part 1 #############
        current_depreciation_total = current_group_totals.get('5114', 0.0)
        prior_depreciation_total = prev_group_totals.get('5114', 0.0)

        operating_cashflow_before_working_capital = net_profit_before_tax + current_depreciation_total


        ############# PART 2 #############
        # Payable (Related Party) movement: Current Year Payable - Prior Year Payable
        related_party_payable_head = '22030101'
        director_payable_heads = ['22030102', '22030103']

        current_due = current_prefix_totals[8].get(related_party_payable_head, 0.0)
        prior_due = prev_prefix_totals[8].get(related_party_payable_head, 0.0)

        current_payables_total = (
            current_group_totals.get('2202', 0.0) +
            current_group_totals.get('2203', 0.0)
        )
        prior_payables_total = (
            prev_group_totals.get('2202', 0.0) +
            prev_group_totals.get('2203', 0.0)
        )

        current_director_payables_total = sum(
            current_prefix_totals[8].get(code, 0.0)
            for code in director_payable_heads
        )
        prior_director_payables_total = sum(
            prev_prefix_totals[8].get(code, 0.0)
            for code in director_payable_heads
        )

        
        decrease_increase_due_related_party = current_due - prior_due
        decrease_increase_in_trade_receivables = current_assets.get("Accounts receivable", 0.0) - prev_current_assets.get("Accounts receivable", 0.0)
        increase_decrease_trade_other_payables = current_payables_total - prior_payables_total
        decrease_in_payable_director = current_director_payables_total - prior_director_payables_total

        net_cash_generated_from_operations = operating_cashflow_before_working_capital + decrease_increase_due_related_party + decrease_increase_in_trade_receivables + increase_decrease_trade_other_payables + decrease_in_payable_director

        ### Cash FLow Part 3: Investing Activities ###
        current_property = -(current_group_totals.get('1101', 0.0))
        current_rou_assets = -(current_group_totals.get('1102', 0.0))
        current_intangilbe = -(current_group_totals.get('1107', 0.0))

        net_cash_used_in_investing_activities = current_property + current_rou_assets + current_intangilbe

        ### Cash Flow Part 4: Financing Activities ###

        cash_from_financing_activities = 0.0 ### PLACEHOLDER ###



        ### Cash Flow Summary ###
        net_cash_and_cash_equivalents = net_cash_generated_from_operations + net_cash_used_in_investing_activities + cash_from_financing_activities
        cash_beginning_year = prev_current_assets.get("Cash and bank balances", 0.0)
        cash_end_of_year = current_assets.get("Cash and bank balances", 0.0)

        prior_operating_cashflow_before_working_capital = prev_net_profit_before_tax + prior_depreciation_total
        prior_decrease_increase_due_related_party = 0.0
        prior_decrease_increase_in_trade_receivables = 0.0
        prior_increase_decrease_trade_other_payables = 0.0
        prior_decrease_in_payable_director = 0.0
        prior_net_cash_generated_from_operations = (
            prior_operating_cashflow_before_working_capital
            + prior_decrease_increase_due_related_party
            + prior_decrease_increase_in_trade_receivables
            + prior_increase_decrease_trade_other_payables
            + prior_decrease_in_payable_director
        )

        prior_property = -(prev_group_totals.get('1101', 0.0))
        prior_rou_assets = -(prev_group_totals.get('1102', 0.0))
        prior_intangilbe = -(prev_group_totals.get('1107', 0.0))
        prior_net_cash_used_in_investing_activities = prior_property + prior_rou_assets + prior_intangilbe

        prior_cash_from_financing_activities = 0.0
        prior_net_cash_and_cash_equivalents = (
            prior_net_cash_generated_from_operations
            + prior_net_cash_used_in_investing_activities
            + prior_cash_from_financing_activities
        )
        prior_cash_beginning_year = 0.0
        prior_cash_end_of_year = cash_beginning_year


        ##############################################################################################

        ############# Shareholders Section #############


        # Shareholders START #
        #########################################################################################################
        company = self.company_id
        # Shareholders (explicit variables)
        sh_name_1 = company.shareholder_1
        sh_nat_1 = company.nationality_1
        sh_shares_1 = company.number_of_shares_1
        sh_value_1 = company.share_value_1
        sh_total_1 = company.total_share_1

        sh_name_2 = company.shareholder_2
        sh_nat_2 = company.nationality_2
        sh_shares_2 = company.number_of_shares_2
        sh_value_2 = company.share_value_2
        sh_total_2 = company.total_share_2

        sh_name_3 = company.shareholder_3
        sh_nat_3 = company.nationality_3
        sh_shares_3 = company.number_of_shares_3
        sh_value_3 = company.share_value_3
        sh_total_3 = company.total_share_3

        sh_name_4 = company.shareholder_4
        sh_nat_4 = company.nationality_4
        sh_shares_4 = company.number_of_shares_4
        sh_value_4 = company.share_value_4
        sh_total_4 = company.total_share_4

        sh_name_5 = company.shareholder_5
        sh_nat_5 = company.nationality_5
        sh_shares_5 = company.number_of_shares_5
        sh_value_5 = company.share_value_5
        sh_total_5 = company.total_share_5

        sh_name_6 = company.shareholder_6
        sh_nat_6 = company.nationality_6
        sh_shares_6 = company.number_of_shares_6
        sh_value_6 = company.share_value_6
        sh_total_6 = company.total_share_6

        sh_name_7 = company.shareholder_7
        sh_nat_7 = company.nationality_7
        sh_shares_7 = company.number_of_shares_7
        sh_value_7 = company.share_value_7
        sh_total_7 = company.total_share_7

        sh_name_8 = company.shareholder_8
        sh_nat_8 = company.nationality_8
        sh_shares_8 = company.number_of_shares_8
        sh_value_8 = company.share_value_8
        sh_total_8 = company.total_share_8

        sh_name_9 = company.shareholder_9
        sh_nat_9 = company.nationality_9
        sh_shares_9 = company.number_of_shares_9
        sh_value_9 = company.share_value_9
        sh_total_9 = company.total_share_9

        sh_name_10 = company.shareholder_10
        sh_nat_10 = company.nationality_10
        sh_shares_10 = company.number_of_shares_10
        sh_value_10 = company.share_value_10
        sh_total_10 = company.total_share_10



        # Shareholders END #
        #########################################################################################################

        # Changes in Equity START #
        #########################################################################################################
        total_shares = sh_total_1 + sh_total_2 + sh_total_3 + sh_total_4 + sh_total_5 + sh_total_6 + sh_total_7 + sh_total_8 + sh_total_9 + sh_total_10

        retained_earnings = 0.0

        if net_profit_before_tax > 375000:
            retained_earnings = net_profit_after_tax
        else:
            retained_earnings = net_profit_before_tax

        prev_retained_earnings = (
            prev_net_profit_after_tax
            if prev_net_profit_before_tax > 375000
            else prev_net_profit_before_tax
        )

        # Total Equity to show on the statement of changes in equity
        total_soce = total_shares + retained_earnings
        prev_total_soce = total_shares + prev_retained_earnings

        # Changes in Equity END #
        #########################################################################################################

        # Statement of Cash Flows START #
        #########################################################################################################
        

        


        # Statement of Cash Flows END #
        #########################################################################################################

        return {

            # Balance Sheet
            'balance_rows': balance_rows,
            'profit_loss_accounts': profit_loss_accounts,
            'total_assets': total_assets,
            'total_liabilities': total_liabilities,
            'total_equity': total_equity,
            'current_assets': current_assets,
            'current_liabilities': current_liabilities,
            'equity': equity,
            'non_current_assets': non_current_assets,
            'non_current_liabilities': non_current_liabilities,
            'current_liabilities_total': current_liabilities_total,
            'non_current_liabilities_total': non_current_liabilities_total,
            'current_assets_total': current_assets_total,
            'non_current_assets_total': non_current_assets_total,
            'total_of_equity_and_liabilities': total_of_equity_and_liabilities,
            'prev_current_assets_total': prev_current_assets_total,
            'prev_non_current_assets_total': prev_non_current_assets_total,
            'prev_total_assets': prev_total_assets,
            'prev_current_liabilities_total': prev_current_liabilities_total,
            'prev_non_current_liabilities_total': prev_non_current_liabilities_total,
            'prev_total_liabilities': prev_total_liabilities,
            'prev_total_equity': prev_total_equity,
            'prev_total_of_equity_and_liabilities': prev_total_of_equity_and_liabilities,

            # PnL
             'cost_of_revenue_total':cost_of_revenue_total,
             'depreciation_total':depreciation_total,
             'operating_expenses_total':operating_expenses_total,
             'revenue_total':revenue_total,
             'gross_profit':gross_profit,
             'net_profit_before_tax':net_profit_before_tax,
             'net_profit_after_tax':net_profit_after_tax,
             'tax_amount':tax_amount,
             'prev_revenue_total': prev_revenue_total,
             'prev_cost_of_revenue_total': prev_cost_of_revenue_total,
             'prev_gross_profit': prev_gross_profit,
             'prev_operating_expenses_total': prev_operating_expenses_total,
             'prev_net_profit_before_tax': prev_net_profit_before_tax,
             'prev_tax_amount': prev_tax_amount,
             'prev_net_profit_after_tax': prev_net_profit_after_tax,

             # Statement of Changes in Equity
             'retained_earnings':retained_earnings,
            'total_soce':total_soce,
            'prev_retained_earnings': prev_retained_earnings,
            'prev_total_soce': prev_total_soce,
            'share_capital_total': total_shares,
            'prev_share_capital_total': total_shares,

            # Shareholders
            'sh_name_1':sh_name_1,
             'sh_nat_1':sh_nat_1,
             'sh_shares_1':sh_shares_1,
             'sh_value_1':sh_value_1,
             'sh_total_1':sh_total_1,
             'sh_name_2':sh_name_2,
             'sh_nat_2':sh_nat_2,
             'sh_shares_2':sh_shares_2,
             'sh_value_2':sh_value_2,
             'sh_total_2':sh_total_2,
             'sh_name_3':sh_name_3,
             'sh_nat_3':sh_nat_3,
             'sh_shares_3':sh_shares_3,
             'sh_value_3':sh_value_3,
             'sh_total_3':sh_total_3,

             # Property and equipment subheads
             'current_ppe_subheads': current_ppe_subheads,
             'current_ppe_total': current_ppe_total,
             'prev_ppe_subheads': prev_ppe_subheads,
             'prev_ppe_total': prev_ppe_total,
             'current_subheads_by_group': current_subheads_by_group,
             'prev_subheads_by_group': prev_subheads_by_group,
             'current_main_heads': current_main_heads,
             'prev_main_heads': prev_main_heads,
             'main_head_labels': MAIN_HEAD_LABELS,
             'current_group_totals': current_group_totals,
            'prev_group_totals': prev_group_totals,

            # Cash flow
            'current_depreciation_total': current_depreciation_total,
            'prior_depreciation_total': prior_depreciation_total,
            'operating_cashflow_before_working_capital': operating_cashflow_before_working_capital,
            'decrease_increase_due_related_party': decrease_increase_due_related_party,
            'decrease_increase_in_trade_receivables': decrease_increase_in_trade_receivables,
            'increase_decrease_trade_other_payables': increase_decrease_trade_other_payables,
            'decrease_in_payable_director': decrease_in_payable_director,
            'net_cash_generated_from_operations': net_cash_generated_from_operations,
            'current_property': current_property,
            'current_rou_assets': current_rou_assets,
            'current_intangilbe': current_intangilbe,
            'net_cash_used_in_investing_activities': net_cash_used_in_investing_activities,
            'cash_from_financing_activities': cash_from_financing_activities,
            'net_cash_and_cash_equivalents': net_cash_and_cash_equivalents,
            'cash_beginning_year': cash_beginning_year,
            'cash_end_of_year': cash_end_of_year,
            'prior_operating_cashflow_before_working_capital': prior_operating_cashflow_before_working_capital,
            'prior_decrease_increase_due_related_party': prior_decrease_increase_due_related_party,
            'prior_decrease_increase_in_trade_receivables': prior_decrease_increase_in_trade_receivables,
            'prior_increase_decrease_trade_other_payables': prior_increase_decrease_trade_other_payables,
            'prior_decrease_in_payable_director': prior_decrease_in_payable_director,
            'prior_net_cash_generated_from_operations': prior_net_cash_generated_from_operations,
            'prior_property': prior_property,
            'prior_rou_assets': prior_rou_assets,
            'prior_intangilbe': prior_intangilbe,
            'prior_net_cash_used_in_investing_activities': prior_net_cash_used_in_investing_activities,
            'prior_cash_from_financing_activities': prior_cash_from_financing_activities,
            'prior_net_cash_and_cash_equivalents': prior_net_cash_and_cash_equivalents,
            'prior_cash_beginning_year': prior_cash_beginning_year,
            'prior_cash_end_of_year': prior_cash_end_of_year,
            }



    def action_print_account_report_lines(self):
        """Generate and display report"""
        self.ensure_one()

        # report_data = self._get_report_data()
        # You can now pass `report_data` to your Word/PDF renderer

        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/view/{self.id}',
            'target': 'new',
        } 

    

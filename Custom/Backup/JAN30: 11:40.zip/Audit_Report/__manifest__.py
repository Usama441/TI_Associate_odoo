{
    'name': 'Audit Report',
    'version': '19.0.1.0.0',
    'category': 'Accounting',
    'summary': 'Print Account Report Lines to Console',
    'description': """
        This module provides a wizard to print account report lines.
    """,
    'author': 'Your Company',
    'license': 'LGPL-3',
    'depends': [
        'account_reports',
        'company_exte',
        'account_cash_flow_config',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
    ],
    'demo': [],
    'installable': True,
    'auto_install': False,
    'application': False,
}


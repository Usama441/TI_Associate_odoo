# Cash Flow Account Mapping (Audit_Report)

Source: Custom/Audit_Report/models/audit_report.py

This document lists which account codes feed each cash‑flow line item **as currently implemented**.

## Operating activities (current period)
- Net profit for the year
  - Source: `net_profit_before_tax` (P&L, period: date_start → date_end)
  - Note: label says “Net profit for the year” but value is **before tax** by design.

- Depreciation
  - Code group: `5114` (Depreciation & Amortization)
  - Source: `period_group_totals.get('5114')`

- Interest paid
  - Subgroup: `512401` (Interest Expense)
  - Source: `period_prefix_totals[6].get('512401')` (negated)

- (Increase)/decrease in due to related parties
  - Account head: `22030101`
  - Source: movement in `current_prefix_totals[8]` vs prior

- (Increase)/decrease in trade receivables
  - Group: `1202` (Accounts receivable)
  - Source: movement in `current_assets['Accounts receivable']` vs prior

- Increase/(decrease) in trade and other payables
  - Groups: `2202` (Trade payables) + `2203` (Other payables)
  - Source: movement in `current_group_totals` vs prior
  - Note: `current_interest_paid` is added into this line in code.

- Increase/(decrease) in payable to directors
  - Account heads: `22030102`, `22030103`
  - Source: movement in `current_prefix_totals[8]` vs prior

- Net cash generated from operations
  - Formula (current):
    `operating_cashflow_before_working_capital
     + due_to_related_party_change
     + trade_receivables_change
     + trade_other_payables_change
     + payable_to_director_change`

## Investing activities (current period)
- Purchase of property and equipment
  - Group: `1101`
  - Source: `period_group_totals.get('1101')` (negated)

- Right‑of‑use assets
  - Group: `1102`
  - Source: `period_group_totals.get('1102')` (negated)

- Intangible assets
  - Group: `1107`
  - Source: `period_group_totals.get('1107')` (negated)

- Net cash used in investing activities
  - Sum of the three lines above.

## Financing activities (current period)
- Financing liabilities (net movement)
  - Groups: `2101`, `2102`, `2201`
  - Excludes credit card subgroup: `220103`
  - Source: movement in `current_group_totals` vs prior

- Share capital
  - Account head: `310101`
  - Source: movement in `current_prefix_totals[6]` vs prior

- Dividend paid
  - Account head: `31010202`
  - Source: movement in `current_prefix_totals[8]` vs prior

- Net cash from financing activities
  - Formula:
    `(financing_liabilities_movement
      + share_capital_movement
      - dividend_paid_movement)`

## Cash & cash equivalents
- Beginning of year
  - Group: `1204` (Cash and bank balances)
  - Source: `prev_current_assets['Cash and bank balances']`

- End of year
  - Group: `1204` (Cash and bank balances)
  - Source: `current_assets['Cash and bank balances']`

## Prior year
All prior‑year lines use the same codes, but `prev_*` and `prev_prev_*` totals and movements.

---
If you want any line item to use different codes or movements, tell me which line and the correct account codes.

from odoo import http
from odoo.http import request
from jinja2 import Environment, FileSystemLoader
import os


class AuditReportController(http.Controller):
    
    @http.route('/audit_report/view/<int:report_id>', type='http', auth='user')
    def view_report(self, report_id, **kwargs):
        report = request.env['audit.report'].browse(report_id)
        company = report.company_id
        if not report.exists():
            return request.not_found()
        
        # Get module path
        module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        templates_path = os.path.join(module_path, 'templates')
        
        # Load template
        env = Environment(loader=FileSystemLoader(templates_path))
        template = env.get_template('audit_report_template.html')
        
        # Get data from report
        data = report._get_report_data()

        # Render HTML
        html_content = template.render(
            # Company Info
            company=company,
            company_name=getattr(company, 'name', ''),
            freezone=getattr(company, 'free_zone', ''),
            license=getattr(company, 'company_license_number', ''),
            owner=getattr(company, 'owner', ''),
            date_start=report.date_start,
            date_end=report.date_end,

            # Balance Sheet
            balance_rows=data['balance_rows'],
            current_assets=data['current_assets'],
            current_liabilities=data['current_liabilities'],
            equity=data['equity'],
            non_current_assets=data['non_current_assets'],
            non_current_liabilities=data['non_current_liabilities'],
            current_assets_total=data['current_assets_total'],
            non_current_assets_total=data['non_current_assets_total'],
            total_assets=data['total_assets'],
            current_liabilities_total=data['current_liabilities_total'],
            non_current_liabilities_total=data['non_current_liabilities_total'],
            total_liabilities=data['total_liabilities'],
            total_equity=data['total_equity'],
            total_of_equity_and_liabilities=data['total_of_equity_and_liabilities'],

            # PnL
            cost_of_revenue_total=data['cost_of_revenue_total'],
            depreciation_total=data['depreciation_total'],
            operating_expenses_total=data['operating_expenses_total'],
            revenue_total=data['revenue_total'],
            gross_profit=data['gross_profit'],
            net_profit_before_tax=data['net_profit_before_tax'],
            net_profit_after_tax=data['net_profit_after_tax'],
            tax_amount=data['tax_amount'],
        )
        
        # Load and inject CSS
        css_path = os.path.join(templates_path, 'audit_report_style.css')
        with open(css_path, 'r') as f:
            css_content = f.read()
        
        html_with_style = html_content.replace('</head>', f'<style>{css_content}</style></head>')
        
        return request.make_response(
            html_with_style,
            headers=[('Content-Type', 'text/html; charset=utf-8')]
        )

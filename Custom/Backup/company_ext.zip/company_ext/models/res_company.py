from odoo import models, fields

class ResCompany(models.Model):
    _inherit = 'res.company'

    # Free Zone & License
    free_zone = fields.Char(string="Company Free Zone")
    company_license_number = fields.Char(string="Company License Number")
    trade_license_activities = fields.Text(string="Trade License Activities")

    # Tax Information
    corporate_tax_registration_number = fields.Char(
        string="Corporate Tax Registration Number"
    )
    vat_registration_number = fields.Char(
        string="VAT Registration Number"
    )

    corporate_tax_start_date = fields.Date(
        string="Corporate Tax Start Date"
    )
    corporate_tax_end_date = fields.Date(
        string="Corporate Tax End Date"
    )

    # Incorporation
    incorporation_date = fields.Date(
        string="Company Incorporation Date"
    )

    # Regulations
    implementing_regulations_freezone = fields.Text(
        string="Implementing Regulations for Free Zones"
    )

    # Shareholders (Simple Char Field)
    shareholder_ids = fields.Char(
        string="Company Shareholders"
    )

    shareholders_nationalities = fields.Char(
        string="Nationality"
    )

    shareholder_1 = fields.Char()
    shareholder_2 = fields.Char()
    shareholder_3 = fields.Char()
    shareholder_4 = fields.Char()
    shareholder_5 = fields.Char()
    shareholder_6 = fields.Char()
    shareholder_7 = fields.Char()
    shareholder_8 = fields.Char()
    shareholder_9 = fields.Char()
    shareholder_10 = fields.Char()

    nationality_1 = fields.Char()
    nationality_2 = fields.Char()
    nationality_3 = fields.Char()
    nationality_4 = fields.Char()
    nationality_5 = fields.Char()
    nationality_6 = fields.Char()
    nationality_7 = fields.Char()
    nationality_8 = fields.Char()
    nationality_9 = fields.Char()
    nationality_10 = fields.Char()

    # Share Capital Configuration
    authorized_capital = fields.Monetary(
        string="Authorized Share Capital",
        currency_field='currency_id',
        help="Total authorized share capital of the company (e.g., AED 200,000)"
    )
    share_value = fields.Monetary(
        string="Share Value",
        currency_field='currency_id',
        help="Value per share (e.g., AED 1,000)"
    )
    total_shares = fields.Integer(
        string="Total Number of Shares",
        help="Total number of shares (e.g., 200)"
    )

    # Shareholder Shares Allocation
    shares_1 = fields.Integer(string="Shares (Shareholder 1)")
    shares_2 = fields.Integer(string="Shares (Shareholder 2)")
    shares_3 = fields.Integer(string="Shares (Shareholder 3)")
    shares_4 = fields.Integer(string="Shares (Shareholder 4)")
    shares_5 = fields.Integer(string="Shares (Shareholder 5)")
    shares_6 = fields.Integer(string="Shares (Shareholder 6)")
    shares_7 = fields.Integer(string="Shares (Shareholder 7)")
    shares_8 = fields.Integer(string="Shares (Shareholder 8)")
    shares_9 = fields.Integer(string="Shares (Shareholder 9)")
    shares_10 = fields.Integer(string="Shares (Shareholder 10)")

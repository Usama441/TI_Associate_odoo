# Audit_Report Module Changelog

This file tracks simple code-change summaries for `Custom/Audit_Report` only.
## 2026-02-24 16:36:37
- Stage: start
- Summary: Start changelog tracking for Audit_Report module
## 2026-02-24 16:36:37
- Stage: change
- Summary: Updated retained earnings rollforward and SOCE statutory transfer labeling
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-24 16:42:03
- Stage: change
- Summary: Removed before-tax bottom amount lines when corporate tax provision line is shown in PnL
- Files:
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
## 2026-02-24 16:47:20
- Stage: change
- Summary: Removed statutory reserve note reference from balance sheet and moved statutory reserve line below total comprehensive in SOCE/retained earnings notes.
- Files:
  - Custom/Audit_Report/models/audit_report.py
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
## 2026-02-24 16:49:25
- Stage: change
- Summary: Normalized retained earnings note block structure while keeping statutory-reserve row below total comprehensive and above dividend.
- Files:
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
## 2026-02-24 18:52:55
- Stage: change
- Summary: Merged Stripe/other wallets into prepayment receivables presentation and removed standalone Stripe line from statement/financial-assets note output.
- Files:
  - Custom/Audit_Report/models/audit_report.py
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
## 2026-02-25 10:25:24
- Stage: change
- Summary: Updated receivable line-label logic so Stripe/other wallets (1205) are recognized under "Other receivables" instead of showing only "Prepayment" when wallets exist.
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-25 10:31:32
- Stage: change
- Summary: Excluded VAT receivable (120304) and VAT payable (220302, including VAT input/output subaccounts) from financial assets and liabilities note table line totals and grand totals.
- Files:
  - Custom/Audit_Report/models/audit_report.py
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
  - Custom/Audit_Report/audit_report_template_1y.html
## 2026-02-25 10:35:27
- Stage: change
- Summary: Kept entity information city on same line as street by binding city after comma in address output.
- Files:
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
  - Custom/Audit_Report/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_style.css
## 2026-02-25 10:39:09
- Stage: change
- Summary: Made entity-information street and city render as one non-breaking address segment to prevent city wrapping onto next line.
- Files:
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
  - Custom/Audit_Report/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_style.css
## 2026-02-25 10:43:36
- Stage: change
- Summary: Re-enabled wrapping for entity information office address and removed no-wrap constraints on city/country segments.
- Files:
  - Custom/Audit_Report/templates/audit_report_style.css
## 2026-02-25 10:52:07
- Stage: change
- Summary: Kept address wrapping enabled but prevented city and country phrase splitting by making those segments non-breaking.
- Files:
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
  - Custom/Audit_Report/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_style.css
## 2026-02-25 10:57:41
- Stage: change
- Summary: Restricted corporate-tax-liability-paid checkbox impact to cash-flow tax-paid line only.
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-25 11:15:45
- Stage: change
- Summary: Adjusted SOCE first balance retained earnings to use opening carry-forward from prior closing and movements.
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-25 12:15:45
- Stage: change
- Summary: Improved trial-balance overrides UI with compact layout, clearer actions, and better column spacing.
- Files:
  - Custom/Audit_Report/views/views.xml
  - Custom/Audit_Report/__manifest__.py
  - Custom/Audit_Report/static/src/scss/trial_balance_overrides.scss
## 2026-02-25 12:16:39
- Stage: change
- Summary: Hardened trial-balance override SCSS selectors to apply reliably in Odoo form rendering.
- Files:
  - Custom/Audit_Report/static/src/scss/trial_balance_overrides.scss
## 2026-02-25 12:28:46
- Stage: change
- Summary: SOCE first opening balance retained earnings now sources account 31010102 instead of 31010203.
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-25 12:34:57
- Stage: change
- Summary: Reverted SOCE opening retained-earnings source change and restored previous carry-forward logic.
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-25 12:50:38
- Stage: change
- Summary: Swapped retained-earnings display logic between first and second SOCE opening balance rows, with totals adjusted accordingly.
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-25 13:15:41
- Stage: change
- Summary: Moved SOCE opening-balance retained-earnings swap into core calculation logic and removed display-only swap layer.
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-25 14:16:17
- Stage: change
- Summary: Made middle SOCE balance row a subtotal carry-forward of prior opening plus comparative movements across equity columns.
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-25 14:23:26
- Stage: change
- Summary: Aligned prior-year retained earnings with middle SOCE subtotal carry-forward so both use the same value.
- Files:
  - Custom/Audit_Report/models/audit_report.py

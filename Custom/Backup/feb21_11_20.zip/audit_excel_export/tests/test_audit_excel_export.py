import base64
import io
import unittest

try:
    from openpyxl import load_workbook
except ImportError:
    load_workbook = None

from odoo import Command, fields
from odoo.addons.account.tests.common import AccountTestInvoicingCommon
from odoo.tests.common import tagged


@tagged('post_install', '-at_install')
@unittest.skipUnless(load_workbook, 'openpyxl is required for XLSX assertions')
class TestAuditExcelExport(AccountTestInvoicingCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.export_date_from = fields.Date.from_string('2025-01-01')
        cls.export_date_to = fields.Date.from_string('2025-12-31')
        cls.aged_as_of_date = fields.Date.from_string('2025-12-31')

        cls.customer_partner = cls.partner_a
        cls.vendor_partner = cls.partner_b

        cls.customer_invoice_posted = cls.init_invoice(
            'out_invoice',
            partner=cls.customer_partner,
            invoice_date=fields.Date.from_string('2025-01-10'),
            post=True,
            amounts=[100.0],
        )
        cls.customer_invoice_cancelled = cls.init_invoice(
            'out_invoice',
            partner=cls.customer_partner,
            invoice_date=fields.Date.from_string('2025-01-11'),
            post=True,
            amounts=[50.0],
        )
        cls.customer_invoice_cancelled.button_cancel()

        cls.customer_invoice_draft = cls.init_invoice(
            'out_invoice',
            partner=cls.customer_partner,
            invoice_date=fields.Date.from_string('2025-01-12'),
            post=False,
            amounts=[33.0],
        )
        cls.customer_refund_posted = cls.init_invoice(
            'out_refund',
            partner=cls.customer_partner,
            invoice_date=fields.Date.from_string('2025-01-13'),
            post=True,
            amounts=[10.0],
        )

        cls.vendor_bill_posted = cls.init_invoice(
            'in_invoice',
            partner=cls.vendor_partner,
            invoice_date=fields.Date.from_string('2025-01-14'),
            post=True,
            amounts=[80.0],
        )
        cls.vendor_bill_cancelled = cls.init_invoice(
            'in_invoice',
            partner=cls.vendor_partner,
            invoice_date=fields.Date.from_string('2025-01-15'),
            post=True,
            amounts=[45.0],
        )
        cls.vendor_bill_cancelled.button_cancel()

        cls.vendor_bill_draft = cls.init_invoice(
            'in_invoice',
            partner=cls.vendor_partner,
            invoice_date=fields.Date.from_string('2025-01-16'),
            post=False,
            amounts=[22.0],
        )
        cls.vendor_refund_posted = cls.init_invoice(
            'in_refund',
            partner=cls.vendor_partner,
            invoice_date=fields.Date.from_string('2025-01-17'),
            post=True,
            amounts=[9.0],
        )

    def _create_wizard(self, **overrides):
        vals = {
            'company_ids': [Command.set(self.env.company.ids)],
            'date_from': self.export_date_from,
            'date_to': self.export_date_to,
            'aged_as_of_date': self.aged_as_of_date,
            'include_draft_entries': True,
            'unfold_all': True,
            'hide_zero_lines': False,
            'aging_based_on': 'base_on_maturity_date',
            'aging_interval': 30,
            'show_currency': True,
            'show_account': True,
            'include_dynamic_columns': True,
            'invoice_bill_scope': 'all_states',
            'include_refunds': True,
            'partner_ids': [Command.set([self.customer_partner.id, self.vendor_partner.id])],
        }
        vals.update(overrides)
        return self.env['audit.excel.export.wizard'].create(vals)

    def _export_workbook(self, wizard):
        action = wizard.action_export_xlsx()
        self.assertEqual(action.get('type'), 'ir.actions.act_url')
        self.assertTrue(wizard.file_data)
        binary = base64.b64decode(wizard.file_data)
        self.assertGreater(len(binary), 0)
        wb = load_workbook(io.BytesIO(binary), data_only=True)
        return action, wb

    def _sheet_values(self, ws):
        values = []
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is not None:
                    values.append(str(cell.value))
        return values

    def test_01_export_returns_binary_file(self):
        wizard = self._create_wizard()
        action, _wb = self._export_workbook(wizard)

        self.assertIn('download=true', action.get('url', ''))
        self.assertTrue(wizard.file_name.endswith('.xlsx'))

    def test_02_workbook_has_five_expected_sheets(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        self.assertEqual(
            wb.sheetnames,
            ['General Ledger', 'Customer Invoices', 'Vendor Bills', 'Aged Receivables', 'Aged Payables'],
        )

    def test_03_gl_and_aged_partner_filtered_content(self):
        wizard = self._create_wizard(
            partner_ids=[Command.set([self.customer_partner.id])],
        )
        _action, wb = self._export_workbook(wizard)

        gl_values = self._sheet_values(wb['General Ledger'])
        ar_values = self._sheet_values(wb['Aged Receivables'])

        self.assertIn('Fixed Table - Journal Items', gl_values)
        self.assertIn('Fixed Table - Aged Detail', ar_values)
        self.assertIn(self.customer_partner.display_name, ar_values)

    def test_04_invoice_bill_include_states_and_refunds(self):
        wizard = self._create_wizard(invoice_bill_scope='all_states', include_refunds=True)
        _action, wb = self._export_workbook(wizard)

        ci_values = self._sheet_values(wb['Customer Invoices'])
        vb_values = self._sheet_values(wb['Vendor Bills'])

        self.assertIn('Draft', ci_values)
        self.assertIn('Cancelled', ci_values)
        self.assertIn(self.customer_refund_posted.name, ci_values)

        self.assertIn('Draft', vb_values)
        self.assertIn('Cancelled', vb_values)
        self.assertIn(self.vendor_refund_posted.name, vb_values)

    def test_05_dynamic_mode_present(self):
        wizard = self._create_wizard(include_dynamic_columns=True)
        _action, wb = self._export_workbook(wizard)

        gl_values = self._sheet_values(wb['General Ledger'])
        ar_values = self._sheet_values(wb['Aged Receivables'])
        ci_values = self._sheet_values(wb['Customer Invoices'])
        vb_values = self._sheet_values(wb['Vendor Bills'])

        self.assertIn('Dynamic Table - Report Lines', gl_values)
        self.assertIn('Dynamic Table - Report Lines', ar_values)
        self.assertIn('Salesperson', ci_values)
        self.assertIn('Salesperson', vb_values)

    def test_06_formatting_smoke(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            self.assertIsNotNone(ws.freeze_panes)
            self.assertTrue(ws.auto_filter.ref)

        gl_sheet = wb['General Ledger']
        header_cell = None
        for row in gl_sheet.iter_rows(min_row=1, max_row=80):
            for cell in row:
                if cell.value == 'Entry Date':
                    header_cell = cell
                    break
            if header_cell:
                break

        self.assertIsNotNone(header_cell)
        self.assertNotEqual(header_cell.style_id, 0)

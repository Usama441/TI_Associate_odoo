import base64
import datetime
import io
import json

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError
from odoo.tools import html2plaintext


class AuditExcelExportWizard(models.TransientModel):
    _name = 'audit.excel.export.wizard'
    _description = 'Audit Excel Export Wizard'

    company_ids = fields.Many2many(
        'res.company',
        string='Companies',
        required=True,
        default=lambda self: self.env.company,
    )
    date_from = fields.Date(
        string='Date From',
        required=True,
        default=lambda self: fields.Date.context_today(self).replace(day=1),
    )
    date_to = fields.Date(
        string='Date To',
        required=True,
        default=lambda self: fields.Date.context_today(self),
    )
    aged_as_of_date = fields.Date(
        string='Aged As Of Date',
        required=True,
        default=lambda self: fields.Date.context_today(self),
    )

    journal_ids = fields.Many2many('account.journal', string='Journals')
    partner_ids = fields.Many2many('res.partner', string='Partners')
    analytic_account_ids = fields.Many2many('account.analytic.account', string='Analytic Accounts')

    include_draft_entries = fields.Boolean(string='Include Draft Entries', default=False)
    unfold_all = fields.Boolean(string='Unfold All', default=True)
    hide_zero_lines = fields.Boolean(string='Hide Zero Lines', default=False)

    aging_based_on = fields.Selection(
        [
            ('base_on_invoice_date', 'Based on Invoice Date'),
            ('base_on_maturity_date', 'Based on Maturity Date'),
        ],
        string='Aging Based On',
        default='base_on_maturity_date',
        required=True,
    )
    aging_interval = fields.Integer(string='Aging Interval (Days)', default=30)
    show_currency = fields.Boolean(string='Show Currency Column', default=True)
    show_account = fields.Boolean(string='Show Account Column', default=True)

    include_dynamic_columns = fields.Boolean(string='Include Dynamic Columns', default=True)
    invoice_bill_scope = fields.Selection(
        [
            ('all_states', 'All States'),
            ('posted_only', 'Posted Only'),
            ('posted_cancelled', 'Posted + Cancelled'),
        ],
        string='Invoices/Bills State Scope',
        default='all_states',
        required=True,
    )
    include_refunds = fields.Boolean(string='Include Credit Notes/Refunds', default=True)

    gl_options_json = fields.Text(string='General Ledger Options Override (JSON)')
    aged_receivable_options_json = fields.Text(string='Aged Receivable Options Override (JSON)')
    aged_payable_options_json = fields.Text(string='Aged Payable Options Override (JSON)')

    file_name = fields.Char(string='File Name', readonly=True)
    file_data = fields.Binary(string='File', readonly=True)

    @api.constrains('date_from', 'date_to')
    def _check_date_range(self):
        for wizard in self:
            if wizard.date_from and wizard.date_to and wizard.date_from > wizard.date_to:
                raise ValidationError(_('Date From must be earlier than or equal to Date To.'))

    @api.constrains('aging_interval')
    def _check_aging_interval(self):
        for wizard in self:
            if wizard.aging_interval <= 0:
                raise ValidationError(_('Aging Interval must be greater than zero.'))

    def action_export_xlsx(self):
        self.ensure_one()
        if self.date_from > self.date_to:
            raise ValidationError(_('Date From must be earlier than or equal to Date To.'))
        if not self.aged_as_of_date:
            raise ValidationError(_('Aged As Of Date is required.'))

        gl_overrides = self._parse_json_options(self.gl_options_json, _('General Ledger Options Override'))
        ar_overrides = self._parse_json_options(self.aged_receivable_options_json, _('Aged Receivable Options Override'))
        ap_overrides = self._parse_json_options(self.aged_payable_options_json, _('Aged Payable Options Override'))

        output = io.BytesIO()
        import xlsxwriter  # noqa: PLC0415

        workbook = xlsxwriter.Workbook(output, {
            'in_memory': True,
            'strings_to_formulas': False,
        })

        formats = self._get_formats(workbook)
        used_sheet_names = set()

        gl_payload = self._prepare_general_ledger_payload(gl_overrides)
        self._write_sheet(workbook, used_sheet_names, formats, **gl_payload)

        customer_payload = self._prepare_invoice_bill_payload(is_customer=True)
        self._write_sheet(workbook, used_sheet_names, formats, **customer_payload)

        vendor_payload = self._prepare_invoice_bill_payload(is_customer=False)
        self._write_sheet(workbook, used_sheet_names, formats, **vendor_payload)

        ar_payload = self._prepare_aged_payload(
            xmlid='account_reports.aged_receivable_report',
            sheet_name='Aged Receivables',
            title='Aged Receivables',
            overrides=ar_overrides,
        )
        self._write_sheet(workbook, used_sheet_names, formats, **ar_payload)

        ap_payload = self._prepare_aged_payload(
            xmlid='account_reports.aged_payable_report',
            sheet_name='Aged Payables',
            title='Aged Payables',
            overrides=ap_overrides,
        )
        self._write_sheet(workbook, used_sheet_names, formats, **ap_payload)

        workbook.close()
        output.seek(0)
        file_bytes = output.read()
        output.close()

        filename = f"audit_export_{fields.Date.to_string(self.date_from)}_{fields.Date.to_string(self.date_to)}.xlsx"
        self.write({
            'file_name': filename,
            'file_data': base64.b64encode(file_bytes),
        })

        return {
            'type': 'ir.actions.act_url',
            'url': (
                f"/web/content/?model={self._name}&id={self.id}"
                "&field=file_data&filename_field=file_name&download=true"
            ),
            'target': 'self',
        }

    def _parse_json_options(self, raw_value, field_label):
        if not raw_value:
            return {}

        try:
            parsed = json.loads(raw_value)
        except (TypeError, ValueError) as exc:
            raise ValidationError(_('%(field)s must contain valid JSON. Error: %(error)s', field=field_label, error=str(exc))) from exc

        if not isinstance(parsed, dict):
            raise ValidationError(_('%(field)s must be a JSON object.', field=field_label))

        return parsed

    def _get_report_or_raise(self, xmlid):
        report = self.env.ref(xmlid, raise_if_not_found=False)
        if not report:
            raise ValidationError(_('Accounting report not found: %s') % xmlid)
        return report.with_context(allowed_company_ids=self.company_ids.ids)

    def _build_report_options(self, report, *, date_mode, date_from, date_to, overrides=None, aged=False):
        previous_options = {
            'selected_variant_id': report.id,
            'date': {
                'filter': 'custom',
                'mode': date_mode,
                'date_from': fields.Date.to_string(date_from) if date_from else False,
                'date_to': fields.Date.to_string(date_to),
            },
            'all_entries': self.include_draft_entries,
            'unfold_all': self.unfold_all,
            'hide_0_lines': self.hide_zero_lines,
            'partner_ids': self.partner_ids.ids,
            'analytic_accounts': self.analytic_account_ids.ids,
        }
        if aged:
            previous_options.update({
                'aging_based_on': self.aging_based_on,
                'aging_interval': self.aging_interval,
                'show_currency': self.show_currency,
                'show_account': self.show_account,
            })

        options = report.get_options(previous_options=previous_options)

        if self.journal_ids and options.get('journals'):
            selected_journal_ids = set(self.journal_ids.ids)
            for journal_opt in options['journals']:
                if journal_opt.get('model') == 'account.journal':
                    journal_opt['selected'] = journal_opt.get('id') in selected_journal_ids

        if overrides:
            options = self._deep_merge_dict(options, overrides)

        options['report_id'] = report.id
        return options

    def _deep_merge_dict(self, base_dict, patch_dict):
        result = dict(base_dict)
        for key, value in patch_dict.items():
            if isinstance(value, dict) and isinstance(result.get(key), dict):
                result[key] = self._deep_merge_dict(result[key], value)
            else:
                result[key] = value
        return result

    def _prepare_general_ledger_payload(self, overrides):
        report = self._get_report_or_raise('account_reports.general_ledger_report')
        options = self._build_report_options(
            report,
            date_mode='range',
            date_from=self.date_from,
            date_to=self.date_to,
            overrides=overrides,
            aged=False,
        )

        warnings = {}
        lines = report._get_lines(options, warnings=warnings)

        aml_ids = []
        for line in lines:
            try:
                model_name, model_id = report._get_model_info_from_id(line['id'])
            except Exception:  # report total/special lines can carry synthetic IDs
                continue
            if model_name == 'account.move.line' and model_id:
                aml_ids.append(model_id)

        unique_aml_ids = list(dict.fromkeys(aml_ids))
        aml_records = self.env['account.move.line'].with_context(allowed_company_ids=self.company_ids.ids).browse(unique_aml_ids)
        aml_map = {aml.id: aml for aml in aml_records}

        fixed_headers = [
            'Entry Date',
            'Journal Entry',
            'Journal',
            'Account',
            'Partner',
            'Label',
            'Debit',
            'Credit',
            'Balance',
            'Amount Currency',
            'Currency',
            'Company',
        ]
        fixed_rows = []
        for aml_id in unique_aml_ids:
            aml = aml_map.get(aml_id)
            if not aml:
                continue
            fixed_rows.append([
                aml.date,
                aml.move_id.name or '',
                aml.journal_id.display_name or '',
                f"{aml.account_id.code or ''} {aml.account_id.name or ''}".strip(),
                aml.partner_id.display_name or '',
                aml.name or aml.ref or '',
                aml.debit,
                aml.credit,
                aml.balance,
                aml.amount_currency,
                aml.currency_id.name or '',
                aml.company_id.name or '',
            ])

        sections = [{
            'section_title': 'Fixed Table - Journal Items',
            'headers': fixed_headers,
            'rows': fixed_rows,
            'column_types': {
                0: 'date',
                6: 'number',
                7: 'number',
                8: 'number',
                9: 'number',
            },
            'total_columns': {6, 7, 8, 9},
        }]

        if self.include_dynamic_columns:
            sections.append(self._build_dynamic_section(lines, options, section_title='Dynamic Table - Report Lines'))

        return {
            'sheet_name': 'General Ledger',
            'title': 'General Ledger',
            'metadata': self._build_sheet_metadata('General Ledger', options=options),
            'sections': sections,
        }

    def _prepare_aged_payload(self, *, xmlid, sheet_name, title, overrides):
        report = self._get_report_or_raise(xmlid)
        options = self._build_report_options(
            report,
            date_mode='single',
            date_from=self.aged_as_of_date,
            date_to=self.aged_as_of_date,
            overrides=overrides,
            aged=True,
        )

        warnings = {}
        lines = report._get_lines(options, warnings=warnings)

        labels = [col.get('expression_label') for col in options.get('columns', [])]
        aml_ids = []
        for line in lines:
            try:
                model_name, model_id = report._get_model_info_from_id(line['id'])
            except Exception:
                continue
            if model_name == 'account.move.line' and model_id:
                aml_ids.append(model_id)

        unique_aml_ids = list(dict.fromkeys(aml_ids))
        aml_records = self.env['account.move.line'].with_context(allowed_company_ids=self.company_ids.ids).browse(unique_aml_ids)
        aml_map = {aml.id: aml for aml in aml_records}

        fixed_headers = [
            'Partner',
            'Document',
            'State',
            'Payment State',
            'Invoice Date',
            'Due Date',
            'Account',
            'Currency',
            'At Date',
            'Period 1',
            'Period 2',
            'Period 3',
            'Period 4',
            'Older',
            'Total',
            'Company',
        ]

        fixed_rows = []
        for line in lines:
            try:
                model_name, model_id = report._get_model_info_from_id(line['id'])
            except Exception:
                continue
            if model_name != 'account.move.line' or not model_id:
                continue

            aml = aml_map.get(model_id)
            if not aml:
                continue

            value_map = {}
            for idx, expression_label in enumerate(labels):
                if idx >= len(line.get('columns', [])):
                    continue
                col = line['columns'][idx]
                value_map[expression_label] = col.get('no_format') if col.get('no_format') is not None else col.get('name')

            fixed_rows.append([
                aml.partner_id.display_name or '',
                aml.move_id.name or '',
                aml.move_id.state or '',
                aml.move_id.payment_state or '',
                aml.move_id.invoice_date,
                aml.move_id.invoice_date_due,
                value_map.get('account_name') or f"{aml.account_id.code or ''} {aml.account_id.name or ''}".strip(),
                value_map.get('currency') or aml.currency_id.name or '',
                value_map.get('period0') or 0.0,
                value_map.get('period1') or 0.0,
                value_map.get('period2') or 0.0,
                value_map.get('period3') or 0.0,
                value_map.get('period4') or 0.0,
                value_map.get('period5') or 0.0,
                value_map.get('total') or 0.0,
                aml.company_id.name or '',
            ])

        sections = [{
            'section_title': 'Fixed Table - Aged Detail',
            'headers': fixed_headers,
            'rows': fixed_rows,
            'column_types': {
                4: 'date',
                5: 'date',
                8: 'number',
                9: 'number',
                10: 'number',
                11: 'number',
                12: 'number',
                13: 'number',
                14: 'number',
            },
            'total_columns': {8, 9, 10, 11, 12, 13, 14},
        }]

        if self.include_dynamic_columns:
            sections.append(self._build_dynamic_section(lines, options, section_title='Dynamic Table - Report Lines'))

        return {
            'sheet_name': sheet_name,
            'title': title,
            'metadata': self._build_sheet_metadata(title, options=options),
            'sections': sections,
        }

    def _prepare_invoice_bill_payload(self, *, is_customer):
        move_model = self.env['account.move'].with_context(allowed_company_ids=self.company_ids.ids)

        move_types = ['out_invoice'] if is_customer else ['in_invoice']
        if self.include_refunds:
            move_types += ['out_refund'] if is_customer else ['in_refund']

        domain = [
            ('move_type', 'in', move_types),
            ('company_id', 'in', self.company_ids.ids),
            ('invoice_date', '>=', self.date_from),
            ('invoice_date', '<=', self.date_to),
        ]

        state_scope = self._get_invoice_bill_states()
        if state_scope:
            domain.append(('state', 'in', state_scope))

        if self.journal_ids:
            domain.append(('journal_id', 'in', self.journal_ids.ids))
        if self.partner_ids:
            domain.append(('partner_id', 'in', self.partner_ids.ids))

        moves = move_model.search(domain, order='invoice_date, id')

        move_type_labels = dict(self.env['account.move']._fields['move_type'].selection)
        state_labels = dict(self.env['account.move']._fields['state'].selection)
        payment_state_labels = dict(self.env['account.move']._fields['payment_state'].selection)

        fixed_headers = [
            'Document Number',
            'Type',
            'State',
            'Payment State',
            'Partner',
            'Invoice Date',
            'Due Date',
            'Journal',
            'Currency',
            'Untaxed Amount',
            'Tax Amount',
            'Total Amount',
            'Residual Amount',
            'Reference',
            'Company',
        ]

        dynamic_columns = []
        if self.include_dynamic_columns:
            dynamic_columns = [
                ('Salesperson', lambda move: move.invoice_user_id.display_name or ''),
                ('Payment Terms', lambda move: move.invoice_payment_term_id.display_name or ''),
                ('Invoice Origin', lambda move: move.invoice_origin or ''),
                ('Fiscal Position', lambda move: move.fiscal_position_id.display_name or ''),
                ('Auto Post', lambda move: move.auto_post or ''),
            ]
            fixed_headers.extend([name for name, _func in dynamic_columns])

        fixed_rows = []
        for move in moves:
            row = [
                move.name or '',
                move_type_labels.get(move.move_type, move.move_type or ''),
                state_labels.get(move.state, move.state or ''),
                payment_state_labels.get(move.payment_state, move.payment_state or ''),
                move.partner_id.display_name or '',
                move.invoice_date,
                move.invoice_date_due,
                move.journal_id.display_name or '',
                move.currency_id.name or '',
                move.amount_untaxed_signed,
                move.amount_tax_signed,
                move.amount_total_signed,
                move.amount_residual_signed,
                move.ref or '',
                move.company_id.name or '',
            ]
            for _name, getter in dynamic_columns:
                row.append(getter(move))
            fixed_rows.append(row)

        sections = [{
            'section_title': 'Fixed Table - Document Headers',
            'headers': fixed_headers,
            'rows': fixed_rows,
            'column_types': {
                5: 'date',
                6: 'date',
                9: 'number',
                10: 'number',
                11: 'number',
                12: 'number',
            },
            'total_columns': {9, 10, 11, 12},
        }]

        title = 'Customer Invoices' if is_customer else 'Vendor Bills'
        scope_label = {
            'all_states': 'All States',
            'posted_only': 'Posted Only',
            'posted_cancelled': 'Posted + Cancelled',
        }.get(self.invoice_bill_scope, self.invoice_bill_scope)

        metadata = self._build_sheet_metadata(title)
        metadata.append(('Invoice/Bill State Scope', scope_label))
        metadata.append(('Refunds Included', 'Yes' if self.include_refunds else 'No'))

        return {
            'sheet_name': title,
            'title': title,
            'metadata': metadata,
            'sections': sections,
        }

    def _get_invoice_bill_states(self):
        if self.invoice_bill_scope == 'posted_only':
            return ['posted']
        if self.invoice_bill_scope == 'posted_cancelled':
            return ['posted', 'cancel']
        return ['draft', 'posted', 'cancel']

    def _build_dynamic_section(self, lines, options, *, section_title):
        dynamic_headers = ['Level', 'Line Name'] + [
            col.get('name') or col.get('expression_label') or _('Column')
            for col in options.get('columns', [])
        ]
        dynamic_rows = []

        for line in lines:
            row = [
                line.get('level') or 0,
                self._clean_line_name(line.get('name') or ''),
            ]
            for col in line.get('columns', []):
                value = col.get('no_format')
                if value is None:
                    value = col.get('name')
                row.append(value)
            dynamic_rows.append(row)

        return {
            'section_title': section_title,
            'headers': dynamic_headers,
            'rows': dynamic_rows,
            'column_types': {
                0: 'number',
            },
            'total_columns': set(),
        }

    def _clean_line_name(self, line_name):
        if not line_name:
            return ''
        if '<' in line_name and '>' in line_name:
            return html2plaintext(line_name)
        return line_name

    def _build_sheet_metadata(self, sheet_label, options=None):
        journals = ', '.join(self.journal_ids.mapped('display_name')) if self.journal_ids else 'All'
        partners = ', '.join(self.partner_ids.mapped('display_name')) if self.partner_ids else 'All'
        analytics = ', '.join(self.analytic_account_ids.mapped('name')) if self.analytic_account_ids else 'All'

        metadata = [
            ('Report', sheet_label),
            ('Companies', ', '.join(self.company_ids.mapped('name'))),
            ('Date Range', f"{fields.Date.to_string(self.date_from)} to {fields.Date.to_string(self.date_to)}"),
            ('Aged As Of Date', fields.Date.to_string(self.aged_as_of_date)),
            ('Journals', journals),
            ('Partners', partners),
            ('Analytic Accounts', analytics),
            ('Include Draft Entries', 'Yes' if self.include_draft_entries else 'No'),
            ('Unfold All', 'Yes' if self.unfold_all else 'No'),
            ('Hide Zero Lines', 'Yes' if self.hide_zero_lines else 'No'),
            ('Generated At', fields.Datetime.to_string(fields.Datetime.now())),
            ('Generated By', self.env.user.name),
        ]

        if options and options.get('warnings'):
            metadata.append(('Warnings', ', '.join(sorted(options['warnings'].keys()))))

        return metadata

    def _get_formats(self, workbook):
        return {
            'title': workbook.add_format({
                'bold': True,
                'font_color': '#FFFFFF',
                'bg_color': '#1F4E78',
                'font_size': 14,
                'align': 'left',
                'valign': 'vcenter',
                'border': 1,
            }),
            'section': workbook.add_format({
                'bold': True,
                'font_color': '#1F2D3D',
                'bg_color': '#D9E1F2',
                'align': 'left',
                'valign': 'vcenter',
                'border': 1,
            }),
            'meta_key': workbook.add_format({
                'bold': True,
                'font_color': '#1F2D3D',
                'bg_color': '#EAF2F8',
                'border': 1,
            }),
            'meta_val': workbook.add_format({
                'font_color': '#1F2D3D',
                'bg_color': '#FFFFFF',
                'border': 1,
            }),
            'header': workbook.add_format({
                'bold': True,
                'font_color': '#FFFFFF',
                'bg_color': '#2F5597',
                'align': 'center',
                'valign': 'vcenter',
                'border': 1,
                'text_wrap': True,
            }),
            'data_text_odd': workbook.add_format({'border': 1, 'bg_color': '#FFFFFF'}),
            'data_text_even': workbook.add_format({'border': 1, 'bg_color': '#F7FBFF'}),
            'data_num_odd': workbook.add_format({'border': 1, 'bg_color': '#FFFFFF', 'num_format': '#,##0.00'}),
            'data_num_even': workbook.add_format({'border': 1, 'bg_color': '#F7FBFF', 'num_format': '#,##0.00'}),
            'data_date_odd': workbook.add_format({'border': 1, 'bg_color': '#FFFFFF', 'num_format': 'yyyy-mm-dd'}),
            'data_date_even': workbook.add_format({'border': 1, 'bg_color': '#F7FBFF', 'num_format': 'yyyy-mm-dd'}),
            'total_text': workbook.add_format({
                'bold': True,
                'border': 1,
                'top': 2,
                'bg_color': '#D9E1F2',
            }),
            'total_num': workbook.add_format({
                'bold': True,
                'border': 1,
                'top': 2,
                'bg_color': '#D9E1F2',
                'num_format': '#,##0.00',
            }),
            'no_data': workbook.add_format({
                'italic': True,
                'font_color': '#6C757D',
                'border': 1,
                'bg_color': '#FFFFFF',
            }),
        }

    def _write_sheet(self, workbook, used_sheet_names, formats, *, sheet_name, title, metadata, sections):
        from xlsxwriter.utility import xl_rowcol_to_cell  # noqa: PLC0415

        sheet = workbook.add_worksheet(self._get_unique_sheet_name(sheet_name, used_sheet_names))

        max_columns = max([2] + [len(section.get('headers', [])) for section in sections])
        row = 0

        sheet.merge_range(row, 0, row, max_columns - 1, title, formats['title'])
        row += 1

        col_widths = {}

        def track_width(col_idx, value):
            text = '' if value is None else str(value)
            width = len(text)
            col_widths[col_idx] = max(col_widths.get(col_idx, 0), width)

        for key, value in metadata:
            sheet.write(row, 0, key, formats['meta_key'])
            sheet.merge_range(row, 1, row, max_columns - 1, value or '', formats['meta_val'])
            track_width(0, key)
            track_width(1, value)
            row += 1

        row += 1
        first_header_row = None

        for section in sections:
            headers = section.get('headers', [])
            rows = section.get('rows', [])
            section_title = section.get('section_title') or _('Section')
            column_types = section.get('column_types', {})
            total_columns = section.get('total_columns', set())

            if not headers:
                continue

            sheet.merge_range(row, 0, row, len(headers) - 1, section_title, formats['section'])
            track_width(0, section_title)
            row += 1

            header_row = row
            if first_header_row is None:
                first_header_row = header_row

            for col_idx, header in enumerate(headers):
                sheet.write(row, col_idx, header, formats['header'])
                track_width(col_idx, header)
            row += 1

            data_start_row = row
            if not rows:
                sheet.merge_range(row, 0, row, len(headers) - 1, _('No data'), formats['no_data'])
                track_width(0, _('No data'))
                row += 1
                data_end_row = row - 1
            else:
                for row_idx, line in enumerate(rows):
                    is_even = row_idx % 2 == 1
                    for col_idx, cell_value in enumerate(line):
                        col_type = column_types.get(col_idx)
                        if col_type == 'number':
                            fmt = formats['data_num_even'] if is_even else formats['data_num_odd']
                            if isinstance(cell_value, (int, float)):
                                sheet.write_number(row, col_idx, float(cell_value), fmt)
                            else:
                                sheet.write(row, col_idx, cell_value or '', fmt)
                        elif col_type == 'date':
                            fmt = formats['data_date_even'] if is_even else formats['data_date_odd']
                            if isinstance(cell_value, datetime.datetime):
                                sheet.write_datetime(row, col_idx, cell_value, fmt)
                            elif isinstance(cell_value, datetime.date):
                                sheet.write_datetime(
                                    row,
                                    col_idx,
                                    datetime.datetime.combine(cell_value, datetime.time.min),
                                    fmt,
                                )
                            else:
                                sheet.write(row, col_idx, cell_value or '', fmt)
                        else:
                            fmt = formats['data_text_even'] if is_even else formats['data_text_odd']
                            if isinstance(cell_value, (int, float)):
                                sheet.write_number(row, col_idx, float(cell_value), fmt)
                            else:
                                sheet.write(row, col_idx, cell_value or '', fmt)

                        track_width(col_idx, cell_value)
                    row += 1
                data_end_row = row - 1

                if total_columns:
                    for col_idx in range(len(headers)):
                        if col_idx == 0:
                            sheet.write(row, col_idx, _('Total'), formats['total_text'])
                            track_width(col_idx, _('Total'))
                        elif col_idx in total_columns:
                            start_cell = xl_rowcol_to_cell(data_start_row, col_idx)
                            end_cell = xl_rowcol_to_cell(data_end_row, col_idx)
                            formula = f'=SUM({start_cell}:{end_cell})'
                            sheet.write_formula(row, col_idx, formula, formats['total_num'])
                        else:
                            sheet.write(row, col_idx, '', formats['total_text'])
                    row += 1

            sheet.autofilter(header_row, 0, max(data_end_row, header_row), len(headers) - 1)
            row += 1

        if first_header_row is not None:
            sheet.freeze_panes(first_header_row + 1, 0)

        for col_idx, width in col_widths.items():
            sheet.set_column(col_idx, col_idx, min(max(width + 2, 10), 48))

    def _get_unique_sheet_name(self, base_name, used_sheet_names):
        max_len = 31
        name = (base_name or 'Sheet').strip()[:max_len]
        if name not in used_sheet_names:
            used_sheet_names.add(name)
            return name

        counter = 1
        while True:
            suffix = f" ({counter})"
            candidate = f"{name[:max_len - len(suffix)]}{suffix}"
            if candidate not in used_sheet_names:
                used_sheet_names.add(candidate)
                return candidate
            counter += 1

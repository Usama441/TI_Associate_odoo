# Audit_Report Module Changelog

This file tracks simple code-change summaries for `Custom/Audit_Report` only.
## 2026-02-24 16:36:37
- Stage: start
- Summary: Start changelog tracking for Audit_Report module
## 2026-02-24 16:36:37
- Stage: change
- Summary: Updated retained earnings rollforward and SOCE statutory transfer labeling
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-24 16:42:03
- Stage: change
- Summary: Removed before-tax bottom amount lines when corporate tax provision line is shown in PnL
- Files:
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
## 2026-02-24 16:47:20
- Stage: change
- Summary: Removed statutory reserve note reference from balance sheet and moved statutory reserve line below total comprehensive in SOCE/retained earnings notes.
- Files:
  - Custom/Audit_Report/models/audit_report.py
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
## 2026-02-24 16:49:25
- Stage: change
- Summary: Normalized retained earnings note block structure while keeping statutory-reserve row below total comprehensive and above dividend.
- Files:
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
## 2026-02-24 18:52:55
- Stage: change
- Summary: Merged Stripe/other wallets into prepayment receivables presentation and removed standalone Stripe line from statement/financial-assets note output.
- Files:
  - Custom/Audit_Report/models/audit_report.py
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
## 2026-02-25 10:25:24
- Stage: change
- Summary: Updated receivable line-label logic so Stripe/other wallets (1205) are recognized under "Other receivables" instead of showing only "Prepayment" when wallets exist.
- Files:
  - Custom/Audit_Report/models/audit_report.py
## 2026-02-25 10:31:32
- Stage: change
- Summary: Excluded VAT receivable (120304) and VAT payable (220302, including VAT input/output subaccounts) from financial assets and liabilities note table line totals and grand totals.
- Files:
  - Custom/Audit_Report/models/audit_report.py
  - Custom/Audit_Report/templates/audit_report_template.html
  - Custom/Audit_Report/templates/audit_report_template_1y.html
  - Custom/Audit_Report/templates/audit_report_template_2y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_1y.html
  - Custom/Audit_Report/templates/audit_report_template_dormant_2y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_1y.html
  - Custom/Audit_Report/templates/audit_report_template_cessation_2y.html
  - Custom/Audit_Report/audit_report_template_1y.html

import base64
import datetime
import io
import json
import os
import re
from copy import copy

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError
from odoo.tools import html2plaintext

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    Workbook = load_workbook = None
    Alignment = Border = Font = PatternFill = Side = None
    get_column_letter = None


class AuditExcelExportWizard(models.TransientModel):
    _name = 'audit.excel.export.wizard'
    _description = 'Audit Excel Export Wizard'

    _DATA_SHEET_SEQUENCE = (
        'General Ledger',
        'Customer Invoices',
        'Vendor Bills',
        'Aged Receivables',
        'Aged Payables',
    )
    _TEMPLATE_SHEET_SOURCE_PLAN = (
        ('vat_control', 'VAT Control', 'VAT Control'),
        ('prepayment', 'Prepayment', 'Prepayment'),
        ('client_details', 'Client Details', 'Client Details'),
        ('summary_sheet', 'SUMMARY', 'Summary Sheet'),
        ('sofp', 'SoFP', 'SOFP'),
        ('soci', 'SoCI', 'SOCI'),
        ('soce', 'SoCE', 'SOCE'),
        ('socf', 'SoCF', 'SOCF'),
        ('share_capital', 'Share Capital', 'Share Capital'),
        ('accruals', 'Accruals', 'Accruals'),
    )
    _TRIAL_BALANCE_SHEET_PLAN = ('trial_balance', 'Trial Balance')
    _TEMPLATE_FILE_RELATIVE_PATH = ('data', 'afs_excel_template.xlsx')

    company_ids = fields.Many2many(
        'res.company',
        string='Companies',
        required=True,
        default=lambda self: self.env.company,
    )
    date_from = fields.Date(
        string='Date From',
        required=True,
        default=lambda self: fields.Date.context_today(self).replace(day=1),
    )
    date_to = fields.Date(
        string='Date To',
        required=True,
        default=lambda self: fields.Date.context_today(self),
    )
    aged_as_of_date = fields.Date(
        string='Aged As Of Date',
        required=True,
        default=lambda self: fields.Date.context_today(self),
    )

    journal_ids = fields.Many2many('account.journal', string='Journals')
    partner_ids = fields.Many2many('res.partner', string='Partners')
    analytic_account_ids = fields.Many2many('account.analytic.account', string='Analytic Accounts')

    include_draft_entries = fields.Boolean(string='Include Draft Entries', default=False)
    unfold_all = fields.Boolean(string='Unfold All', default=True)
    hide_zero_lines = fields.Boolean(string='Hide Zero Lines', default=False)

    aging_based_on = fields.Selection(
        [
            ('base_on_invoice_date', 'Based on Invoice Date'),
            ('base_on_maturity_date', 'Based on Maturity Date'),
        ],
        string='Aging Based On',
        default='base_on_maturity_date',
        required=True,
    )
    aging_interval = fields.Integer(string='Aging Interval (Days)', default=30)
    show_currency = fields.Boolean(string='Show Currency Column', default=True)
    show_account = fields.Boolean(string='Show Account Column', default=True)

    include_dynamic_columns = fields.Boolean(string='Include Dynamic Columns', default=True)
    invoice_bill_scope = fields.Selection(
        [
            ('all_states', 'All States'),
            ('posted_only', 'Posted Only'),
            ('posted_cancelled', 'Posted + Cancelled'),
        ],
        string='Invoices/Bills State Scope',
        default='all_states',
        required=True,
    )
    include_refunds = fields.Boolean(string='Include Credit Notes/Refunds', default=True)

    gl_options_json = fields.Text(string='General Ledger Options Override (JSON)')
    aged_receivable_options_json = fields.Text(string='Aged Receivable Options Override (JSON)')
    aged_payable_options_json = fields.Text(string='Aged Payable Options Override (JSON)')

    file_name = fields.Char(string='File Name', readonly=True)
    file_data = fields.Binary(string='File', readonly=True)

    @api.constrains('date_from', 'date_to')
    def _check_date_range(self):
        for wizard in self:
            if wizard.date_from and wizard.date_to and wizard.date_from > wizard.date_to:
                raise ValidationError(_('Date From must be earlier than or equal to Date To.'))

    @api.constrains('aging_interval')
    def _check_aging_interval(self):
        for wizard in self:
            if wizard.aging_interval <= 0:
                raise ValidationError(_('Aging Interval must be greater than zero.'))

    def action_export_xlsx(self):
        self.ensure_one()
        self._ensure_openpyxl_available()
        if self.date_from > self.date_to:
            raise ValidationError(_('Date From must be earlier than or equal to Date To.'))
        if not self.aged_as_of_date:
            raise ValidationError(_('Aged As Of Date is required.'))

        gl_overrides = self._parse_json_options(self.gl_options_json, _('General Ledger Options Override'))
        ar_overrides = self._parse_json_options(self.aged_receivable_options_json, _('Aged Receivable Options Override'))
        ap_overrides = self._parse_json_options(self.aged_payable_options_json, _('Aged Payable Options Override'))

        # Stage A: build data payloads for generated data sheets + trial balance rows.
        stage_a_payload = self._stage_a_build_data_payload(gl_overrides=gl_overrides, ar_overrides=ar_overrides, ap_overrides=ap_overrides)

        # Stage B: load the formatted workbook template and write first five generated data sheets.
        stage_b_context = self._stage_b_create_workbook_and_write_data_sheets(stage_a_payload)

        # Stage C: append Trial Balance sheet after template-backed tabs.
        stage_c_context = self._stage_c_create_template_sheets(stage_b_context, stage_a_payload['trial_balance'])

        # Stage D: remove static/sample values from template sheets except formulas and TB tab.
        self._stage_d_clean_template_inputs(stage_c_context)

        # Stage E: inject real trial balance figures only on the mapped TB sheet.
        self._stage_e_inject_trial_balance(stage_c_context, stage_a_payload['trial_balance'])

        # Stage F: populate template tabs with wizard/company context values.
        self._stage_f_populate_template_context(stage_c_context)

        # Stage G: finalize binary and keep existing wizard download UX.
        return self._stage_g_finalize_binary_download(stage_c_context['workbook'])

    def _parse_json_options(self, raw_value, field_label):
        if not raw_value:
            return {}

        try:
            parsed = json.loads(raw_value)
        except (TypeError, ValueError) as exc:
            raise ValidationError(_('%(field)s must contain valid JSON. Error: %(error)s', field=field_label, error=str(exc))) from exc

        if not isinstance(parsed, dict):
            raise ValidationError(_('%(field)s must be a JSON object.', field=field_label))

        return parsed

    def _stage_a_build_data_payload(self, *, gl_overrides, ar_overrides, ap_overrides):
        gl_payload = self._prepare_general_ledger_payload(gl_overrides)
        customer_payload = self._prepare_invoice_bill_payload(is_customer=True)
        vendor_payload = self._prepare_invoice_bill_payload(is_customer=False)
        ar_payload = self._prepare_aged_payload(
            xmlid='account_reports.aged_receivable_report',
            sheet_name='Aged Receivables',
            title='Aged Receivables',
            overrides=ar_overrides,
        )
        ap_payload = self._prepare_aged_payload(
            xmlid='account_reports.aged_payable_report',
            sheet_name='Aged Payables',
            title='Aged Payables',
            overrides=ap_overrides,
        )
        trial_balance_payload = self._prepare_trial_balance_payload()

        return {
            'data_sheets': [gl_payload, customer_payload, vendor_payload, ar_payload, ap_payload],
            'trial_balance': trial_balance_payload,
        }

    def _stage_b_create_workbook_and_write_data_sheets(self, stage_a_payload):
        self._ensure_openpyxl_available()

        workbook, template_sheet_map = self._load_formatted_template_workbook()

        used_sheet_names = set(workbook.sheetnames)
        for insert_index, payload in enumerate(stage_a_payload['data_sheets']):
            native_source_sheet = payload.get('native_source_sheet')
            if native_source_sheet is not None:
                self._write_native_sheet_copy(
                    workbook,
                    used_sheet_names,
                    insert_index=insert_index,
                    sheet_name=payload.get('sheet_name') or native_source_sheet.title or 'Sheet',
                    source_sheet=native_source_sheet,
                )
                continue

            self._write_plain_sheet(
                workbook,
                used_sheet_names,
                insert_index=insert_index,
                **payload,
            )

        return {
            'workbook': workbook,
            'used_sheet_names': used_sheet_names,
            'template_sheet_map': template_sheet_map,
        }

    def _stage_c_create_template_sheets(self, stage_b_context, trial_balance_payload):
        workbook = stage_b_context['workbook']
        used_sheet_names = stage_b_context['used_sheet_names']

        template_sheet_map = list(stage_b_context.get('template_sheet_map', []))
        _logical_key, requested_sheet_name = self._TRIAL_BALANCE_SHEET_PLAN
        insert_index = len(self._DATA_SHEET_SEQUENCE) + len(template_sheet_map)
        native_source_sheet = trial_balance_payload.get('native_source_sheet') if trial_balance_payload else None
        if native_source_sheet is not None:
            trial_balance_sheet_name = self._write_native_sheet_copy(
                workbook,
                used_sheet_names,
                insert_index=insert_index,
                sheet_name=trial_balance_payload.get('sheet_name') or requested_sheet_name,
                source_sheet=native_source_sheet,
            )
            trial_balance_prepopulated = True
        else:
            trial_balance_sheet_name = self._get_unique_sheet_name(requested_sheet_name, used_sheet_names)
            sheet = workbook.create_sheet(title=trial_balance_sheet_name, index=insert_index)
            self._build_template_trial_balance_sheet(sheet)
            trial_balance_prepopulated = False

        stage_b_context['template_sheet_map'] = template_sheet_map
        stage_b_context['trial_balance_sheet'] = trial_balance_sheet_name
        stage_b_context['trial_balance_prepopulated'] = trial_balance_prepopulated
        return stage_b_context

    def _stage_d_clean_template_inputs(self, stage_c_context):
        workbook = stage_c_context['workbook']

        for item in stage_c_context['template_sheet_map']:
            sheet_name = item['sheet_name']
            self._cleanup_template_sheet_inputs(workbook[sheet_name])

    def _stage_e_inject_trial_balance(self, stage_c_context, trial_balance_payload):
        if stage_c_context.get('trial_balance_prepopulated'):
            return
        workbook = stage_c_context['workbook']
        sheet = workbook[stage_c_context['trial_balance_sheet']]
        self._write_trial_balance_to_template_sheet(sheet, trial_balance_payload)

    def _stage_f_populate_template_context(self, stage_c_context):
        workbook = stage_c_context['workbook']
        primary_company = self._get_primary_company_for_template()

        client_details_sheet = self._get_sheet_if_exists(workbook, 'Client Details')
        if client_details_sheet is not None:
            self._populate_client_details_sheet(client_details_sheet, primary_company)

        share_capital_sheet = self._get_sheet_if_exists(workbook, 'Share Capital')
        if share_capital_sheet is not None and primary_company:
            self._populate_share_capital_sheet(share_capital_sheet, primary_company)

    def _stage_g_finalize_binary_download(self, workbook):
        output = io.BytesIO()
        workbook.save(output)
        output.seek(0)
        file_bytes = output.read()
        output.close()

        filename = f"audit_export_{fields.Date.to_string(self.date_from)}_{fields.Date.to_string(self.date_to)}.xlsx"
        self.write({
            'file_name': filename,
            'file_data': base64.b64encode(file_bytes),
        })

        return {
            'type': 'ir.actions.act_url',
            'url': (
                f"/web/content/?model={self._name}&id={self.id}"
                "&field=file_data&filename_field=file_name&download=true"
            ),
            'target': 'self',
        }

    def _get_sheet_if_exists(self, workbook, sheet_name):
        if sheet_name in workbook.sheetnames:
            return workbook[sheet_name]
        return None

    def _get_primary_company_for_template(self):
        companies = self.company_ids.sorted('id')
        if companies:
            return companies[0]
        return self.env.company

    def _populate_client_details_sheet(self, sheet, company):
        company_names = ', '.join(self.company_ids.mapped('name')) if self.company_ids else (company.name or '')
        shareholders = self._collect_company_shareholders(company)

        self._write_cell_value(sheet, 'B4', company_names)
        self._write_cell_value(sheet, 'B5', self.date_from)
        self._write_cell_value(sheet, 'B6', self.date_to)

        # Additional company profile fields are only meaningful in single-company export.
        if len(self.company_ids) == 1 and company:
            self._write_cell_value(sheet, 'B8', getattr(company, 'company_license_number', '') or '')
            self._write_cell_value(sheet, 'B9', getattr(company, 'free_zone', '') or '')
            self._write_cell_value(sheet, 'B10', getattr(company, 'incorporation_date', False) or None)
            self._write_cell_value(sheet, 'B12', getattr(company, 'trade_license_activities', '') or '')
            self._write_cell_value(
                sheet,
                'B15',
                getattr(company, 'corporate_tax_registration_number', '') or '',
            )
            self._write_cell_value(sheet, 'B16', getattr(company, 'vat_registration_number', '') or '')
        else:
            self._write_cell_value(sheet, 'B8', '')
            self._write_cell_value(sheet, 'B9', '')
            self._write_cell_value(sheet, 'B10', None)
            self._write_cell_value(sheet, 'B12', '')
            self._write_cell_value(sheet, 'B15', '')
            self._write_cell_value(sheet, 'B16', '')

        self._write_cell_value(sheet, 'B13', ', '.join(shareholders) if shareholders else '')

        for coord in ('B5', 'B6', 'B10'):
            cell = sheet[coord]
            if cell.value:
                cell.number_format = 'yyyy-mm-dd'

    def _populate_share_capital_sheet(self, sheet, company):
        shareholders = self._collect_company_shareholder_rows(company)
        for row_offset in range(4):
            row_no = 7 + row_offset
            row_data = shareholders[row_offset] if row_offset < len(shareholders) else None
            if not row_data:
                self._write_cell_value(sheet, f'A{row_no}', '')
                self._write_cell_value(sheet, f'B{row_no}', None)
                self._write_cell_value(sheet, f'C{row_no}', None)
                continue

            self._write_cell_value(sheet, f'A{row_no}', row_data['name'])
            self._write_cell_value(sheet, f'B{row_no}', row_data['shares'])
            self._write_cell_value(sheet, f'C{row_no}', row_data['share_value'])

            sheet[f'B{row_no}'].number_format = '#,##0'
            sheet[f'C{row_no}'].number_format = '#,##0.00'

    def _collect_company_shareholders(self, company):
        result = []
        if not company:
            return result
        for idx in range(1, 11):
            name = (getattr(company, f'shareholder_{idx}', '') or '').strip()
            if name:
                result.append(name)
        return result

    def _collect_company_shareholder_rows(self, company):
        rows = []
        if not company:
            return rows

        for idx in range(1, 11):
            name = (getattr(company, f'shareholder_{idx}', '') or '').strip()
            shares = getattr(company, f'number_of_shares_{idx}', 0) or 0
            share_value = getattr(company, f'share_value_{idx}', 0.0) or 0.0
            if not name and not shares and not share_value:
                continue
            rows.append({
                'name': name,
                'shares': int(shares) if shares else None,
                'share_value': float(share_value) if share_value else None,
            })
        return rows

    def _write_cell_value(self, sheet, coordinate, value):
        sheet[coordinate].value = value

    def _ensure_openpyxl_available(self):
        if not (load_workbook and Workbook):
            raise ValidationError(_('Python package "openpyxl" is required for this export.'))

    def _resolve_template_workbook_path(self):
        module_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
        candidate = os.path.abspath(os.path.join(module_root, *self._TEMPLATE_FILE_RELATIVE_PATH))
        if os.path.isfile(candidate):
            return candidate
        raise ValidationError(
            _('Template workbook file was not found at "%(path)s".', path=candidate)
        )

    def _load_formatted_template_workbook(self):
        template_path = self._resolve_template_workbook_path()
        try:
            workbook = load_workbook(template_path, data_only=False, keep_links=False)
        except Exception as exc:
            error_message = str(exc) or repr(exc) or exc.__class__.__name__
            raise ValidationError(
                _('Unable to load template workbook "%(path)s": %(error)s', path=template_path, error=error_message)
            ) from exc

        source_sheet_names = [source_sheet_name for _key, source_sheet_name, _target in self._TEMPLATE_SHEET_SOURCE_PLAN]
        missing_sheets = [name for name in source_sheet_names if name not in workbook.sheetnames]
        if missing_sheets:
            raise ValidationError(
                _(
                    'Template workbook "%(path)s" is missing required sheets: %(sheets)s',
                    path=template_path,
                    sheets=', '.join(missing_sheets),
                )
            )

        for sheet in list(workbook.worksheets):
            if sheet.title not in source_sheet_names:
                workbook.remove(sheet)

        rename_map = {
            source_sheet_name: target_sheet_name
            for _logical_key, source_sheet_name, target_sheet_name in self._TEMPLATE_SHEET_SOURCE_PLAN
            if source_sheet_name != target_sheet_name
        }
        temporary_names = {}
        for source_sheet_name, target_sheet_name in rename_map.items():
            if source_sheet_name.lower() == target_sheet_name.lower():
                temporary_name = '__tmp_%s__' % source_sheet_name
                while temporary_name in workbook.sheetnames:
                    temporary_name = '%s_' % temporary_name
                workbook[source_sheet_name].title = temporary_name
                temporary_names[source_sheet_name] = temporary_name

        for source_sheet_name, target_sheet_name in rename_map.items():
            current_sheet_name = temporary_names.get(source_sheet_name, source_sheet_name)
            workbook[current_sheet_name].title = target_sheet_name

        template_sheet_map = []
        for logical_key, _source_sheet_name, target_sheet_name in self._TEMPLATE_SHEET_SOURCE_PLAN:
            template_sheet_map.append({
                'logical_key': logical_key,
                'sheet_name': target_sheet_name,
            })

        self._rewrite_workbook_sheet_references(workbook, rename_map)
        self._reorder_workbook_sheets(workbook, [item['sheet_name'] for item in template_sheet_map])
        return workbook, template_sheet_map

    def _rewrite_workbook_sheet_references(self, workbook, rename_map):
        if not rename_map:
            return

        for sheet in workbook.worksheets:
            for cell in sheet._cells.values():
                value = cell.value
                if isinstance(value, str) and value.startswith('='):
                    cell.value = self._replace_formula_sheet_references(value, rename_map)

        defined_names = getattr(workbook.defined_names, 'definedName', [])
        for defined_name in defined_names:
            attr_text = getattr(defined_name, 'attr_text', None)
            if isinstance(attr_text, str):
                defined_name.attr_text = self._replace_formula_sheet_references(attr_text, rename_map)

    def _replace_formula_sheet_references(self, expression, rename_map):
        updated_expression = expression
        for old_name, new_name in rename_map.items():
            old_quoted = "'%s'!" % old_name.replace("'", "''")
            new_quoted = "'%s'!" % new_name.replace("'", "''")
            updated_expression = updated_expression.replace(old_quoted, new_quoted)

            if self._sheet_name_is_unquoted_token(old_name) and self._sheet_name_is_unquoted_token(new_name):
                pattern = re.compile(r'(?<![A-Za-z0-9_.])%s!' % re.escape(old_name))
                updated_expression = pattern.sub('%s!' % new_name, updated_expression)
        return updated_expression

    def _sheet_name_is_unquoted_token(self, sheet_name):
        return bool(re.match(r'^[A-Za-z_][A-Za-z0-9_.]*$', sheet_name or ''))

    def _reorder_workbook_sheets(self, workbook, ordered_sheet_names):
        ordered_sheets = [workbook[name] for name in ordered_sheet_names if name in workbook.sheetnames]
        if len(ordered_sheets) != len(workbook.worksheets):
            remaining = [sheet for sheet in workbook.worksheets if sheet.title not in ordered_sheet_names]
            ordered_sheets.extend(remaining)
        workbook._sheets = ordered_sheets

    def _prepare_trial_balance_payload(self):
        report = self._get_report_or_raise('account_reports.trial_balance_report')
        # Trial balance export must be flat (no account-group hierarchy) and fully expanded to leaves.
        tb_overrides = {
            'hierarchy': False,
            'unfold_all': True,
            'unfolded_lines': [],
        }
        options = self._build_report_options(
            report,
            date_mode='range',
            date_from=self.date_from,
            date_to=self.date_to,
            overrides=tb_overrides,
            aged=False,
        )
        return self._build_native_report_sheet_payload(
            report=report,
            options=options,
            sheet_name='Trial Balance',
            empty_message=_('Trial Balance XLSX export returned no file content.'),
        )

    def _extract_trial_balance_amounts(self, line_columns, normalized_labels):
        value_map = {}
        numeric_values = []
        for idx, col in enumerate(line_columns):
            value = col.get('no_format')
            if not isinstance(value, (int, float)):
                continue
            numeric_value = float(value)
            label = normalized_labels[idx] if idx < len(normalized_labels) else f'col{idx}'
            value_map[label] = numeric_value
            numeric_values.append(numeric_value)

        def get_first(*keys):
            for key in keys:
                if key in value_map:
                    return value_map[key]
            return None

        debit = get_first('debit', 'perioddebit', 'currentdebit')
        credit = get_first('credit', 'periodcredit', 'currentcredit')

        ending_debit = get_first('endingdebit', 'closingdebit')
        ending_credit = get_first('endingcredit', 'closingcredit')
        balance = get_first('balance', 'endingbalance', 'totalbalance')

        if balance is None and ending_debit is not None and ending_credit is not None:
            balance = ending_debit - ending_credit

        if debit is None or credit is None:
            if len(numeric_values) >= 2:
                debit = numeric_values[-2]
                credit = numeric_values[-1]
            else:
                debit = debit or 0.0
                credit = credit or 0.0

        if balance is None:
            balance = debit - credit

        return {
            'debit': float(debit or 0.0),
            'credit': float(credit or 0.0),
            'balance': float(balance or 0.0),
        }

    def _get_report_or_raise(self, xmlid):
        report = self.env.ref(xmlid, raise_if_not_found=False)
        if not report:
            raise ValidationError(_('Accounting report not found: %s') % xmlid)
        return report.with_context(allowed_company_ids=self.company_ids.ids)

    def _build_report_options(self, report, *, date_mode, date_from, date_to, overrides=None, aged=False):
        previous_options = {
            'selected_variant_id': report.id,
            'date': {
                'filter': 'custom',
                'mode': date_mode,
                'date_from': fields.Date.to_string(date_from) if date_from else False,
                'date_to': fields.Date.to_string(date_to),
            },
            'all_entries': self.include_draft_entries,
            'unfold_all': self.unfold_all,
            'hide_0_lines': self.hide_zero_lines,
            'partner_ids': self.partner_ids.ids,
            'analytic_accounts': self.analytic_account_ids.ids,
        }
        if aged:
            previous_options.update({
                'aging_based_on': self.aging_based_on,
                'aging_interval': self.aging_interval,
                'show_currency': self.show_currency,
                'show_account': self.show_account,
            })

        options = report.get_options(previous_options=previous_options)

        if self.journal_ids and options.get('journals'):
            selected_journal_ids = set(self.journal_ids.ids)
            for journal_opt in options['journals']:
                if journal_opt.get('model') == 'account.journal':
                    journal_opt['selected'] = journal_opt.get('id') in selected_journal_ids

        if overrides:
            options = self._deep_merge_dict(options, overrides)

        options['report_id'] = report.id
        return options

    def _deep_merge_dict(self, base_dict, patch_dict):
        result = dict(base_dict)
        for key, value in patch_dict.items():
            if isinstance(value, dict) and isinstance(result.get(key), dict):
                result[key] = self._deep_merge_dict(result[key], value)
            else:
                result[key] = value
        return result

    def _build_native_report_sheet_payload(self, *, report, options, sheet_name, empty_message):
        export_data = report.export_to_xlsx(options)
        file_content = export_data.get('file_content')
        if not file_content:
            raise ValidationError(empty_message)

        try:
            source_workbook = load_workbook(io.BytesIO(file_content), data_only=False)
        except Exception as exc:
            report_name = report.display_name or report.name or report._name
            raise ValidationError(
                _('Unable to read native XLSX export for %(report)s: %(error)s', report=report_name, error=str(exc) or repr(exc))
            ) from exc

        if not source_workbook.sheetnames:
            raise ValidationError(_('Native XLSX export did not contain any sheet.'))

        return {
            'sheet_name': sheet_name,
            'native_source_sheet': source_workbook[source_workbook.sheetnames[0]],
        }

    def _prepare_general_ledger_payload(self, overrides):
        report = self._get_report_or_raise('account_reports.general_ledger_report')
        options = self._build_report_options(
            report,
            date_mode='range',
            date_from=self.date_from,
            date_to=self.date_to,
            overrides=overrides,
            aged=False,
        )
        return self._build_native_report_sheet_payload(
            report=report,
            options=options,
            sheet_name='General Ledger',
            empty_message=_('General Ledger XLSX export returned no file content.'),
        )

    def _prepare_aged_payload(self, *, xmlid, sheet_name, title, overrides):
        report = self._get_report_or_raise(xmlid)
        options = self._build_report_options(
            report,
            date_mode='single',
            date_from=self.aged_as_of_date,
            date_to=self.aged_as_of_date,
            overrides=overrides,
            aged=True,
        )
        return self._build_native_report_sheet_payload(
            report=report,
            options=options,
            sheet_name=sheet_name,
            empty_message=_('%s XLSX export returned no file content.') % title,
        )

    def _prepare_invoice_bill_payload(self, *, is_customer):
        move_model = self.env['account.move'].with_context(allowed_company_ids=self.company_ids.ids)

        move_types = ['out_invoice'] if is_customer else ['in_invoice']
        if self.include_refunds:
            move_types += ['out_refund'] if is_customer else ['in_refund']

        domain = [
            ('move_type', 'in', move_types),
            ('company_id', 'in', self.company_ids.ids),
            ('invoice_date', '>=', self.date_from),
            ('invoice_date', '<=', self.date_to),
        ]

        state_scope = self._get_invoice_bill_states()
        if state_scope:
            domain.append(('state', 'in', state_scope))

        if self.journal_ids:
            domain.append(('journal_id', 'in', self.journal_ids.ids))
        if self.partner_ids:
            domain.append(('partner_id', 'in', self.partner_ids.ids))

        moves = move_model.search(domain, order='invoice_date, id')

        move_type_labels = dict(self.env['account.move']._fields['move_type'].selection)
        state_labels = dict(self.env['account.move']._fields['state'].selection)
        payment_state_labels = dict(self.env['account.move']._fields['payment_state'].selection)

        fixed_headers = [
            'Document Number',
            'Type',
            'State',
            'Payment State',
            'Partner',
            'Invoice Date',
            'Due Date',
            'Journal',
            'Currency',
            'Untaxed Amount',
            'Tax Amount',
            'Total Amount',
            'Residual Amount',
            'Reference',
            'Company',
        ]

        dynamic_columns = []
        if self.include_dynamic_columns:
            dynamic_columns = [
                ('Salesperson', lambda move: move.invoice_user_id.display_name or ''),
                ('Payment Terms', lambda move: move.invoice_payment_term_id.display_name or ''),
                ('Invoice Origin', lambda move: move.invoice_origin or ''),
                ('Fiscal Position', lambda move: move.fiscal_position_id.display_name or ''),
                ('Auto Post', lambda move: move.auto_post or ''),
            ]
            fixed_headers.extend([name for name, _func in dynamic_columns])

        fixed_rows = []
        for move in moves:
            row = [
                move.name or '',
                move_type_labels.get(move.move_type, move.move_type or ''),
                state_labels.get(move.state, move.state or ''),
                payment_state_labels.get(move.payment_state, move.payment_state or ''),
                move.partner_id.display_name or '',
                move.invoice_date,
                move.invoice_date_due,
                move.journal_id.display_name or '',
                move.currency_id.name or '',
                move.amount_untaxed_signed,
                move.amount_tax_signed,
                move.amount_total_signed,
                move.amount_residual_signed,
                move.ref or '',
                move.company_id.name or '',
            ]
            for _name, getter in dynamic_columns:
                row.append(getter(move))
            fixed_rows.append(row)

        sections = [{
            'section_title': 'Fixed Table - Document Headers',
            'headers': fixed_headers,
            'rows': fixed_rows,
            'column_types': {
                5: 'date',
                6: 'date',
                9: 'number',
                10: 'number',
                11: 'number',
                12: 'number',
            },
            'total_columns': {9, 10, 11, 12},
        }]

        title = 'Customer Invoices' if is_customer else 'Vendor Bills'
        scope_label = {
            'all_states': 'All States',
            'posted_only': 'Posted Only',
            'posted_cancelled': 'Posted + Cancelled',
        }.get(self.invoice_bill_scope, self.invoice_bill_scope)

        metadata = self._build_sheet_metadata(title)
        metadata.append(('Invoice/Bill State Scope', scope_label))
        metadata.append(('Refunds Included', 'Yes' if self.include_refunds else 'No'))

        return {
            'sheet_name': title,
            'title': title,
            'metadata': metadata,
            'sections': sections,
        }

    def _get_invoice_bill_states(self):
        if self.invoice_bill_scope == 'posted_only':
            return ['posted']
        if self.invoice_bill_scope == 'posted_cancelled':
            return ['posted', 'cancel']
        return ['draft', 'posted', 'cancel']

    def _build_dynamic_section(self, lines, options, *, section_title):
        dynamic_headers = ['Level', 'Line Name'] + [
            col.get('name') or col.get('expression_label') or _('Column')
            for col in options.get('columns', [])
        ]
        dynamic_rows = []

        for line in lines:
            row = [
                line.get('level') or 0,
                self._clean_line_name(line.get('name') or ''),
            ]
            for col in line.get('columns', []):
                value = col.get('no_format')
                if value is None:
                    value = col.get('name')
                row.append(value)
            dynamic_rows.append(row)

        return {
            'section_title': section_title,
            'headers': dynamic_headers,
            'rows': dynamic_rows,
            'column_types': {
                0: 'number',
            },
            'total_columns': set(),
        }

    def _clean_line_name(self, line_name):
        if not line_name:
            return ''
        if '<' in line_name and '>' in line_name:
            return html2plaintext(line_name)
        return line_name

    def _build_sheet_metadata(self, sheet_label, options=None):
        journals = ', '.join(self.journal_ids.mapped('display_name')) if self.journal_ids else 'All'
        partners = ', '.join(self.partner_ids.mapped('display_name')) if self.partner_ids else 'All'
        analytics = ', '.join(self.analytic_account_ids.mapped('name')) if self.analytic_account_ids else 'All'

        metadata = [
            ('Report', sheet_label),
            ('Companies', ', '.join(self.company_ids.mapped('name'))),
            ('Date Range', f"{fields.Date.to_string(self.date_from)} to {fields.Date.to_string(self.date_to)}"),
            ('Aged As Of Date', fields.Date.to_string(self.aged_as_of_date)),
            ('Journals', journals),
            ('Partners', partners),
            ('Analytic Accounts', analytics),
            ('Include Draft Entries', 'Yes' if self.include_draft_entries else 'No'),
            ('Unfold All', 'Yes' if self.unfold_all else 'No'),
            ('Hide Zero Lines', 'Yes' if self.hide_zero_lines else 'No'),
            ('Generated At', fields.Datetime.to_string(fields.Datetime.now())),
            ('Generated By', self.env.user.name),
        ]

        if options and options.get('warnings'):
            metadata.append(('Warnings', ', '.join(sorted(options['warnings'].keys()))))

        return metadata

    def _get_plain_styles(self):
        thin_side = Side(style='thin', color='D9D9D9')
        thin_border = Border(left=thin_side, right=thin_side, top=thin_side, bottom=thin_side)
        return {
            'title_font': Font(size=13, bold=True),
            'section_fill': PatternFill(fill_type='solid', fgColor='F2F2F2'),
            'header_font': Font(bold=True),
            'meta_key_font': Font(bold=True),
            'center': Alignment(horizontal='center', vertical='center', wrap_text=True),
            'left': Alignment(horizontal='left', vertical='center', wrap_text=False),
            'number': Alignment(horizontal='right', vertical='center'),
            'border': thin_border,
        }

    def _write_plain_sheet(self, workbook, used_sheet_names, *, insert_index, sheet_name, title, metadata, sections):
        styles = self._get_plain_styles()
        sheet = workbook.create_sheet(title=self._get_unique_sheet_name(sheet_name, used_sheet_names), index=insert_index)

        max_columns = max([2] + [len(section.get('headers', [])) for section in sections])
        row = 1
        col_widths = {}

        def track_width(col_idx, value):
            text = '' if value is None else str(value)
            col_widths[col_idx] = max(col_widths.get(col_idx, 0), len(text))

        sheet.merge_cells(start_row=row, start_column=1, end_row=row, end_column=max_columns)
        title_cell = sheet.cell(row=row, column=1, value=title)
        title_cell.font = styles['title_font']
        title_cell.alignment = styles['left']
        track_width(1, title)
        row += 1

        for key, value in metadata:
            key_cell = sheet.cell(row=row, column=1, value=key)
            key_cell.font = styles['meta_key_font']
            key_cell.alignment = styles['left']
            key_cell.border = styles['border']

            sheet.merge_cells(start_row=row, start_column=2, end_row=row, end_column=max_columns)
            value_cell = sheet.cell(row=row, column=2, value=value or '')
            value_cell.alignment = styles['left']
            value_cell.border = styles['border']

            track_width(1, key)
            track_width(2, value)
            row += 1

        row += 1
        first_header_row = None

        for section in sections:
            headers = section.get('headers', [])
            rows = section.get('rows', [])
            section_title = section.get('section_title') or _('Section')
            column_types = section.get('column_types', {})
            total_columns = section.get('total_columns', set())

            if not headers:
                continue

            sheet.merge_cells(start_row=row, start_column=1, end_row=row, end_column=len(headers))
            section_cell = sheet.cell(row=row, column=1, value=section_title)
            section_cell.font = styles['header_font']
            section_cell.fill = styles['section_fill']
            section_cell.alignment = styles['left']
            section_cell.border = styles['border']
            track_width(1, section_title)
            row += 1

            header_row = row
            if first_header_row is None:
                first_header_row = header_row

            for col_idx, header in enumerate(headers, start=1):
                cell = sheet.cell(row=row, column=col_idx, value=header)
                cell.font = styles['header_font']
                cell.fill = styles['section_fill']
                cell.alignment = styles['center']
                cell.border = styles['border']
                track_width(col_idx, header)
            row += 1

            data_start_row = row
            if not rows:
                sheet.merge_cells(start_row=row, start_column=1, end_row=row, end_column=len(headers))
                no_data_cell = sheet.cell(row=row, column=1, value=_('No data'))
                no_data_cell.alignment = styles['left']
                no_data_cell.border = styles['border']
                track_width(1, _('No data'))
                row += 1
                data_end_row = row - 1
            else:
                for line in rows:
                    for col_idx, cell_value in enumerate(line, start=1):
                        cell = sheet.cell(row=row, column=col_idx)
                        col_type = column_types.get(col_idx - 1)

                        if col_type == 'number' and isinstance(cell_value, (int, float)):
                            cell.value = float(cell_value)
                            cell.number_format = '#,##0.00'
                            cell.alignment = styles['number']
                        elif col_type == 'date':
                            if isinstance(cell_value, datetime.datetime):
                                cell.value = cell_value
                                cell.number_format = 'yyyy-mm-dd'
                                cell.alignment = styles['center']
                            elif isinstance(cell_value, datetime.date):
                                cell.value = datetime.datetime.combine(cell_value, datetime.time.min)
                                cell.number_format = 'yyyy-mm-dd'
                                cell.alignment = styles['center']
                            else:
                                cell.value = cell_value or ''
                                cell.alignment = styles['left']
                        elif isinstance(cell_value, (int, float)):
                            cell.value = float(cell_value)
                            cell.alignment = styles['number']
                        else:
                            cell.value = cell_value or ''
                            cell.alignment = styles['left']

                        cell.border = styles['border']
                        track_width(col_idx, cell_value)
                    row += 1
                data_end_row = row - 1

                if total_columns:
                    for col_idx in range(1, len(headers) + 1):
                        cell = sheet.cell(row=row, column=col_idx)
                        cell.border = styles['border']
                        cell.font = styles['header_font']
                        if col_idx == 1:
                            cell.value = _('Total')
                            cell.alignment = styles['left']
                            track_width(col_idx, _('Total'))
                        elif (col_idx - 1) in total_columns:
                            col_letter = get_column_letter(col_idx)
                            cell.value = f'=SUM({col_letter}{data_start_row}:{col_letter}{data_end_row})'
                            cell.number_format = '#,##0.00'
                            cell.alignment = styles['number']
                        else:
                            cell.value = ''
                            cell.alignment = styles['left']
                    row += 1

            sheet.auto_filter.ref = f"A{header_row}:{get_column_letter(len(headers))}{max(data_end_row, header_row)}"
            row += 1

        if first_header_row is not None:
            sheet.freeze_panes = f"A{first_header_row + 1}"

        for col_idx, width in col_widths.items():
            sheet.column_dimensions[get_column_letter(col_idx)].width = min(max(width + 2, 10), 48)

    def _write_native_sheet_copy(self, workbook, used_sheet_names, *, insert_index, sheet_name, source_sheet):
        target_sheet = workbook.create_sheet(
            title=self._get_unique_sheet_name(sheet_name, used_sheet_names),
            index=insert_index,
        )

        for src_row in source_sheet.iter_rows(
            min_row=1,
            max_row=source_sheet.max_row,
            min_col=1,
            max_col=source_sheet.max_column,
        ):
            for src_cell in src_row:
                if src_cell.value is None and not src_cell.has_style and not src_cell.comment and not src_cell.hyperlink:
                    continue

                dst_cell = target_sheet.cell(
                    row=src_cell.row,
                    column=src_cell.column,
                    value=src_cell.value,
                )
                if src_cell.has_style:
                    dst_cell.font = copy(src_cell.font)
                    dst_cell.fill = copy(src_cell.fill)
                    dst_cell.border = copy(src_cell.border)
                    dst_cell.alignment = copy(src_cell.alignment)
                    dst_cell.number_format = src_cell.number_format
                    dst_cell.protection = copy(src_cell.protection)
                if src_cell.comment:
                    dst_cell.comment = copy(src_cell.comment)
                if src_cell.hyperlink:
                    dst_cell._hyperlink = copy(src_cell.hyperlink)

        for merged_range in source_sheet.merged_cells.ranges:
            target_sheet.merge_cells(str(merged_range))

        for col_key, source_dimension in source_sheet.column_dimensions.items():
            target_dimension = target_sheet.column_dimensions[col_key]
            target_dimension.width = source_dimension.width
            target_dimension.hidden = source_dimension.hidden
            target_dimension.bestFit = source_dimension.bestFit
            target_dimension.outlineLevel = source_dimension.outlineLevel
            target_dimension.collapsed = source_dimension.collapsed

        for row_key, source_dimension in source_sheet.row_dimensions.items():
            target_dimension = target_sheet.row_dimensions[row_key]
            target_dimension.height = source_dimension.height
            target_dimension.hidden = source_dimension.hidden
            target_dimension.outlineLevel = source_dimension.outlineLevel
            target_dimension.collapsed = source_dimension.collapsed

        target_sheet.freeze_panes = source_sheet.freeze_panes
        if source_sheet.auto_filter and source_sheet.auto_filter.ref:
            target_sheet.auto_filter.ref = source_sheet.auto_filter.ref
        return target_sheet.title

    def _write_trial_balance_to_template_sheet(self, sheet, trial_balance_payload):
        styles = self._get_plain_styles()
        headers = trial_balance_payload['headers']
        rows = trial_balance_payload['rows']
        start_row = 6

        # Clear previous static values in the write area while preserving formulas.
        max_row = max(sheet.max_row, start_row + 1)
        for row in sheet.iter_rows(min_row=start_row, max_row=max_row, min_col=1, max_col=len(headers)):
            for cell in row:
                if isinstance(cell.value, str) and cell.value.startswith('='):
                    continue
                cell.value = None

        for col_idx, header in enumerate(headers, start=1):
            cell = sheet.cell(row=start_row, column=col_idx, value=header)
            cell.font = styles['header_font']
            cell.fill = styles['section_fill']
            cell.alignment = styles['center']
            cell.border = styles['border']

        write_row = start_row + 1
        if not rows:
            cell = sheet.cell(row=write_row, column=1, value=_('No data'))
            cell.alignment = styles['left']
            cell.border = styles['border']
            return

        for row_values in rows:
            for col_idx, value in enumerate(row_values, start=1):
                cell = sheet.cell(row=write_row, column=col_idx, value=value)
                cell.border = styles['border']
                if col_idx >= 3 and isinstance(value, (int, float)):
                    cell.number_format = '#,##0.00'
                    cell.alignment = styles['number']
                elif col_idx == 1:
                    cell.alignment = styles['center']
                else:
                    cell.alignment = styles['left']
            write_row += 1

        total_row = write_row
        total_label = sheet.cell(row=total_row, column=1, value=_('Total'))
        total_label.font = styles['header_font']
        total_label.alignment = styles['left']
        total_label.border = styles['border']
        for col_idx in range(2, len(headers) + 1):
            cell = sheet.cell(row=total_row, column=col_idx)
            cell.font = styles['header_font']
            cell.border = styles['border']
            if col_idx >= 3:
                letter = get_column_letter(col_idx)
                cell.value = f'=SUM({letter}{start_row + 1}:{letter}{write_row - 1})'
                cell.number_format = '#,##0.00'
                cell.alignment = styles['number']
            else:
                cell.value = ''
                cell.alignment = styles['left']

        sheet.auto_filter.ref = f"A{start_row}:{get_column_letter(len(headers))}{write_row - 1}"
        sheet.freeze_panes = f"A{start_row + 1}"
        sheet.column_dimensions['A'].width = max(sheet.column_dimensions['A'].width or 0, 16)
        sheet.column_dimensions['B'].width = max(sheet.column_dimensions['B'].width or 0, 32)
        sheet.column_dimensions['C'].width = max(sheet.column_dimensions['C'].width or 0, 14)
        sheet.column_dimensions['D'].width = max(sheet.column_dimensions['D'].width or 0, 14)
        sheet.column_dimensions['E'].width = max(sheet.column_dimensions['E'].width or 0, 14)

    def _cleanup_template_sheet_inputs(self, sheet):
        for cell in sheet._cells.values():
            value = cell.value
            if value is None:
                continue
            if isinstance(value, str) and value.startswith('='):
                continue
            if isinstance(value, (int, float, bool, datetime.date, datetime.datetime)):
                cell.value = None
                continue
            if isinstance(value, str) and value.strip().lower() in {'0', '0.0', '0.00', 'n/a', 'na'}:
                cell.value = None

    def _normalize_key(self, value):
        return ''.join(ch for ch in (value or '').strip().lower() if ch.isalnum())

    def _get_template_sheet_styles(self):
        thin_side = Side(style='thin', color='D9D9D9')
        thin_border = Border(left=thin_side, right=thin_side, top=thin_side, bottom=thin_side)
        return {
            'title_font': Font(size=13, bold=True, color='FFFFFF'),
            'subtitle_font': Font(size=11, italic=True, color='595959'),
            'title_fill': PatternFill(fill_type='solid', fgColor='1F4E78'),
            'header_font': Font(bold=True, color='FFFFFF'),
            'header_fill': PatternFill(fill_type='solid', fgColor='2F5597'),
            'label_font': Font(bold=True),
            'border': thin_border,
            'left': Alignment(horizontal='left', vertical='center'),
            'center': Alignment(horizontal='center', vertical='center'),
            'right': Alignment(horizontal='right', vertical='center'),
        }

    def _init_template_sheet(self, sheet, *, title, subtitle_formula=None, with_client_ref=True):
        styles = self._get_template_sheet_styles()
        sheet.page_setup.orientation = 'landscape'
        sheet.page_setup.fitToWidth = 1
        sheet.page_setup.fitToHeight = 0
        sheet.column_dimensions['A'].width = 42
        sheet.column_dimensions['B'].width = 18
        sheet.column_dimensions['C'].width = 18
        sheet.column_dimensions['D'].width = 18
        sheet.column_dimensions['E'].width = 18
        sheet.row_dimensions[2].height = 28
        sheet.merge_cells('A2:E2')
        title_cell = sheet['A2']
        title_cell.value = title
        title_cell.font = styles['title_font']
        title_cell.fill = styles['title_fill']
        title_cell.alignment = styles['left']
        title_cell.border = styles['border']
        if with_client_ref:
            sheet['A1'] = "='Client Details'!B4"
        if subtitle_formula:
            sheet.merge_cells('A4:E4')
            subtitle_cell = sheet['A4']
            subtitle_cell.value = subtitle_formula
            subtitle_cell.font = styles['subtitle_font']
            subtitle_cell.alignment = styles['left']

    def _apply_template_header_row(self, sheet, row, headers):
        styles = self._get_template_sheet_styles()
        for col_index, header in enumerate(headers, start=1):
            cell = sheet.cell(row=row, column=col_index, value=header)
            cell.font = styles['header_font']
            cell.fill = styles['header_fill']
            cell.alignment = styles['center']
            cell.border = styles['border']

    def _build_template_client_details_sheet(self, sheet):
        self._init_template_sheet(sheet, title='Client Details', with_client_ref=False)
        sheet['A1'] = 'Client Details'
        labels = [
            (4, 'Client Name'),
            (5, 'Period Start Date'),
            (6, 'Period End Date'),
            (8, 'Trade License Number'),
            (9, 'Freezone / Mainland'),
            (10, 'Company Formation Date'),
            (11, 'License Expiry Date'),
            (12, 'Business Activities'),
            (13, 'Owner Names'),
            (15, 'Corporate Tax Registration Number'),
            (16, 'VAT Registration Number'),
        ]
        styles = self._get_template_sheet_styles()
        for row, label in labels:
            cell = sheet.cell(row=row, column=1, value=label)
            cell.font = styles['label_font']
            cell.alignment = styles['left']
            cell.border = styles['border']
            sheet.cell(row=row, column=2, value='')
            sheet.cell(row=row, column=2).border = styles['border']
        sheet['A18'] = 'Client Name Copy'
        sheet['B18'] = '=IF(B4="","",B4)'

    def _build_template_summary_sheet(self, sheet):
        self._init_template_sheet(
            sheet,
            title='Summary Sheet',
            subtitle_formula='=IF(OR(\'Client Details\'!B5="",\'Client Details\'!B6=""),"",TEXT(\'Client Details\'!B5,"DD mmmm YYYY")&" - "&TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))',
        )
        self._apply_template_header_row(sheet, 6, ['Description', 'Amount (AED)'])
        rows = [
            (7, 'Total Revenue', '=SOCI!B8'),
            (8, 'Total Expenses (Excluding Director Salary)', '=SOCI!B27'),
            (9, 'Director Salary', '=SOCI!B16'),
            (10, 'Profit / (Loss)', '=SOCI!B31'),
            (11, 'Total Assets', '=SOFP!B17'),
            (12, 'Total Liabilities', '=SOFP!B30'),
            (13, 'Total Equity', '=SOFP!B24'),
            (15, 'Related Party Revenue', '=SOCI!B9'),
            (16, 'Related Party Loan', '=SOFP!B23'),
            (17, 'Interest Income', '=SOCI!B29'),
            (18, 'Dividend Income', '=0'),
        ]
        styles = self._get_template_sheet_styles()
        for row, label, formula in rows:
            sheet.cell(row=row, column=1, value=label).border = styles['border']
            value_cell = sheet.cell(row=row, column=2, value=formula)
            value_cell.number_format = '#,##0.00'
            value_cell.alignment = styles['right']
            value_cell.border = styles['border']

    def _build_template_sofp_sheet(self, sheet):
        self._init_template_sheet(
            sheet,
            title='SOFP',
            subtitle_formula='=IF(\'Client Details\'!B6="","","As at " & TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))',
        )
        self._apply_template_header_row(sheet, 6, ['', 'Current Year', 'Prior Year'])
        sheet['B6'] = '=IF(\'Client Details\'!B6="","",TEXT(\'Client Details\'!B6,"YYYY"))'
        sheet['C6'] = '=IF(B6="","",B6-1)'
        entries = [
            (7, 'Assets:'),
            (8, 'Non-current assets'),
            (9, 'Property, plant and equipment'),
            (10, 'Total non-current assets'),
            (11, 'Current assets'),
            (12, 'Accounts receivable'),
            (13, 'Prepayment'),
            (14, 'VAT recoverable'),
            (15, 'Cash and bank balances'),
            (16, 'Total current assets'),
            (17, 'Total assets'),
            (19, 'Equity and Liabilities:'),
            (20, 'Equity'),
            (21, 'Share capital'),
            (22, 'Retained earnings'),
            (23, 'Owner current account'),
            (24, 'Total Equity'),
            (25, 'Non-current liabilities'),
            (26, 'Long-term loans'),
            (27, 'Current liabilities'),
            (28, 'Audit and accounting accrual'),
            (29, 'VAT payable'),
            (30, 'Total Liabilities'),
            (31, 'Total Equity and Liabilities'),
            (33, 'Difference (Should be 0)'),
        ]
        formulas = {
            'B10': '=SUM(B8:B9)', 'C10': '=SUM(C8:C9)',
            'B16': '=SUM(B11:B15)', 'C16': '=SUM(C11:C15)',
            'B17': '=B16+B10', 'C17': '=C16+C10',
            'B24': '=SUM(B21:B23)', 'C24': '=SUM(C21:C23)',
            'B30': '=SUM(B25:B29)', 'C30': '=SUM(C25:C29)',
            'B31': '=B30+B24', 'C31': '=C30+C24',
            'B33': '=B31-B17',
        }
        styles = self._get_template_sheet_styles()
        for row, label in entries:
            sheet.cell(row=row, column=1, value=label).border = styles['border']
            sheet.cell(row=row, column=2).border = styles['border']
            sheet.cell(row=row, column=3).border = styles['border']
        for coord, formula in formulas.items():
            cell = sheet[coord]
            cell.value = formula
            cell.number_format = '#,##0.00'
            cell.alignment = styles['right']

    def _build_template_soci_sheet(self, sheet):
        self._init_template_sheet(
            sheet,
            title='SOCI',
            subtitle_formula='=IF(\'Client Details\'!B6="","","For the year ended " & TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))',
        )
        self._apply_template_header_row(sheet, 6, ['', 'Current Year', 'Prior Year'])
        sheet['B6'] = '=IF(\'Client Details\'!B6="","",TEXT(\'Client Details\'!B6,"YYYY"))'
        sheet['C6'] = '=IF(B6="","",B6-1)'
        entries = [
            (8, 'Revenue'),
            (9, 'Revenue - related party'),
            (11, 'Direct cost'),
            (13, 'Gross profit'),
            (15, 'Operating expenses'),
            (16, 'Director salary'),
            (17, 'Salaries, wages and benefits'),
            (18, 'Advertising'),
            (19, 'Audit and accounting'),
            (20, 'Depreciation'),
            (21, 'Government fees'),
            (22, 'Insurance'),
            (23, 'Office expense'),
            (24, 'Bank charges'),
            (25, 'Exchange loss'),
            (26, 'Others'),
            (27, 'Total operating expenses'),
            (29, 'Other income'),
            (31, 'Net profit / (loss)'),
        ]
        formulas = {
            'B13': '=SUM(B9:B11)', 'C13': '=SUM(C9:C11)',
            'B27': '=SUM(B16:B26)', 'C27': '=SUM(C16:C26)',
            'B31': '=B13-B27+B29', 'C31': '=C13-C27+C29',
        }
        styles = self._get_template_sheet_styles()
        for row, label in entries:
            sheet.cell(row=row, column=1, value=label).border = styles['border']
            sheet.cell(row=row, column=2).border = styles['border']
            sheet.cell(row=row, column=3).border = styles['border']
        for coord, formula in formulas.items():
            cell = sheet[coord]
            cell.value = formula
            cell.number_format = '#,##0.00'
            cell.alignment = styles['right']

    def _build_template_soce_sheet(self, sheet):
        self._init_template_sheet(
            sheet,
            title='SOCE',
            subtitle_formula='=IF(\'Client Details\'!B6="","","For the year ended " & TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))',
        )
        self._apply_template_header_row(
            sheet,
            6,
            ['', 'Share capital', "Owner's current account", 'Retained earnings', 'Total'],
        )
        entries = [
            (7, 'Balance as at start of period'),
            (8, 'Paid up capital'),
            (9, "Movement in owner's current account"),
            (10, 'Net profit / (loss)'),
            (11, 'Transfer to reserve'),
            (12, 'Balance as at end of period'),
            (13, 'Paid up capital'),
            (14, "Movement in owner's current account"),
            (15, 'Net profit / (loss)'),
            (16, 'Transfer to reserve'),
            (17, 'Balance c/f'),
        ]
        styles = self._get_template_sheet_styles()
        for row, label in entries:
            sheet.cell(row=row, column=1, value=label).border = styles['border']
            for col in range(2, 6):
                sheet.cell(row=row, column=col).border = styles['border']
        for row in (7, 8, 9, 10, 11, 13, 14, 15, 16):
            sheet.cell(row=row, column=5, value=f'=SUM(B{row}:D{row})')
        for col in ('B', 'C', 'D', 'E'):
            sheet[f'{col}12'] = f'=SUM({col}7:{col}11)'
            sheet[f'{col}17'] = f'=SUM({col}13:{col}16)'

    def _build_template_socf_sheet(self, sheet):
        self._init_template_sheet(
            sheet,
            title='SOCF',
            subtitle_formula='=IF(\'Client Details\'!B6="","","For the year ended " & TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))',
        )
        self._apply_template_header_row(sheet, 6, ['', 'Current Year', 'Prior Year'])
        entries = [
            (8, 'Cash flows from operating activities'),
            (9, 'Net profit for the year'),
            (10, 'Operating cash flows before working capital changes'),
            (11, 'Changes in working capital'),
            (12, '(Increase) / decrease in current assets'),
            (13, 'Increase / (decrease) in current liabilities'),
            (14, 'Net cash generated from operations'),
            (15, 'Cash flows from investing activities'),
            (16, 'Property, plant and equipment'),
            (17, 'Net cash generated from investing activities'),
            (18, 'Cash flows from financing activities'),
            (19, 'Paid up capital'),
            (20, 'Owner current account'),
            (21, 'Net cash generated from financing activities'),
            (22, 'Net increase in cash and cash equivalents'),
            (23, 'Cash and cash equivalents, beginning of the period'),
            (24, 'Cash and cash equivalents, end of the period'),
        ]
        formulas = {
            'B9': '=SOCI!B31', 'C9': '=SOCI!C31',
            'B10': '=B9', 'C10': '=C9',
            'B14': '=SUM(B10:B13)', 'C14': '=SUM(C10:C13)',
            'B17': '=SUM(B15:B16)', 'C17': '=SUM(C15:C16)',
            'B21': '=SUM(B18:B20)', 'C21': '=SUM(C18:C20)',
            'B22': '=B21+B17+B14', 'C22': '=C21+C17+C14',
            'B23': '=C24',
            'B24': '=SUM(B22:B23)', 'C24': '=SUM(C22:C23)',
        }
        styles = self._get_template_sheet_styles()
        for row, label in entries:
            sheet.cell(row=row, column=1, value=label).border = styles['border']
            sheet.cell(row=row, column=2).border = styles['border']
            sheet.cell(row=row, column=3).border = styles['border']
        for coord, formula in formulas.items():
            cell = sheet[coord]
            cell.value = formula
            cell.number_format = '#,##0.00'
            cell.alignment = styles['right']

    def _build_template_prepayment_sheet(self, sheet):
        self._init_template_sheet(
            sheet,
            title='Prepayment',
            subtitle_formula='=IF(\'Client Details\'!B6="","","For the year ended " & TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))',
        )
        rows = [
            (6, 'Renewed in Current Period'),
            (7, 'License'),
            (8, 'Total Amount (AED)'),
            (9, 'Date of Issuance'),
            (10, 'Date of Expiry'),
            (11, 'Total Days'),
            (12, 'Cost Per Day'),
            (13, 'Date of bookkeeping'),
            (14, 'Days Expired'),
            (15, 'Expense'),
            (16, 'Pre-Payment'),
            (18, 'Invoice Details'),
        ]
        styles = self._get_template_sheet_styles()
        for row, label in rows:
            sheet.cell(row=row, column=1, value=label).border = styles['border']
            sheet.cell(row=row, column=2).border = styles['border']

        formulas = {
            'B8': '=SUM(F23:F26)',
            'B11': '=IF(OR(B9="",B10=""),"",B10-B9+1)',
            'B12': '=IF(B11="","",B8/B11)',
            'B13': "='Client Details'!B6",
            'B14': '=IF(OR(B13="",B9=""),"",B13-B9+1)',
            'B15': '=IF(OR(B12="",B14=""),"",B12*B14)',
            'B16': '=IF(OR(B8="",B15=""),"",B8-B15)',
        }
        for coord, formula in formulas.items():
            sheet[coord] = formula

        self._apply_template_header_row(sheet, 19, ['Inv. Date', 'Description', 'Inv No', 'Gross', 'VAT', 'Net'])
        self._apply_template_header_row(sheet, 22, ['Description', 'Quantity', 'Rate', 'Taxable Amount', 'Tax', 'Amount'])

    def _build_template_vat_control_sheet(self, sheet):
        self._init_template_sheet(
            sheet,
            title='VAT Control',
            subtitle_formula='=IF(\'Client Details\'!B6="","","For the year ended " & TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))',
        )
        self._apply_template_header_row(sheet, 6, ['Description', 'Dr.', 'Cr.', 'Balance'])
        rows = [
            (8, 'Balance b/f'),
            (10, 'Output VAT'),
            (12, 'Output VAT on uninvoiced sales'),
            (14, 'Input VAT on service invoice'),
            (16, 'Balance c/d'),
            (20, 'VAT reconciliation'),
            (22, 'VAT liability'),
            (24, 'Less: VAT adjustments'),
            (26, 'B/fwd'),
            (28, 'Current year'),
            (29, 'Output VAT on uninvoiced sales'),
            (33, 'VAT Summary'),
        ]
        styles = self._get_template_sheet_styles()
        for row, label in rows:
            sheet.cell(row=row, column=1, value=label).border = styles['border']
        formulas = {
            'B18': '=SUM(B7:B17)',
            'C18': '=SUM(C7:C17)',
            'D18': '=B18-C18',
            'B22': '=D18',
            'C22': '=SUM(B22)',
            'C27': '=SUM(B27)',
            'C31': '=SUM(C22:C29)',
            'A36': '=C10',
            'B36': '=B14',
            'C36': '=A36-B36',
            'E36': '=C36',
            'A37': '=SUM(A36:A36)',
            'B37': '=SUM(B36:B36)',
            'C37': '=SUM(C36:C36)',
            'D37': '=SUM(D36:D36)',
            'E37': '=SUM(E36:E36)',
        }
        for coord, formula in formulas.items():
            sheet[coord] = formula

    def _build_template_accruals_sheet(self, sheet):
        self._init_template_sheet(
            sheet,
            title='Accruals',
            subtitle_formula='=IF(\'Client Details\'!B6="","","For the year ended " & TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))',
        )
        self._apply_template_header_row(sheet, 6, ['Description', 'Dr.', 'Cr.'])
        rows = [
            (7, 'B/F'),
            (8, '=IF(\'Client Details\'!B6="","","Audit fees " & TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))'),
            (9, 'C/F'),
        ]
        styles = self._get_template_sheet_styles()
        for row, label in rows:
            sheet.cell(row=row, column=1, value=label).border = styles['border']
            sheet.cell(row=row, column=2).border = styles['border']
            sheet.cell(row=row, column=3).border = styles['border']
        sheet['B10'] = '=SUM(B7:B9)'
        sheet['C10'] = '=SUM(C7:C9)'

    def _build_template_share_capital_sheet(self, sheet):
        self._init_template_sheet(
            sheet,
            title='Share Capital',
            subtitle_formula='=IF(\'Client Details\'!B6="","","As at " & TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))',
        )
        self._apply_template_header_row(sheet, 6, ['Owner Name', 'No. of Shares', 'Value per Share (AED)', 'Total Share Value (AED)'])
        styles = self._get_template_sheet_styles()
        for row in range(7, 11):
            for col in range(1, 5):
                sheet.cell(row=row, column=col).border = styles['border']
            sheet[f'D{row}'] = f'=B{row}*C{row}'
        sheet['B11'] = '=SUM(B7:B10)'
        sheet['C11'] = '=SUM(C7:C10)'
        sheet['D11'] = '=SUM(D7:D10)'

    def _build_template_trial_balance_sheet(self, sheet):
        self._init_template_sheet(
            sheet,
            title='Trial Balance',
            subtitle_formula='=IF(\'Client Details\'!B6="","","For the year ended " & TEXT(\'Client Details\'!B6,"DD mmmm YYYY"))',
        )
        styles = self._get_template_sheet_styles()
        note = sheet['A5']
        note.value = 'Figures are populated by export logic.'
        note.font = styles['subtitle_font']


    def _get_unique_sheet_name(self, base_name, used_sheet_names):
        max_len = 31
        name = (base_name or 'Sheet').strip()[:max_len]
        if name not in used_sheet_names:
            used_sheet_names.add(name)
            return name

        counter = 1
        while True:
            suffix = f" ({counter})"
            candidate = f"{name[:max_len - len(suffix)]}{suffix}"
            if candidate not in used_sheet_names:
                used_sheet_names.add(candidate)
                return candidate
            counter += 1

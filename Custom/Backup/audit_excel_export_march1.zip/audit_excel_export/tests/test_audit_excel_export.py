import base64
import datetime
import io
import unittest
from unittest.mock import patch

try:
    from openpyxl import load_workbook
except ImportError:
    load_workbook = None

from odoo import Command, fields
from odoo.addons.account.tests.common import AccountTestInvoicingCommon
from odoo.tests.common import tagged


@tagged('post_install', '-at_install')
@unittest.skipUnless(load_workbook, 'openpyxl is required for XLSX assertions')
class TestAuditExcelExport(AccountTestInvoicingCommon):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

        cls.export_date_from = fields.Date.from_string('2025-01-01')
        cls.export_date_to = fields.Date.from_string('2025-12-31')
        cls.aged_as_of_date = fields.Date.from_string('2025-12-31')

        cls.customer_partner = cls.partner_a
        cls.vendor_partner = cls.partner_b

        cls.customer_invoice_posted = cls.init_invoice(
            'out_invoice',
            partner=cls.customer_partner,
            invoice_date=fields.Date.from_string('2025-01-10'),
            post=True,
            amounts=[100.0],
        )
        cls.vendor_bill_posted = cls.init_invoice(
            'in_invoice',
            partner=cls.vendor_partner,
            invoice_date=fields.Date.from_string('2025-01-14'),
            post=True,
            amounts=[80.0],
        )

    def _create_wizard(self, **overrides):
        vals = {
            'company_ids': [Command.set(self.env.company.ids)],
            'date_from': self.export_date_from,
            'date_to': self.export_date_to,
            'aged_as_of_date': self.aged_as_of_date,
            'include_draft_entries': True,
            'unfold_all': True,
            'hide_zero_lines': False,
            'aging_based_on': 'base_on_maturity_date',
            'aging_interval': 30,
            'show_currency': True,
            'show_account': True,
            'include_dynamic_columns': True,
            'invoice_bill_scope': 'all_states',
            'include_refunds': True,
            'partner_ids': [Command.set([self.customer_partner.id, self.vendor_partner.id])],
        }
        vals.update(overrides)
        return self.env['audit.excel.export.wizard'].create(vals)

    def _export_workbook(self, wizard):
        action = wizard.action_export_xlsx()
        self.assertEqual(action.get('type'), 'ir.actions.act_url')
        self.assertTrue(wizard.file_data)
        binary = base64.b64decode(wizard.file_data)
        self.assertGreater(len(binary), 0)
        wb = load_workbook(io.BytesIO(binary), data_only=False)
        return action, wb

    def _sheet_values(self, ws):
        values = []
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is not None:
                    values.append(str(cell.value))
        return values

    def _coerce_openpyxl_date(self, value):
        if isinstance(value, datetime.datetime):
            return value.date()
        return value

    def _static_numeric_like_values(self, ws):
        values = []
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 250), min_col=1, max_col=min(ws.max_column, 8)):
            for cell in row:
                value = cell.value
                if value is None:
                    continue
                if isinstance(value, str) and value.startswith('='):
                    continue
                if isinstance(value, (int, float, bool, datetime.date, datetime.datetime)):
                    values.append((cell.coordinate, value))
        return values

    def test_01_export_download_and_sheet_order(self):
        wizard = self._create_wizard()
        action, wb = self._export_workbook(wizard)

        self.assertIn('download=true', action.get('url', ''))
        self.assertTrue(wizard.file_name.endswith('.xlsx'))
        self.assertEqual(
            wb.sheetnames,
            [
                'General Ledger',
                'Customer Invoices',
                'Vendor Bills',
                'Aged Receivables',
                'Aged Payables',
                'VAT Control',
                'Prepayment',
                'Client Details',
                'Summary Sheet',
                'SOFP',
                'SOCI',
                'SOCE',
                'SOCF',
                'Share Capital',
                'Accruals',
                'Trial Balance',
            ],
        )

    def test_02_template_formulas_and_formatting_survive(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        self.assertTrue(str(wb['Summary Sheet']['A1'].value).startswith('='))
        self.assertTrue(str(wb['Summary Sheet']['B7'].value).startswith('='))
        self.assertTrue(str(wb['SOFP']['A1'].value).startswith('='))
        self.assertTrue(str(wb['VAT Control']['B18'].value).startswith('='))

        sofp = wb['SOFP']
        self.assertIn('A2:E2', {str(rng) for rng in sofp.merged_cells.ranges})
        self.assertTrue(sofp['A2'].font.bold)
        self.assertEqual(sofp.page_setup.orientation, 'landscape')
        self.assertEqual(sofp.column_dimensions['B'].width, 18.0)
        self.assertEqual(sofp.row_dimensions[2].height, 28.0)

    def test_03_first_five_sheets_have_data(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        gl_values = self._sheet_values(wb['General Ledger'])
        self.assertIn('Code', gl_values)
        self.assertIn('Account Name', gl_values)
        self.assertIn('Debit', gl_values)
        self.assertIn('Credit', gl_values)
        self.assertIn('Balance', gl_values)
        self.assertGreater(len(gl_values), 20)

        expected_markers = {
            'Customer Invoices': 'Fixed Table - Document Headers',
            'Vendor Bills': 'Fixed Table - Document Headers',
        }
        for sheet_name, marker in expected_markers.items():
            values = self._sheet_values(wb[sheet_name])
            self.assertIn(marker, values)
            self.assertGreater(len(values), 20)

        for sheet_name in ('Aged Receivables', 'Aged Payables'):
            ws = wb[sheet_name]
            values = self._sheet_values(ws)
            self.assertGreater(ws.max_row, 5)
            self.assertGreater(ws.max_column, 5)
            self.assertGreater(len(values), 20)

    def test_04_trial_balance_is_populated(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        ws = wb['Trial Balance']
        values = self._sheet_values(ws)
        self.assertIn('Code', values)
        self.assertIn('Account Name', values)
        self.assertIn('Debit', values)
        self.assertIn('Credit', values)
        self.assertIn('Balance', values)

        has_numeric_tb_rows = any(
            isinstance(cell.value, (int, float)) and abs(cell.value) > 0
            for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 300), min_col=1, max_col=min(ws.max_column, 12))
            for cell in row
        )
        self.assertTrue(has_numeric_tb_rows)

    def test_05_client_details_are_populated(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        ws = wb['Client Details']
        self.assertEqual(ws['B4'].value, self.env.company.name)
        self.assertEqual(self._coerce_openpyxl_date(ws['B5'].value), self.export_date_from)
        self.assertEqual(self._coerce_openpyxl_date(ws['B6'].value), self.export_date_to)

    def test_06_share_capital_rows_are_populated_when_company_data_exists(self):
        self.env.company.write({
            'shareholder_1': 'Owner A',
            'number_of_shares_1': 100,
            'share_value_1': 10.0,
        })

        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        ws = wb['Share Capital']
        self.assertEqual(ws['A7'].value, 'Owner A')
        self.assertEqual(ws['B7'].value, 100)
        self.assertEqual(ws['C7'].value, 10.0)

    def test_07_non_tb_template_sheets_have_no_static_numeric_samples(self):
        wizard = self._create_wizard()
        _action, wb = self._export_workbook(wizard)

        non_tb_template_sheets = [
            'VAT Control',
            'Prepayment',
            'Summary Sheet',
            'SOFP',
            'SOCI',
            'SOCE',
            'SOCF',
            'Accruals',
        ]

        for sheet_name in non_tb_template_sheets:
            ws = wb[sheet_name]
            static_values = self._static_numeric_like_values(ws)
            self.assertFalse(static_values, f'Static sample numeric values found on {sheet_name}: {static_values[:5]}')

    def test_08_trial_balance_forces_flat_unfolded_options(self):
        wizard = self._create_wizard(unfold_all=False)

        with patch.object(type(wizard), '_build_native_report_sheet_payload', autospec=True, return_value={}) as mocked_builder:
            wizard._prepare_trial_balance_payload()

        options = mocked_builder.call_args.kwargs['options']
        self.assertFalse(options.get('hierarchy'))
        self.assertTrue(options.get('unfold_all'))
        self.assertEqual(options.get('unfolded_lines'), [])

import csv
from io import BytesIO
import json
import logging
import os
from datetime import date as py_date, datetime as py_datetime, time as py_time
from dateutil.relativedelta import relativedelta
from odoo import models, fields, api
from odoo.exceptions import ValidationError

try:
    from openpyxl import load_workbook
except Exception:  # pragma: no cover - handled at runtime with a validation error
    load_workbook = None

_logger = logging.getLogger(__name__)


class AuditReport(models.TransientModel):
    _name = 'audit.report'
    _description = 'Audit Report'

    date_start = fields.Date(string='Date Start', required=True)
    date_end = fields.Date(string='Date End', required=True)
    balance_sheet_date_mode = fields.Selection(
        [
            ('end_only', 'End date only (snapshot)'),
            ('range', 'Date range (start to end)'),
        ],
        string='Balance Sheet Dates',
        required=True,
        default='end_only',
    )
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company,
    )
    company_name = fields.Char(related='company_id.name', readonly=False)
    company_street = fields.Char(related='company_id.street', readonly=False)
    company_street2 = fields.Char(related='company_id.street2', readonly=False)
    company_city = fields.Char(related='company_id.city', readonly=False)
    company_state_id = fields.Many2one(related='company_id.state_id', readonly=False)
    company_zip = fields.Char(related='company_id.zip', readonly=False)
    company_country_id = fields.Many2one(related='company_id.country_id', readonly=False)
    company_free_zone = fields.Selection(related='company_id.free_zone', readonly=False)
    company_license_number = fields.Char(related='company_id.company_license_number', readonly=False)
    trade_license_activities = fields.Text(related='company_id.trade_license_activities', readonly=False)
    incorporation_date = fields.Date(related='company_id.incorporation_date', readonly=False)
    corporate_tax_registration_number = fields.Char(
        related='company_id.corporate_tax_registration_number',
        readonly=False,
    )
    vat_registration_number = fields.Char(
        related='company_id.vat_registration_number',
        readonly=False,
    )
    corporate_tax_start_date = fields.Date(
        related='company_id.corporate_tax_start_date',
        readonly=False,
    )
    corporate_tax_end_date = fields.Date(
        related='company_id.corporate_tax_end_date',
        readonly=False,
    )
    implementing_regulations_freezone = fields.Text(
        related='company_id.implementing_regulations_freezone',
        readonly=False,
    )

    @api.onchange('company_free_zone')
    def _onchange_company_free_zone(self):
        if not self.company_free_zone or not self.company_id:
            return
        if hasattr(self.company_id, '_get_free_zone_implementing_regulations'):
            mapped = self.company_id._get_free_zone_implementing_regulations(self.company_free_zone)
            if mapped:
                self.implementing_regulations_freezone = mapped
    shareholder_1 = fields.Char(related='company_id.shareholder_1', readonly=False)
    shareholder_2 = fields.Char(related='company_id.shareholder_2', readonly=False)
    shareholder_3 = fields.Char(related='company_id.shareholder_3', readonly=False)
    shareholder_4 = fields.Char(related='company_id.shareholder_4', readonly=False)
    shareholder_5 = fields.Char(related='company_id.shareholder_5', readonly=False)
    shareholder_6 = fields.Char(related='company_id.shareholder_6', readonly=False)
    shareholder_7 = fields.Char(related='company_id.shareholder_7', readonly=False)
    shareholder_8 = fields.Char(related='company_id.shareholder_8', readonly=False)
    shareholder_9 = fields.Char(related='company_id.shareholder_9', readonly=False)
    shareholder_10 = fields.Char(related='company_id.shareholder_10', readonly=False)

    nationality_1 = fields.Char(related='company_id.nationality_1', readonly=False)
    nationality_2 = fields.Char(related='company_id.nationality_2', readonly=False)
    nationality_3 = fields.Char(related='company_id.nationality_3', readonly=False)
    nationality_4 = fields.Char(related='company_id.nationality_4', readonly=False)
    nationality_5 = fields.Char(related='company_id.nationality_5', readonly=False)
    nationality_6 = fields.Char(related='company_id.nationality_6', readonly=False)
    nationality_7 = fields.Char(related='company_id.nationality_7', readonly=False)
    nationality_8 = fields.Char(related='company_id.nationality_8', readonly=False)
    nationality_9 = fields.Char(related='company_id.nationality_9', readonly=False)
    nationality_10 = fields.Char(related='company_id.nationality_10', readonly=False)

    number_of_shares_1 = fields.Integer(related='company_id.number_of_shares_1', readonly=False)
    number_of_shares_2 = fields.Integer(related='company_id.number_of_shares_2', readonly=False)
    number_of_shares_3 = fields.Integer(related='company_id.number_of_shares_3', readonly=False)
    number_of_shares_4 = fields.Integer(related='company_id.number_of_shares_4', readonly=False)
    number_of_shares_5 = fields.Integer(related='company_id.number_of_shares_5', readonly=False)
    number_of_shares_6 = fields.Integer(related='company_id.number_of_shares_6', readonly=False)
    number_of_shares_7 = fields.Integer(related='company_id.number_of_shares_7', readonly=False)
    number_of_shares_8 = fields.Integer(related='company_id.number_of_shares_8', readonly=False)
    number_of_shares_9 = fields.Integer(related='company_id.number_of_shares_9', readonly=False)
    number_of_shares_10 = fields.Integer(related='company_id.number_of_shares_10', readonly=False)

    share_value_1 = fields.Float(related='company_id.share_value_1', readonly=False)
    share_value_2 = fields.Float(related='company_id.share_value_2', readonly=False)
    share_value_3 = fields.Float(related='company_id.share_value_3', readonly=False)
    share_value_4 = fields.Float(related='company_id.share_value_4', readonly=False)
    share_value_5 = fields.Float(related='company_id.share_value_5', readonly=False)
    share_value_6 = fields.Float(related='company_id.share_value_6', readonly=False)
    share_value_7 = fields.Float(related='company_id.share_value_7', readonly=False)
    share_value_8 = fields.Float(related='company_id.share_value_8', readonly=False)
    share_value_9 = fields.Float(related='company_id.share_value_9', readonly=False)
    share_value_10 = fields.Float(related='company_id.share_value_10', readonly=False)

    total_share_1 = fields.Float(related='company_id.total_share_1', readonly=True)
    total_share_2 = fields.Float(related='company_id.total_share_2', readonly=True)
    total_share_3 = fields.Float(related='company_id.total_share_3', readonly=True)
    total_share_4 = fields.Float(related='company_id.total_share_4', readonly=True)
    total_share_5 = fields.Float(related='company_id.total_share_5', readonly=True)
    total_share_6 = fields.Float(related='company_id.total_share_6', readonly=True)
    total_share_7 = fields.Float(related='company_id.total_share_7', readonly=True)
    total_share_8 = fields.Float(related='company_id.total_share_8', readonly=True)
    total_share_9 = fields.Float(related='company_id.total_share_9', readonly=True)
    total_share_10 = fields.Float(related='company_id.total_share_10', readonly=True)
    auditor_type = fields.Selection(
        [
            ('default', 'Default'),
            ('ifza', 'IFZA'),
            ('dmcc', 'DMCC'),
        ],
        string='Freezone City',
        required=True,
        default='default',
    )
    report_type = fields.Selection(
        [
            ('period', 'Financial Statements for the Period Ended'),
            ('year', 'Financial Statements for the Year Ended'),
            ('management', 'Management Accounts for the Period Ended'),
        ],
        string='Report Type',
        required=True,
        default='period',
    )
    show_related_parties_note = fields.Boolean(
        string='Show related parties note',
        default=False,
    )
    gap_report_of_directors = fields.Boolean(
        string='Gap in report of directors',
        default=True,
    )
    gap_independent_auditor_report = fields.Boolean(
        string='Gap in independent auditor report',
        default=True,
    )
    gap_notes_to_financial_statements = fields.Boolean(
        string='Gap in notes to financial statements',
        default=True,
    )
    signature_break_lines_report_of_directors = fields.Integer(
        string='Break lines (Report of Directors)',
        default=5,
    )
    signature_break_lines_balance_sheet = fields.Integer(
        string='Break lines (Statement of financial position)',
        default=5,
    )
    signature_break_lines_profit_loss = fields.Integer(
        string='Break lines (Statement of profit and loss)',
        default=5,
    )
    signature_break_lines_changes_in_equity = fields.Integer(
        string='Break lines (Statement of changes in equity)',
        default=5,
    )
    signature_break_lines_cash_flows = fields.Integer(
        string='Break lines (Statement of cash flows)',
        default=5,
    )
    signature_break_lines_notes = fields.Integer(
        string='Break lines (Notes to financial statements)',
        default=5,
    )
    use_previous_settings = fields.Boolean(
        string='Use Previous Settings',
        default=True,
    )
    audit_period_category = fields.Selection(
        [
            ('cessation_2y', '2 Years Cessation'),
            ('cessation_1y', '1 Year Cessation'),
            ('normal_1y', '1 Year Normal'),
            ('normal_2y', '2 Years Normal'),
            ('dormant_1y', '1 Year Dormant'),
            ('dormant_2y', '2 Years Dormant'),
        ],
        string='Audit Period Category',
        default='normal_2y',
    )
    share_capital_paid_status = fields.Selection(
        [
            ('paid', 'Paid'),
            ('unpaid', 'Unpaid'),
        ],
        string='Share capital status',
        default='paid',
    )
    related_party_name = fields.Char(string='Related party')
    related_party_relationship = fields.Char(string='Nature of relationship')
    related_party_transaction = fields.Char(string='Nature of transactions')
    related_party_amount = fields.Float(string='Related party amount (current)')
    related_party_amount_prior = fields.Float(string='Related party amount (prior)')
    prior_year_mode = fields.Selection(
        [
            ('auto', 'Auto (1 year back)'),
            ('manual', 'Manual selection'),
        ],
        string='Prior Year Dates',
        required=True,
        default='auto',
    )
    prior_date_start = fields.Date(string='Prior Date Start')
    prior_date_end = fields.Date(string='Prior Date End')
    excel_date_start = fields.Date(string='Excel Date Start')
    excel_date_end = fields.Date(string='Excel Date End')
    excel_prior_year_mode = fields.Selection(
        [
            ('auto', 'Auto (1 year back)'),
            ('manual', 'Manual selection'),
        ],
        string='Excel Prior Year Dates',
        required=True,
        default='auto',
    )
    excel_prior_date_start = fields.Date(string='Excel Prior Date Start')
    excel_prior_date_end = fields.Date(string='Excel Prior Date End')
    emphasis_change_period = fields.Boolean(string='Change in Financial Year/Period')
    emphasis_correction_error = fields.Boolean(string='Correction of Error')
    emphasis_liquidation = fields.Boolean(string='Liquidation')
    emphasis_change_from_date = fields.Date(string='Changed From')
    emphasis_change_to_date = fields.Date(string='Changed To')
    additional_note_legal_status_change = fields.Boolean(string='Legal Status Change')
    additional_note_no_active_bank_account = fields.Boolean(string='No Active Bank Account')
    emphasis_legal_change_date = fields.Date(string='Legal Change Date')
    emphasis_legal_status_from = fields.Char(string='Legal Status From')
    emphasis_legal_status_to = fields.Char(string='Legal Status To')

    def _previous_settings_key(self):
        return (
            f'audit_report_wizard.prev_settings.user_{self.env.user.id}.'
            f'company_{self.env.company.id}'
        )

    def _get_previous_settings(self):
        param = self.env['ir.config_parameter'].sudo()
        raw = param.get_param(self._previous_settings_key(), default='')
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except (TypeError, ValueError):
            return {}

    def _store_previous_settings(self):
        data = {
            'date_start': self.date_start.isoformat() if self.date_start else False,
            'date_end': self.date_end.isoformat() if self.date_end else False,
            'balance_sheet_date_mode': self.balance_sheet_date_mode,
            'prior_year_mode': self.prior_year_mode,
            'prior_date_start': self.prior_date_start.isoformat() if self.prior_date_start else False,
            'prior_date_end': self.prior_date_end.isoformat() if self.prior_date_end else False,
            'excel_date_start': self.excel_date_start.isoformat() if self.excel_date_start else False,
            'excel_date_end': self.excel_date_end.isoformat() if self.excel_date_end else False,
            'excel_prior_year_mode': self.excel_prior_year_mode,
            'excel_prior_date_start': (
                self.excel_prior_date_start.isoformat() if self.excel_prior_date_start else False
            ),
            'excel_prior_date_end': (
                self.excel_prior_date_end.isoformat() if self.excel_prior_date_end else False
            ),
            'report_type': self.report_type,
            'auditor_type': self.auditor_type,
            'audit_period_category': self.audit_period_category,
            'show_related_parties_note': self.show_related_parties_note,
            'gap_report_of_directors': self.gap_report_of_directors,
            'gap_independent_auditor_report': self.gap_independent_auditor_report,
            'gap_notes_to_financial_statements': self.gap_notes_to_financial_statements,
            'signature_break_lines_report_of_directors': self.signature_break_lines_report_of_directors,
            'signature_break_lines_balance_sheet': self.signature_break_lines_balance_sheet,
            'signature_break_lines_profit_loss': self.signature_break_lines_profit_loss,
            'signature_break_lines_changes_in_equity': self.signature_break_lines_changes_in_equity,
            'signature_break_lines_cash_flows': self.signature_break_lines_cash_flows,
            'signature_break_lines_notes': self.signature_break_lines_notes,
            'share_capital_paid_status': self.share_capital_paid_status,
            'related_party_name': self.related_party_name,
            'related_party_relationship': self.related_party_relationship,
            'related_party_transaction': self.related_party_transaction,
            'related_party_amount': self.related_party_amount,
            'related_party_amount_prior': self.related_party_amount_prior,
            'emphasis_change_period': self.emphasis_change_period,
            'emphasis_correction_error': self.emphasis_correction_error,
            'emphasis_liquidation': self.emphasis_liquidation,
            'emphasis_change_from_date': (
                self.emphasis_change_from_date.isoformat() if self.emphasis_change_from_date else False
            ),
            'emphasis_change_to_date': (
                self.emphasis_change_to_date.isoformat() if self.emphasis_change_to_date else False
            ),
            'additional_note_legal_status_change': self.additional_note_legal_status_change,
            'additional_note_no_active_bank_account': self.additional_note_no_active_bank_account,
            'emphasis_legal_change_date': (
                self.emphasis_legal_change_date.isoformat() if self.emphasis_legal_change_date else False
            ),
            'emphasis_legal_status_from': self.emphasis_legal_status_from,
            'emphasis_legal_status_to': self.emphasis_legal_status_to,
        }
        self.env['ir.config_parameter'].sudo().set_param(
            self._previous_settings_key(),
            json.dumps(data),
        )

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        if not res.get('use_previous_settings', True):
            return res
        data = self._get_previous_settings()
        if not data:
            return res
        if 'date_start' in fields_list and data.get('date_start'):
            res['date_start'] = fields.Date.to_date(data['date_start'])
        if 'date_end' in fields_list and data.get('date_end'):
            res['date_end'] = fields.Date.to_date(data['date_end'])
        if 'balance_sheet_date_mode' in fields_list and data.get('balance_sheet_date_mode'):
            res['balance_sheet_date_mode'] = data['balance_sheet_date_mode']
        if 'prior_year_mode' in fields_list and data.get('prior_year_mode'):
            res['prior_year_mode'] = data['prior_year_mode']
        if 'prior_date_start' in fields_list and data.get('prior_date_start'):
            res['prior_date_start'] = fields.Date.to_date(data['prior_date_start'])
        if 'prior_date_end' in fields_list and data.get('prior_date_end'):
            res['prior_date_end'] = fields.Date.to_date(data['prior_date_end'])
        if 'excel_date_start' in fields_list and data.get('excel_date_start'):
            res['excel_date_start'] = fields.Date.to_date(data['excel_date_start'])
        if 'excel_date_end' in fields_list and data.get('excel_date_end'):
            res['excel_date_end'] = fields.Date.to_date(data['excel_date_end'])
        if 'excel_prior_year_mode' in fields_list and data.get('excel_prior_year_mode'):
            res['excel_prior_year_mode'] = data['excel_prior_year_mode']
        if 'excel_prior_date_start' in fields_list and data.get('excel_prior_date_start'):
            res['excel_prior_date_start'] = fields.Date.to_date(data['excel_prior_date_start'])
        if 'excel_prior_date_end' in fields_list and data.get('excel_prior_date_end'):
            res['excel_prior_date_end'] = fields.Date.to_date(data['excel_prior_date_end'])
        if 'report_type' in fields_list and data.get('report_type'):
            res['report_type'] = data['report_type']
        if 'auditor_type' in fields_list and data.get('auditor_type'):
            res['auditor_type'] = data['auditor_type']
        if 'audit_period_category' in fields_list and data.get('audit_period_category'):
            res['audit_period_category'] = data['audit_period_category']
        if 'show_related_parties_note' in fields_list and data.get('show_related_parties_note') is not None:
            res['show_related_parties_note'] = data['show_related_parties_note']
        if 'gap_report_of_directors' in fields_list and data.get('gap_report_of_directors') is not None:
            res['gap_report_of_directors'] = data['gap_report_of_directors']
        if (
            'gap_independent_auditor_report' in fields_list
            and data.get('gap_independent_auditor_report') is not None
        ):
            res['gap_independent_auditor_report'] = data['gap_independent_auditor_report']
        if (
            'gap_notes_to_financial_statements' in fields_list
            and data.get('gap_notes_to_financial_statements') is not None
        ):
            res['gap_notes_to_financial_statements'] = data['gap_notes_to_financial_statements']
        old_directors_breaks = data.get('signature_break_lines_directors')
        old_other_breaks = data.get('signature_break_lines_other')
        if 'signature_break_lines_report_of_directors' in fields_list:
            value = data.get('signature_break_lines_report_of_directors')
            if value is None:
                value = old_directors_breaks if old_directors_breaks is not None else old_other_breaks
            if value is not None:
                res['signature_break_lines_report_of_directors'] = value
        if 'signature_break_lines_balance_sheet' in fields_list:
            value = data.get('signature_break_lines_balance_sheet')
            if value is None:
                value = old_other_breaks
            if value is not None:
                res['signature_break_lines_balance_sheet'] = value
        if 'signature_break_lines_profit_loss' in fields_list:
            value = data.get('signature_break_lines_profit_loss')
            if value is None:
                value = old_other_breaks
            if value is not None:
                res['signature_break_lines_profit_loss'] = value
        if 'signature_break_lines_changes_in_equity' in fields_list:
            value = data.get('signature_break_lines_changes_in_equity')
            if value is None:
                value = old_other_breaks
            if value is not None:
                res['signature_break_lines_changes_in_equity'] = value
        if 'signature_break_lines_cash_flows' in fields_list:
            value = data.get('signature_break_lines_cash_flows')
            if value is None:
                value = old_other_breaks
            if value is not None:
                res['signature_break_lines_cash_flows'] = value
        if 'signature_break_lines_notes' in fields_list:
            value = data.get('signature_break_lines_notes')
            if value is None:
                value = old_other_breaks
            if value is not None:
                res['signature_break_lines_notes'] = value
        if 'share_capital_paid_status' in fields_list and data.get('share_capital_paid_status'):
            res['share_capital_paid_status'] = data['share_capital_paid_status']
        if 'related_party_name' in fields_list and data.get('related_party_name'):
            res['related_party_name'] = data['related_party_name']
        if 'related_party_relationship' in fields_list and data.get('related_party_relationship'):
            res['related_party_relationship'] = data['related_party_relationship']
        if 'related_party_transaction' in fields_list and data.get('related_party_transaction'):
            res['related_party_transaction'] = data['related_party_transaction']
        if 'related_party_amount' in fields_list and data.get('related_party_amount') is not None:
            res['related_party_amount'] = data['related_party_amount']
        if 'related_party_amount_prior' in fields_list and data.get('related_party_amount_prior') is not None:
            res['related_party_amount_prior'] = data['related_party_amount_prior']
        if 'emphasis_change_period' in fields_list and data.get('emphasis_change_period') is not None:
            res['emphasis_change_period'] = data['emphasis_change_period']
        if 'emphasis_correction_error' in fields_list and data.get('emphasis_correction_error') is not None:
            res['emphasis_correction_error'] = data['emphasis_correction_error']
        if 'emphasis_liquidation' in fields_list and data.get('emphasis_liquidation') is not None:
            res['emphasis_liquidation'] = data['emphasis_liquidation']
        if 'emphasis_change_from_date' in fields_list and data.get('emphasis_change_from_date'):
            res['emphasis_change_from_date'] = fields.Date.to_date(data['emphasis_change_from_date'])
        if 'emphasis_change_to_date' in fields_list and data.get('emphasis_change_to_date'):
            res['emphasis_change_to_date'] = fields.Date.to_date(data['emphasis_change_to_date'])
        if (
            'additional_note_legal_status_change' in fields_list
            and data.get('additional_note_legal_status_change') is not None
        ):
            res['additional_note_legal_status_change'] = data['additional_note_legal_status_change']
        if (
            'additional_note_no_active_bank_account' in fields_list
            and data.get('additional_note_no_active_bank_account') is not None
        ):
            res['additional_note_no_active_bank_account'] = data['additional_note_no_active_bank_account']
        if 'emphasis_legal_change_date' in fields_list and data.get('emphasis_legal_change_date'):
            res['emphasis_legal_change_date'] = fields.Date.to_date(data['emphasis_legal_change_date'])
        if 'emphasis_legal_status_from' in fields_list and data.get('emphasis_legal_status_from'):
            res['emphasis_legal_status_from'] = data['emphasis_legal_status_from']
        if 'emphasis_legal_status_to' in fields_list and data.get('emphasis_legal_status_to'):
            res['emphasis_legal_status_to'] = data['emphasis_legal_status_to']
        return res

    @api.onchange('use_previous_settings')
    def _onchange_use_previous_settings(self):
        if self.use_previous_settings:
            data = self._get_previous_settings()
            if data.get('date_start'):
                self.date_start = fields.Date.to_date(data['date_start'])
            if data.get('date_end'):
                self.date_end = fields.Date.to_date(data['date_end'])
            if data.get('balance_sheet_date_mode'):
                self.balance_sheet_date_mode = data['balance_sheet_date_mode']
            if data.get('prior_year_mode'):
                self.prior_year_mode = data['prior_year_mode']
            if data.get('prior_date_start'):
                self.prior_date_start = fields.Date.to_date(data['prior_date_start'])
            if data.get('prior_date_end'):
                self.prior_date_end = fields.Date.to_date(data['prior_date_end'])
            if data.get('excel_date_start'):
                self.excel_date_start = fields.Date.to_date(data['excel_date_start'])
            if data.get('excel_date_end'):
                self.excel_date_end = fields.Date.to_date(data['excel_date_end'])
            if data.get('excel_prior_year_mode'):
                self.excel_prior_year_mode = data['excel_prior_year_mode']
            if data.get('excel_prior_date_start'):
                self.excel_prior_date_start = fields.Date.to_date(data['excel_prior_date_start'])
            if data.get('excel_prior_date_end'):
                self.excel_prior_date_end = fields.Date.to_date(data['excel_prior_date_end'])
            if data.get('report_type'):
                self.report_type = data['report_type']
            if data.get('auditor_type'):
                self.auditor_type = data['auditor_type']
            if data.get('audit_period_category'):
                self.audit_period_category = data['audit_period_category']
            if data.get('show_related_parties_note') is not None:
                self.show_related_parties_note = data['show_related_parties_note']
            if data.get('gap_report_of_directors') is not None:
                self.gap_report_of_directors = data['gap_report_of_directors']
            if data.get('gap_independent_auditor_report') is not None:
                self.gap_independent_auditor_report = data['gap_independent_auditor_report']
            if data.get('gap_notes_to_financial_statements') is not None:
                self.gap_notes_to_financial_statements = data['gap_notes_to_financial_statements']
            old_directors_breaks = data.get('signature_break_lines_directors')
            old_other_breaks = data.get('signature_break_lines_other')
            if data.get('signature_break_lines_report_of_directors') is not None:
                self.signature_break_lines_report_of_directors = data['signature_break_lines_report_of_directors']
            elif old_directors_breaks is not None:
                self.signature_break_lines_report_of_directors = old_directors_breaks
            elif old_other_breaks is not None:
                self.signature_break_lines_report_of_directors = old_other_breaks
            if data.get('signature_break_lines_balance_sheet') is not None:
                self.signature_break_lines_balance_sheet = data['signature_break_lines_balance_sheet']
            elif old_other_breaks is not None:
                self.signature_break_lines_balance_sheet = old_other_breaks
            if data.get('signature_break_lines_profit_loss') is not None:
                self.signature_break_lines_profit_loss = data['signature_break_lines_profit_loss']
            elif old_other_breaks is not None:
                self.signature_break_lines_profit_loss = old_other_breaks
            if data.get('signature_break_lines_changes_in_equity') is not None:
                self.signature_break_lines_changes_in_equity = data['signature_break_lines_changes_in_equity']
            elif old_other_breaks is not None:
                self.signature_break_lines_changes_in_equity = old_other_breaks
            if data.get('signature_break_lines_cash_flows') is not None:
                self.signature_break_lines_cash_flows = data['signature_break_lines_cash_flows']
            elif old_other_breaks is not None:
                self.signature_break_lines_cash_flows = old_other_breaks
            if data.get('signature_break_lines_notes') is not None:
                self.signature_break_lines_notes = data['signature_break_lines_notes']
            elif old_other_breaks is not None:
                self.signature_break_lines_notes = old_other_breaks
            if data.get('share_capital_paid_status'):
                self.share_capital_paid_status = data['share_capital_paid_status']
            if data.get('related_party_name'):
                self.related_party_name = data['related_party_name']
            if data.get('related_party_relationship'):
                self.related_party_relationship = data['related_party_relationship']
            if data.get('related_party_transaction'):
                self.related_party_transaction = data['related_party_transaction']
            if data.get('related_party_amount') is not None:
                self.related_party_amount = data['related_party_amount']
            if data.get('related_party_amount_prior') is not None:
                self.related_party_amount_prior = data['related_party_amount_prior']
            if data.get('emphasis_change_period') is not None:
                self.emphasis_change_period = data['emphasis_change_period']
            if data.get('emphasis_correction_error') is not None:
                self.emphasis_correction_error = data['emphasis_correction_error']
            if data.get('emphasis_liquidation') is not None:
                self.emphasis_liquidation = data['emphasis_liquidation']
            if data.get('emphasis_change_from_date'):
                self.emphasis_change_from_date = fields.Date.to_date(data['emphasis_change_from_date'])
            if data.get('emphasis_change_to_date'):
                self.emphasis_change_to_date = fields.Date.to_date(data['emphasis_change_to_date'])
            if data.get('additional_note_legal_status_change') is not None:
                self.additional_note_legal_status_change = data['additional_note_legal_status_change']
            if data.get('additional_note_no_active_bank_account') is not None:
                self.additional_note_no_active_bank_account = data['additional_note_no_active_bank_account']
            if data.get('emphasis_legal_change_date'):
                self.emphasis_legal_change_date = fields.Date.to_date(data['emphasis_legal_change_date'])
            if data.get('emphasis_legal_status_from'):
                self.emphasis_legal_status_from = data['emphasis_legal_status_from']
            if data.get('emphasis_legal_status_to'):
                self.emphasis_legal_status_to = data['emphasis_legal_status_to']
        else:
            self.date_start = False
            self.date_end = False
            self.balance_sheet_date_mode = 'end_only'
            self.prior_year_mode = 'auto'
            self.prior_date_start = False
            self.prior_date_end = False
            self.excel_date_start = False
            self.excel_date_end = False
            self.excel_prior_year_mode = 'auto'
            self.excel_prior_date_start = False
            self.excel_prior_date_end = False
            self.report_type = 'period'
            self.auditor_type = 'default'
            self.audit_period_category = 'normal_2y'
            self.show_related_parties_note = False
            self.gap_report_of_directors = True
            self.gap_independent_auditor_report = True
            self.gap_notes_to_financial_statements = True
            self.signature_break_lines_report_of_directors = 5
            self.signature_break_lines_balance_sheet = 5
            self.signature_break_lines_profit_loss = 5
            self.signature_break_lines_changes_in_equity = 5
            self.signature_break_lines_cash_flows = 5
            self.signature_break_lines_notes = 5
            self.share_capital_paid_status = 'paid'
            self.related_party_name = False
            self.related_party_relationship = False
            self.related_party_transaction = False
            self.related_party_amount = 0.0
            self.related_party_amount_prior = 0.0
            self.emphasis_change_period = False
            self.emphasis_correction_error = False
            self.emphasis_liquidation = False
            self.emphasis_change_from_date = False
            self.emphasis_change_to_date = False
            self.additional_note_legal_status_change = False
            self.additional_note_no_active_bank_account = False
            self.emphasis_legal_change_date = False
            self.emphasis_legal_status_from = False
            self.emphasis_legal_status_to = False
            self.company_id = self.env.company

    @api.onchange('emphasis_change_period')
    def _onchange_emphasis_change_period(self):
        if not self.emphasis_change_period:
            self.emphasis_change_from_date = False
            self.emphasis_change_to_date = False

    @api.onchange('additional_note_legal_status_change')
    def _onchange_additional_note_legal_status_change(self):
        if not self.additional_note_legal_status_change:
            self.emphasis_legal_change_date = False
            self.emphasis_legal_status_from = False
            self.emphasis_legal_status_to = False

    def _validate_emphasis_options(self):
        self.ensure_one()
        if self.emphasis_change_period:
            if not self.emphasis_change_from_date or not self.emphasis_change_to_date:
                raise ValidationError(
                    "Please provide both 'Changed From' and 'Changed To' dates for Emphasis of Matter."
                )
            if self.emphasis_change_from_date >= self.emphasis_change_to_date:
                raise ValidationError(
                    "'Changed To' date must be after 'Changed From' date for Emphasis of Matter."
                )
        if self.additional_note_legal_status_change:
            if (
                not self.emphasis_legal_change_date
                or not self.emphasis_legal_status_from
                or not self.emphasis_legal_status_to
            ):
                raise ValidationError(
                    "Please provide Legal Change Date, Legal Status From, and Legal Status To for Additional Notes."
                )

    @api.onchange(
        'company_street',
        'company_free_zone',
        'company_license_number',
        'trade_license_activities',
        'incorporation_date',
        'corporate_tax_registration_number',
        'vat_registration_number',
        'corporate_tax_start_date',
        'corporate_tax_end_date',
        'implementing_regulations_freezone',
        'shareholder_1',
        'shareholder_2',
        'shareholder_3',
        'shareholder_4',
        'shareholder_5',
        'shareholder_6',
        'shareholder_7',
        'shareholder_8',
        'shareholder_9',
        'shareholder_10',
        'nationality_1',
        'nationality_2',
        'nationality_3',
        'nationality_4',
        'nationality_5',
        'nationality_6',
        'nationality_7',
        'nationality_8',
        'nationality_9',
        'nationality_10',
        'number_of_shares_1',
        'number_of_shares_2',
        'number_of_shares_3',
        'number_of_shares_4',
        'number_of_shares_5',
        'number_of_shares_6',
        'number_of_shares_7',
        'number_of_shares_8',
        'number_of_shares_9',
        'number_of_shares_10',
        'share_value_1',
        'share_value_2',
        'share_value_3',
        'share_value_4',
        'share_value_5',
        'share_value_6',
        'share_value_7',
        'share_value_8',
        'share_value_9',
        'share_value_10',
    )
    def _onchange_sync_company_info(self):
        if not self.company_id:
            return
        vals = {
            'street': self.company_street or False,
            'free_zone': self.company_free_zone or False,
            'company_license_number': self.company_license_number or False,
            'trade_license_activities': self.trade_license_activities or False,
            'incorporation_date': self.incorporation_date or False,
            'corporate_tax_registration_number': self.corporate_tax_registration_number or False,
            'vat_registration_number': self.vat_registration_number or False,
            'corporate_tax_start_date': self.corporate_tax_start_date or False,
            'corporate_tax_end_date': self.corporate_tax_end_date or False,
            'implementing_regulations_freezone': self.implementing_regulations_freezone or False,
            'shareholder_1': self.shareholder_1 or False,
            'shareholder_2': self.shareholder_2 or False,
            'shareholder_3': self.shareholder_3 or False,
            'shareholder_4': self.shareholder_4 or False,
            'shareholder_5': self.shareholder_5 or False,
            'shareholder_6': self.shareholder_6 or False,
            'shareholder_7': self.shareholder_7 or False,
            'shareholder_8': self.shareholder_8 or False,
            'shareholder_9': self.shareholder_9 or False,
            'shareholder_10': self.shareholder_10 or False,
            'nationality_1': self.nationality_1 or False,
            'nationality_2': self.nationality_2 or False,
            'nationality_3': self.nationality_3 or False,
            'nationality_4': self.nationality_4 or False,
            'nationality_5': self.nationality_5 or False,
            'nationality_6': self.nationality_6 or False,
            'nationality_7': self.nationality_7 or False,
            'nationality_8': self.nationality_8 or False,
            'nationality_9': self.nationality_9 or False,
            'nationality_10': self.nationality_10 or False,
            'number_of_shares_1': self.number_of_shares_1 or 0,
            'number_of_shares_2': self.number_of_shares_2 or 0,
            'number_of_shares_3': self.number_of_shares_3 or 0,
            'number_of_shares_4': self.number_of_shares_4 or 0,
            'number_of_shares_5': self.number_of_shares_5 or 0,
            'number_of_shares_6': self.number_of_shares_6 or 0,
            'number_of_shares_7': self.number_of_shares_7 or 0,
            'number_of_shares_8': self.number_of_shares_8 or 0,
            'number_of_shares_9': self.number_of_shares_9 or 0,
            'number_of_shares_10': self.number_of_shares_10 or 0,
            'share_value_1': self.share_value_1 or 0.0,
            'share_value_2': self.share_value_2 or 0.0,
            'share_value_3': self.share_value_3 or 0.0,
            'share_value_4': self.share_value_4 or 0.0,
            'share_value_5': self.share_value_5 or 0.0,
            'share_value_6': self.share_value_6 or 0.0,
            'share_value_7': self.share_value_7 or 0.0,
            'share_value_8': self.share_value_8 or 0.0,
            'share_value_9': self.share_value_9 or 0.0,
            'share_value_10': self.share_value_10 or 0.0,
        }
        self.company_id.write(vals)

    def _get_report_data(self):
        """Get report data for the template"""
        ctx = self.env.context
        date_start = fields.Date.to_date(ctx.get('audit_date_start') or self.date_start)
        date_end = fields.Date.to_date(ctx.get('audit_date_end') or self.date_end)
        period_category = (ctx.get('audit_period_category') or self.audit_period_category or '').lower()
        prior_year_mode = ctx.get('audit_prior_year_mode') or self.prior_year_mode
        prior_date_start_raw = ctx.get('audit_prior_date_start') or self.prior_date_start
        prior_date_end_raw = ctx.get('audit_prior_date_end') or self.prior_date_end
        show_prior_year = not period_category.endswith('_1y')
        if prior_year_mode == 'manual' and prior_date_start_raw and prior_date_end_raw:
            prior_date_start = fields.Date.to_date(prior_date_start_raw)
            prior_date_end = fields.Date.to_date(prior_date_end_raw)
        else:
            prior_date_start = date_start - relativedelta(years=1)
            prior_date_end = date_end - relativedelta(years=1)
        prior_prior_date_start = prior_date_start - relativedelta(years=1)
        prior_prior_date_end = prior_date_end - relativedelta(years=1)


        def _fetch_account_rows(date_start, date_end):
            def _normalize_code(code):
                return ''.join(ch for ch in code if ch.isdigit())

            if not date_end:
                return []
            domain = [
                ('date', '<=', date_end),
                ('company_id', '=', self.company_id.id),
                ('move_id.state', '=', 'posted'),
            ]
            if date_start:
                domain.insert(0, ('date', '>=', date_start))
            move_line_env = self.env['account.move.line'].with_context(
                allowed_company_ids=[self.company_id.id]
            )
            rows = move_line_env.read_group(
                domain=domain,
                fields=['debit', 'credit', 'balance'],
                groupby=['account_id']
            )

            account_ids = [row['account_id'][0] for row in rows if row.get('account_id')]
            account_env = self.env['account.account'].with_company(self.company_id).with_context(
                allowed_company_ids=[self.company_id.id]
            )
            account_map = {acc.id: acc for acc in account_env.browse(account_ids)}


            final_rows = []
            for row in rows:
                if not row.get('account_id'):
                    continue
                account_id = row['account_id'][0]
                account = account_map.get(account_id)
                if not account:
                    continue
                code_raw = (account.code or account.code_store or '').strip()
                if not code_raw:
                    continue
                code = _normalize_code(code_raw)
                if not code:
                    continue
                final_rows.append({
                    'id': account_id,
                    'code': code,
                    'code_raw': code_raw,
                    'name': account.name,
                    'type': account.account_type,
                    'debit': row['debit'],
                    'credit': row['credit'],
                    'balance': row['balance'],
                })
          
            return final_rows


        balance_sheet_date_start = date_start if self.balance_sheet_date_mode == 'range' else False
        prior_balance_sheet_date_start = (
            prior_date_start if self.balance_sheet_date_mode == 'range' else False
        )
        prior_prior_balance_sheet_date_start = (
            prior_prior_date_start if self.balance_sheet_date_mode == 'range' else False
        )

        def _sum_by_prefix(rows, length):
            totals = {}
            for row in rows:
                code = row.get('code') or ''
                if len(code) < length:
                    continue
                key = code[:length]
                totals[key] = totals.get(key, 0.0) + row.get('balance', 0.0)
            return totals


        def _build_section_totals(group_totals, mapping):
            totals = {}
            for label, codes in mapping.items():
                total = 0.0
                for code in codes:
                    total += group_totals.get(code, 0.0)
                totals[label] = total
            return totals

        def _build_group_label_map(mappings):
            labels = {}
            for mapping in mappings:
                for label, codes in mapping.items():
                    for code in codes:
                        labels[code] = label
            return labels

        def _annotate_rows(rows, group_labels):
            annotated = []
            for row in rows:
                code = row.get('code', '')
                group_code = code[:4] if len(code) >= 4 else ''
                data = dict(row)
                data['group_code'] = group_code
                data['sub_group_code'] = code[:6] if len(code) >= 6 else ''
                data['two_digit_code'] = code[:2] if len(code) >= 2 else ''
                data['one_digit_code'] = code[:1] if len(code) >= 1 else ''
                data['section'] = group_labels.get(group_code, 'Other')
                annotated.append(data)
            return annotated

        def _build_subhead_groups(prefix_totals, subhead_labels):
            grouped = {}
            for code in sorted(prefix_totals):
                name = subhead_labels.get(code)
                if not name:
                    continue
                group_code = code[:4]
                grouped.setdefault(group_code, []).append({
                    'code': code,
                    'name': name,
                    'balance': prefix_totals[code],
                })
            return grouped

        def _build_account_head_map(rows):
            accounts = {}
            for row in rows:
                code = row.get('code') or ''
                if len(code) < 8:
                    continue
                group_code = code[:4]
                accounts.setdefault(group_code, {})
                accounts[group_code][code] = {
                    'code': code,
                    'name': row.get('name') or '',
                    'balance': row.get('balance', 0.0),
                }
            return accounts

        def _account_head_balance(account_heads, account_code):
            group_code = account_code[:4]
            return account_heads.get(group_code, {}).get(account_code, {}).get('balance', 0.0)

        def _equity_head_balance(account_heads, account_code):
            # Equity accounts are credit-balanced in Odoo (negative); invert for display.
            return -_account_head_balance(account_heads, account_code)

        def _collect_note_lines(group_codes, current_map, prev_map):
            if len(group_codes) == 1 and group_codes[0] == '1204':
                cash_prefix = '120401'
                bank_prefix = '120402'

                def _sum_prefix(prefix, account_map):
                    total = 0.0
                    for code, info in account_map.get('1204', {}).items():
                        if code.startswith(prefix):
                            total += info.get('balance', 0.0)
                    return total

                current_bank = _sum_prefix(bank_prefix, current_map)
                prev_bank = _sum_prefix(bank_prefix, prev_map)
                current_cash = _sum_prefix(cash_prefix, current_map)
                prev_cash = _sum_prefix(cash_prefix, prev_map)

                lines = []
                if current_bank or prev_bank:
                    lines.append({
                        'code': bank_prefix,
                        'name': 'Cash in bank',
                        'current': current_bank,
                        'prev': prev_bank,
                    })
                if current_cash or prev_cash:
                    lines.append({
                        'code': cash_prefix,
                        'name': 'Cash in hand',
                        'current': current_cash,
                        'prev': prev_cash,
                    })
                if lines:
                    return lines

            account_codes = set()
            for group_code in group_codes:
                account_codes.update(current_map.get(group_code, {}).keys())
                account_codes.update(prev_map.get(group_code, {}).keys())

            lines = []
            for account_code in sorted(account_codes):
                group_code = account_code[:4]
                current_info = current_map.get(group_code, {}).get(account_code, {})
                prev_info = prev_map.get(group_code, {}).get(account_code, {})
                current_balance = current_info.get('balance', 0.0)
                prev_balance = prev_info.get('balance', 0.0)
                if not (current_balance or prev_balance):
                    continue
                lines.append({
                    'code': account_code,
                    'name': current_info.get('name') or prev_info.get('name') or '',
                    'current': current_balance,
                    'prev': prev_balance,
                })
            return lines

        def _label_group_totals(group_totals, labels):
            totals = {}
            for code, label in labels.items():
                totals[label] = totals.get(label, 0.0) + group_totals.get(code, 0.0)
            return totals

        NON_CURRENT_ASSET_GROUPS = {
            'Property and equipment': ['1101'],
            'Right of use of assets': ['1102'],
            'Capital work in progress': ['1103'],
            'Long term investment': ['1104', '1108'],
            'Long term deposits': ['1105'],
            'Long term loans receivable': ['1106'],
            'Intangible assets': ['1107'],
            'Deferred tax': ['1109'],
        }
        CURRENT_ASSET_GROUPS = {
            'Inventory': ['1201'],
            'Accounts receivable': ['1202'],
            'Prepayment, deposits, advances and other receivables': ['1203'],
            'Cash and bank balances': ['1204'],
            'Stripe and other wallets': ['1205'],
            'Interbank transfer': ['1206'],
        }
        NON_CURRENT_LIABILITY_GROUPS = {
            'Long term loan': ['2101'],
            'Long term loans payable - related parties': ['2102'],
            'Deferred tax': ['2103'],
            'Employee benefits': ['2104'],
        }
        CURRENT_LIABILITY_GROUPS = {
            'Short term borrowings': ['2201'],
            'Trade payables': ['2202'],
            'Other payables': ['2203'],
            'Corporate tax liability': ['2204'],
        }
        EQUITY_GROUPS = {
            'Equity': ['3101'],
        }
        REVENUE_GROUPS = {
            'Revenue': ['4101', '4102'],
        }
        OTHER_INCOME_GROUPS = {
            'Other income': ['4103'],
        }
        COST_OF_REVENUE_GROUPS = {
            'Cost of revenue': ['5101'],
        }
        DEPRECIATION_GROUPS = {
            'Depreciation': ['5114'],
        }

        MAIN_HEAD_LABELS = {
            '1101': 'Property Plant And Equipment',
            '1102': 'Right of Use of Assets',
            '1103': 'Capital Work in Progress',
            '1104': 'Long Term Investment',
            '1105': 'Long Term Deposits',
            '1106': 'Long Term Loans Receivable',
            '1107': 'Intangible Assets',
            '1108': 'Long Term Investment',
            '1109': 'Deferred Tax',
            '1201': 'Inventory',
            '1202': 'Accounts Receivable',
            '1203': 'Prepayment, Deposits, Advances & Other Receivables',
            '1204': 'Cash And Bank Balances',
            '1205': 'Stripe & Other Wallets',
            '1206': 'Interbank Transfer',
            '2101': 'Long term loan',
            '2102': 'Long Term Loans Payable - Related Parties',
            '2103': 'Deferred Tax',
            '2104': 'Employee Benefits',
            '2201': 'Short Term Borrowings',
            '2202': 'Trade Payables',
            '2203': 'Other Payables',
            '2204': 'Corporate Tax Liability',
            '3101': 'Equity',
            '4101': 'Revenue',
            '4102': 'Revenue - Related Party',
            '4103': 'Other Income',
            '5101': 'Direct Cost',
            '5102': 'Marketing & Advertisement Expenses',
            '5103': 'IT Expenses',
            '5104': 'Telephone & Internet',
            '5105': 'Professional Fee & Consultancy',
            '5106': 'Legal & Government Fee',
            '5107': "Director's Salary",
            '5108': 'Salaries & Wages',
            '5109': 'Audit & Accounting Expense',
            '5110': 'Rent Expense',
            '5111': 'Utilities',
            '5112': 'Printing & Stationary Expense',
            '5113': 'Travel & Accommodation Expense',
            '5114': 'Depreciation & Amortization',
            '5115': 'Courier Expenses',
            '5116': 'Commission Expense',
            '5117': 'Cleaning Expense',
            '5118': 'Repair & Maintenance',
            '5119': 'Other expenses',
            '5120': 'Penalties & Fines',
            '5121': 'Donation & Charity',
            '5122': 'Other expenses',
            '5123': 'Bank Charges',
            '5124': 'Finance Cost',
            '5125': 'Insurance Expense',
            '5126': 'Fees & Subscriptions',
            '5127': 'Tax expense',
            '5128': 'Office Expense',
        }

        SUBHEAD_LABELS = {
            '110101': 'Land & Buildings',
            '110102': 'Furnitures & Fixtures',
            '110103': 'Leasehold Improvements',
            '110104': 'Vehicles',
            '110105': 'IT Equipments',
            '110106': 'Office Equipments',
            '110201': 'ROU Property',
            '110202': 'ROU Vehicles',
            '110203': 'ROU Equipment',
            '110204': 'ROU Property',
            '110205': 'ROU Vehicles',
            '110206': 'ROU Equipment',
            '110301': 'Capital Work in Progress',
            '110401': 'Investments in funds',
            '110501': 'Long Term Deposits',
            '110601': 'Related Parties',
            '110701': 'Software & Licences',
            '110702': 'Website & Blogs',
            '110703': 'Other Intangible Assets',
            '110801': 'Group Investments',
            '110901': 'Deferred Tax',
            '120101': 'Inventory',
            '120201': 'Trade Receivables',
            '120202': 'Retention Receivables',
            '120301': 'Advances',
            '120302': 'Prepaid Expenses',
            '120303': 'Other Receivables',
            '120304': 'VAT Receivable',
            '120401': 'Cash',
            '120402': 'Bank Accounts',
            '120501': 'Payment Gateways',
            '120502': 'Other Wallet',
            '120601': 'Interbank Transfer',
            '210101': 'Bank Loans',
            '210102': 'Related Party Loan',
            '210103': 'Lease Liabilities',
            '210201': 'Long Term Loans Payable - Related Parties',
            '210301': 'Deferred Tax',
            '210401': 'End of Service Benefits',
            '220101': 'Bank Overdraft',
            '220102': 'Short term loan',
            '220103': 'Credit Card Payable',
            '220104': 'Lease Liability',
            '220201': 'Trade Payables',
            '220301': 'Other Payables',
            '220302': 'VAT Payable',
            '220303': 'Accrued Expenses',
            '220401': 'Corporate Tax Liability',
            '310101': 'Share Capital',
            '310102': 'Retained Earnings',
            '310103': 'Reserves',
            '310104': 'Fund Balances',
            '410101': 'Revenue',
            '410201': 'Revenue - Related Party',
            '410301': 'Interest income',
            '410302': 'Dividend income',
            '410303': 'Rental Income',
            '410304': 'Miscellaneous Income',
            '410305': 'Foreign Exchange Gain',
            '410306': 'Fair Value Gains',
            '410307': 'Endowment Income',
            '410308': 'Donations',
            '410309': 'Grants',
            '410310': 'Write Back',
            '510101': 'Cost of Sales',
            '510102': 'Cost of Goods',
            '510103': 'Cost of Sales',
            '510104': 'Event Fee',
            '510201': 'Marketing & Advertisement Expenses',
            '510301': 'IT & Software Expenses',
            '510401': 'Telephone & Internet',
            '510501': 'Professional Fee & Consultancy',
            '510601': 'Legal & Government Fee',
            '510701': "Director's Salary",
            '510801': 'Office Staff Salaries',
            '510802': 'Coaching Staff Salaries',
            '510803': 'Employee Benefits & Allowances',
            '510804': 'Bonus & Incentives',
            '510805': 'Staff Welfare',
            '510901': 'Audit Fee',
            '510902': 'Accounting & Bookkeeping Fee',
            '511001': 'Office Rent',
            '511002': 'Miscellaneous Rent',
            '511101': 'Office Utilities',
            '511201': 'Printing Cost',
            '511202': 'Stationary',
            '511301': 'Travel & Accommodation Expense',
            '511302': 'Local Accommodation Expense',
            '511401': 'Depreciation Expense',
            '511402': 'Amortization Expense',
            '511501': 'Courier Expenses',
            '511601': 'Commission Expense',
            '511701': 'Cleaning Expense',
            '511801': 'Repair & Maintenance',
            '511901': 'Other Expenses',
            '512001': 'Penalties & Fines',
            '512101': 'Donation & Charity',
            '512201': 'Other Expenses',
            '512202': 'Charitable Activities',
            '512301': 'Bank Charges & Fees',
            '512401': 'Interest Expense',
            '512501': 'Business Insurance',
            '512601': 'Trade License',
            '512602': 'Establishment Card',
            '512603': 'Visa Fee',
            '512701': 'Corporate Tax Expense',
            '512801': 'Office Expense',
        }

        group_labels = _build_group_label_map([
            NON_CURRENT_ASSET_GROUPS,
            CURRENT_ASSET_GROUPS,
            NON_CURRENT_LIABILITY_GROUPS,
            CURRENT_LIABILITY_GROUPS,
            EQUITY_GROUPS,
            REVENUE_GROUPS,
            OTHER_INCOME_GROUPS,
            COST_OF_REVENUE_GROUPS,
            DEPRECIATION_GROUPS,
        ])

        # Current year balances (as of date_end)
        current_rows = _fetch_account_rows(balance_sheet_date_start, date_end)
        current_account_heads = _build_account_head_map(current_rows)
        current_prefix_totals = {
            1: _sum_by_prefix(current_rows, 1),
            2: _sum_by_prefix(current_rows, 2),
            4: _sum_by_prefix(current_rows, 4),
            6: _sum_by_prefix(current_rows, 6),
            8: _sum_by_prefix(current_rows, 8),
        }
        current_group_totals = current_prefix_totals[4]
        current_main_heads = _label_group_totals(current_group_totals, MAIN_HEAD_LABELS)
        current_subheads_by_group = _build_subhead_groups(
            current_prefix_totals[6],
            SUBHEAD_LABELS,
        )
        current_ppe_subheads = {
            row['name']: row['balance']
            for row in current_subheads_by_group.get('1101', [])
        }
        current_ppe_total = sum(current_ppe_subheads.values())

        annotated_rows = _annotate_rows(current_rows, group_labels)
        balance_rows = [row for row in annotated_rows if row['one_digit_code'] in ('1', '2', '3')]
        period_rows = _fetch_account_rows(date_start, date_end)
        period_account_heads = _build_account_head_map(period_rows)
        period_prefix_totals = {
            1: _sum_by_prefix(period_rows, 1),
            2: _sum_by_prefix(period_rows, 2),
            4: _sum_by_prefix(period_rows, 4),
            6: _sum_by_prefix(period_rows, 6),
            8: _sum_by_prefix(period_rows, 8),
        }
        period_group_totals = period_prefix_totals[4]
        period_annotated_rows = _annotate_rows(period_rows, group_labels)
        profit_loss_accounts = [
            row for row in period_annotated_rows
            if row['one_digit_code'] in ('4', '5')
        ]



        current_assets = _build_section_totals(current_group_totals, CURRENT_ASSET_GROUPS)
        non_current_assets = _build_section_totals(current_group_totals, NON_CURRENT_ASSET_GROUPS)
        current_liabilities = _build_section_totals(current_group_totals, CURRENT_LIABILITY_GROUPS)
        non_current_liabilities = _build_section_totals(current_group_totals, NON_CURRENT_LIABILITY_GROUPS)
        equity = _build_section_totals(current_group_totals, EQUITY_GROUPS)

        current_assets_total = sum(current_assets.values())
        non_current_assets_total = sum(non_current_assets.values())
        total_assets = current_assets_total + non_current_assets_total


        current_liabilities_total = sum(current_liabilities.values())
        non_current_liabilities_total = sum(non_current_liabilities.values())
        total_liabilities = -(current_liabilities_total + non_current_liabilities_total)

        total_equity = sum(equity.values())
        total_of_equity_and_liabilities = total_equity + total_liabilities

        # PnL (current year)
        revenue_total = sum(
            period_group_totals.get(code, 0.0)
            for code in REVENUE_GROUPS['Revenue']
        )
        revenue_total = -(revenue_total)
        other_income_total = sum(
            period_group_totals.get(code, 0.0)
            for code in OTHER_INCOME_GROUPS['Other income']
        )
        other_income_total = -(other_income_total)
        cost_of_revenue_total = sum(
            period_group_totals.get(code, 0.0)
            for code in COST_OF_REVENUE_GROUPS['Cost of revenue']
        )
        depreciation_total = sum(
            period_group_totals.get(code, 0.0)
            for code in DEPRECIATION_GROUPS['Depreciation']
        )
        expense_total = period_prefix_totals[2].get('51', 0.0)
        tax_expense_ledger = period_group_totals.get('5127', 0.0)
        operating_expenses_total = expense_total - cost_of_revenue_total - tax_expense_ledger

        gross_profit = revenue_total - cost_of_revenue_total
        net_profit_before_tax = gross_profit - operating_expenses_total + other_income_total
        tax_amount = 0.0
        net_profit_after_tax = net_profit_before_tax

        if net_profit_before_tax > 375000:
            tax_amount = (net_profit_before_tax - 375000) * 0.09
            net_profit_after_tax = net_profit_before_tax - tax_amount

        if tax_amount:
            current_group_totals = dict(current_group_totals)
            current_group_totals['2204'] = current_group_totals.get('2204', 0.0) - tax_amount
            current_liabilities = _build_section_totals(current_group_totals, CURRENT_LIABILITY_GROUPS)
            current_liabilities_total = sum(current_liabilities.values())
            total_liabilities = -(current_liabilities_total + non_current_liabilities_total)

        def _calc_margin(amount, base):
            if not base:
                return 0.0
            return (amount / base) * 100.0

        def _net_label(current, prev, period_word, suffix=None):
            label_base = "Net profit/(loss)" if (current or 0.0) < 0 or (prev or 0.0) < 0 else "Net profit"
            label = f"{label_base} for the {period_word}"
            if suffix:
                label = f"{label} {suffix}"
            return label

        gross_profit_margin = _calc_margin(gross_profit, revenue_total)
        net_profit_margin = _calc_margin(net_profit_after_tax, revenue_total)

        # Prior year balances (as of prior_date_end)
        prev_rows = _fetch_account_rows(prior_balance_sheet_date_start, prior_date_end)
        prev_account_heads = _build_account_head_map(prev_rows)
        prev_prefix_totals = {
            1: _sum_by_prefix(prev_rows, 1),
            2: _sum_by_prefix(prev_rows, 2),
            4: _sum_by_prefix(prev_rows, 4),
            6: _sum_by_prefix(prev_rows, 6),
            8: _sum_by_prefix(prev_rows, 8),
        }
        prev_group_totals = prev_prefix_totals[4]

        def _sum_prefix_group(prefix_totals, prefixes):
            return sum(prefix_totals.get(code, 0.0) for code in prefixes)

        def _sum_other_receivables(prefix_totals):
            return sum(
                value
                for code, value in prefix_totals.items()
                if code.startswith('1203') and code not in ('120301', '120302')
            )

        def _has_amount(*values):
            return any(abs(value) > 0.0 for value in values)

        advances_current = _sum_prefix_group(current_prefix_totals[6], ['120301'])
        advances_prev = _sum_prefix_group(prev_prefix_totals[6], ['120301'])
        prepaid_current = _sum_prefix_group(current_prefix_totals[6], ['120302'])
        prepaid_prev = _sum_prefix_group(prev_prefix_totals[6], ['120302'])
        other_receivables_current = _sum_other_receivables(current_prefix_totals[6])
        other_receivables_prev = _sum_other_receivables(prev_prefix_totals[6])

        receivable_parts = []
        if _has_amount(prepaid_current, prepaid_prev):
            receivable_parts.append('Prepayment')
        if _has_amount(advances_current, advances_prev):
            receivable_parts.append('Advances')
        if _has_amount(other_receivables_current, other_receivables_prev):
            receivable_parts.append('Other receivables')

        receivable_label = None
        if receivable_parts:
            if len(receivable_parts) == 1:
                receivable_label = receivable_parts[0]
            elif len(receivable_parts) == 2:
                receivable_label = f"{receivable_parts[0]} and {receivable_parts[1]}"
            else:
                receivable_label = f"{receivable_parts[0]}, {receivable_parts[1]} and {receivable_parts[2]}"
            MAIN_HEAD_LABELS['1203'] = receivable_label

        prev_prev_rows = _fetch_account_rows(prior_prior_balance_sheet_date_start, prior_prior_date_end)
        prev_prev_account_heads = _build_account_head_map(prev_prev_rows)
        prev_prev_prefix_totals = {
            1: _sum_by_prefix(prev_prev_rows, 1),
            2: _sum_by_prefix(prev_prev_rows, 2),
            4: _sum_by_prefix(prev_prev_rows, 4),
            6: _sum_by_prefix(prev_prev_rows, 6),
            8: _sum_by_prefix(prev_prev_rows, 8),
        }
        prev_prev_group_totals = prev_prev_prefix_totals[4]
        prev_period_rows = _fetch_account_rows(prior_date_start, prior_date_end)
        prev_period_account_heads = _build_account_head_map(prev_period_rows)
        prev_period_prefix_totals = {
            1: _sum_by_prefix(prev_period_rows, 1),
            2: _sum_by_prefix(prev_period_rows, 2),
            4: _sum_by_prefix(prev_period_rows, 4),
            6: _sum_by_prefix(prev_period_rows, 6),
            8: _sum_by_prefix(prev_period_rows, 8),
        }
        prev_period_group_totals = prev_period_prefix_totals[4]
        prev_prev_period_rows = _fetch_account_rows(prior_prior_date_start, prior_prior_date_end)
        prev_prev_period_account_heads = _build_account_head_map(prev_prev_period_rows)
        prev_prev_period_prefix_totals = {
            1: _sum_by_prefix(prev_prev_period_rows, 1),
            2: _sum_by_prefix(prev_prev_period_rows, 2),
            4: _sum_by_prefix(prev_prev_period_rows, 4),
            6: _sum_by_prefix(prev_prev_period_rows, 6),
            8: _sum_by_prefix(prev_prev_period_rows, 8),
        }
        prev_prev_period_group_totals = prev_prev_period_prefix_totals[4]
        prev_main_heads = _label_group_totals(prev_group_totals, MAIN_HEAD_LABELS)
        prev_subheads_by_group = _build_subhead_groups(
            prev_prefix_totals[6],
            SUBHEAD_LABELS,
        )
        prev_ppe_subheads = {
            row['name']: row['balance']
            for row in prev_subheads_by_group.get('1101', [])
        }
        prev_ppe_total = sum(prev_ppe_subheads.values())

        prev_current_assets = _build_section_totals(prev_group_totals, CURRENT_ASSET_GROUPS)
        prev_non_current_assets = _build_section_totals(prev_group_totals, NON_CURRENT_ASSET_GROUPS)
        prev_current_liabilities = _build_section_totals(prev_group_totals, CURRENT_LIABILITY_GROUPS)
        prev_non_current_liabilities = _build_section_totals(prev_group_totals, NON_CURRENT_LIABILITY_GROUPS)
        prev_equity = _build_section_totals(prev_group_totals, EQUITY_GROUPS)
        prev_prev_current_assets = _build_section_totals(prev_prev_group_totals, CURRENT_ASSET_GROUPS)

        prev_current_assets_total = sum(prev_current_assets.values())
        prev_non_current_assets_total = sum(prev_non_current_assets.values())
        prev_total_assets = prev_current_assets_total + prev_non_current_assets_total

        prev_current_liabilities_total = sum(prev_current_liabilities.values())
        prev_non_current_liabilities_total = sum(prev_non_current_liabilities.values())
        prev_total_liabilities = -(prev_current_liabilities_total + prev_non_current_liabilities_total)

        prev_equity_total = sum(prev_equity.values())
        prev_total_equity = prev_equity_total
        prev_total_of_equity_and_liabilities = prev_total_equity + prev_total_liabilities

        prev_revenue_total = sum(
            prev_period_group_totals.get(code, 0.0)
            for code in REVENUE_GROUPS['Revenue']
        )
        prev_revenue_total = -(prev_revenue_total)
        prev_other_income_total = sum(
            prev_period_group_totals.get(code, 0.0)
            for code in OTHER_INCOME_GROUPS['Other income']
        )
        prev_other_income_total = -(prev_other_income_total)
        prev_cost_of_revenue_total = sum(
            prev_period_group_totals.get(code, 0.0)
            for code in COST_OF_REVENUE_GROUPS['Cost of revenue']
        )
        prev_depreciation_total = sum(
            prev_period_group_totals.get(code, 0.0)
            for code in DEPRECIATION_GROUPS['Depreciation']
        )
        prev_expense_total = prev_period_prefix_totals[2].get('51', 0.0)
        prev_tax_expense_ledger = prev_period_group_totals.get('5127', 0.0)
        prev_operating_expenses_total = (
            prev_expense_total - prev_cost_of_revenue_total - prev_tax_expense_ledger
        )

        prev_gross_profit = prev_revenue_total - prev_cost_of_revenue_total
        prev_net_profit_before_tax = (
            prev_gross_profit - prev_operating_expenses_total + prev_other_income_total
        )
        prev_tax_amount = 0.0
        prev_net_profit_after_tax = prev_net_profit_before_tax

        if prev_net_profit_before_tax > 375000:
            prev_tax_amount = (prev_net_profit_before_tax - 375000) * 0.09
            prev_net_profit_after_tax = prev_net_profit_before_tax - prev_tax_amount

        if prev_tax_amount:
            prev_group_totals = dict(prev_group_totals)
            prev_group_totals['2204'] = prev_group_totals.get('2204', 0.0) - prev_tax_amount
            prev_current_liabilities = _build_section_totals(prev_group_totals, CURRENT_LIABILITY_GROUPS)
            prev_current_liabilities_total = sum(prev_current_liabilities.values())
            prev_total_liabilities = -(prev_current_liabilities_total + prev_non_current_liabilities_total)

        prev_gross_profit_margin = _calc_margin(prev_gross_profit, prev_revenue_total)
        prev_net_profit_margin = _calc_margin(prev_net_profit_after_tax, prev_revenue_total)

        label_prev_net_profit_before_tax = prev_net_profit_before_tax if show_prior_year else 0.0
        label_prev_net_profit_after_tax = prev_net_profit_after_tax if show_prior_year else 0.0
        period_word = "period" if not show_prior_year else "year"
        show_after_tax_line = bool(
            (tax_amount or (show_prior_year and prev_tax_amount))
            and (net_profit_after_tax or (show_prior_year and prev_net_profit_after_tax))
        )
        before_tax_suffix = "before tax" if show_after_tax_line else None
        net_profit_before_tax_label = _net_label(
            net_profit_before_tax,
            label_prev_net_profit_before_tax,
            period_word,
            before_tax_suffix,
        )
        net_profit_after_tax_label = _net_label(
            net_profit_after_tax,
            label_prev_net_profit_after_tax,
            period_word,
            "after tax",
        )

        prev_prev_revenue_total = sum(
            prev_prev_period_group_totals.get(code, 0.0)
            for code in REVENUE_GROUPS['Revenue']
        )
        prev_prev_revenue_total = -(prev_prev_revenue_total)
        prev_prev_other_income_total = sum(
            prev_prev_period_group_totals.get(code, 0.0)
            for code in OTHER_INCOME_GROUPS['Other income']
        )
        prev_prev_other_income_total = -(prev_prev_other_income_total)
        prev_prev_cost_of_revenue_total = sum(
            prev_prev_period_group_totals.get(code, 0.0)
            for code in COST_OF_REVENUE_GROUPS['Cost of revenue']
        )
        prev_prev_depreciation_total = sum(
            prev_prev_period_group_totals.get(code, 0.0)
            for code in DEPRECIATION_GROUPS['Depreciation']
        )
        prev_prev_expense_total = prev_prev_period_prefix_totals[2].get('51', 0.0)
        prev_prev_tax_expense_ledger = prev_prev_period_group_totals.get('5127', 0.0)
        prev_prev_operating_expenses_total = (
            prev_prev_expense_total - prev_prev_cost_of_revenue_total - prev_prev_tax_expense_ledger
        )
        prev_prev_gross_profit = prev_prev_revenue_total - prev_prev_cost_of_revenue_total
        prev_prev_net_profit_before_tax = (
            prev_prev_gross_profit
            - prev_prev_operating_expenses_total
            + prev_prev_other_income_total
        )
        prev_prev_tax_amount = 0.0
        prev_prev_net_profit_after_tax = prev_prev_net_profit_before_tax

        if prev_prev_net_profit_before_tax > 375000:
            prev_prev_tax_amount = (prev_prev_net_profit_before_tax - 375000) * 0.09
            prev_prev_net_profit_after_tax = prev_prev_net_profit_before_tax - prev_prev_tax_amount

        note_number = 5
        note_numbers = {}
        note_sections = []
        note_labels = dict(MAIN_HEAD_LABELS)
        if receivable_label:
            note_labels['1203'] = receivable_label

        note_prev_account_heads = prev_account_heads if show_prior_year else {}
        note_prev_group_totals = prev_group_totals if show_prior_year else {}
        note_prev_period_account_heads = prev_period_account_heads if show_prior_year else {}
        note_prev_period_group_totals = prev_period_group_totals if show_prior_year else {}

        def _sort_operating_expense_lines(lines):
            top_codes = ['51070101', '51080101']
            bottom_codes = ['51230101', '51220102']
            top_set = set(top_codes)
            bottom_set = set(bottom_codes)
            top_lines = [line for code in top_codes for line in lines if line.get('code') == code]
            bottom_lines = [line for code in bottom_codes for line in lines if line.get('code') == code]
            middle_lines = [
                line for line in lines
                if line.get('code') not in top_set and line.get('code') not in bottom_set
            ]
            middle_lines.sort(key=lambda line: (line.get('name') or line.get('code') or '').lower())
            return top_lines + middle_lines + bottom_lines

        def _aggregate_operating_expense_lines(lines):
            fee_codes = {'51260101', '51260201', '51260301'}
            fee_current = 0.0
            fee_prev = 0.0
            aggregated = []
            for line in lines:
                if line.get('code') in fee_codes:
                    fee_current += line.get('current', 0.0)
                    fee_prev += line.get('prev', 0.0)
                    continue
                aggregated.append(line)
            if fee_current or fee_prev:
                aggregated.append({
                    'code': 'fee_subscription',
                    'name': 'Fee and subscription',
                    'current': fee_current,
                    'prev': fee_prev,
                })
            return aggregated

        def _add_note(key, label, group_codes, current_total, prev_total, current_map=None, prev_map=None):
            nonlocal note_number
            lines = _collect_note_lines(
                group_codes,
                current_map or current_account_heads,
                prev_map or note_prev_account_heads,
            )
            if not lines:
                return
            if key == 'pl_opex':
                lines = _aggregate_operating_expense_lines(lines)
                lines = _sort_operating_expense_lines(lines)
            note_numbers[key] = note_number
            note_sections.append({
                'number': note_number,
                'label': label,
                'lines': lines,
                'total_current': current_total,
                'total_prev': prev_total,
            })
            note_number += 1

        non_current_codes = ['1101', '1102', '1103', '1104', '1105', '1106', '1107', '1108', '1109']
        current_codes = ['1201', '1202', '1203', '1204', '1205', '1206']
        equity_codes = ['3101']
        non_current_liability_codes = ['2101', '2102', '2103', '2104']
        current_liability_codes = ['2201', '2202', '2203', '2204']
        aggregated_payables_codes = set(current_liability_codes)
        for code in non_current_codes + current_codes + equity_codes + non_current_liability_codes + current_liability_codes:
            if code in aggregated_payables_codes:
                continue
            current_total = current_group_totals.get(code, 0.0)
            prev_total = note_prev_group_totals.get(code, 0.0)
            if not (current_total or prev_total):
                if code == '3101':
                    if code not in note_numbers:
                        note_numbers[code] = note_number
                        note_sections.append({
                            'number': note_number,
                            'label': note_labels.get(code, code),
                            'lines': [],
                            'total_current': 0.0,
                            'total_prev': 0.0,
                        })
                        note_number += 1
                    if 'retained_earnings' not in note_numbers:
                        note_numbers['retained_earnings'] = note_number
                        note_sections.append({
                            'number': note_number,
                            'label': 'Retained earnings',
                            'lines': [],
                            'total_current': 0.0,
                            'total_prev': 0.0,
                        })
                        note_number += 1
                continue
            _add_note(code, note_labels.get(code, code), [code], current_total, prev_total)
            if code == '3101' and 'retained_earnings' not in note_numbers:
                note_numbers['retained_earnings'] = note_number
                note_sections.append({
                    'number': note_number,
                    'label': 'Retained earnings',
                    'lines': [],
                    'total_current': 0.0,
                    'total_prev': 0.0,
                })
                note_number += 1

        aggregated_payables_current = sum(
            current_group_totals.get(code, 0.0)
            for code in aggregated_payables_codes
        )
        aggregated_payables_prev = sum(
            note_prev_group_totals.get(code, 0.0)
            for code in aggregated_payables_codes
        )
        if aggregated_payables_current or aggregated_payables_prev:
            _add_note(
                'other_payables',
                'Other payables',
                sorted(aggregated_payables_codes),
                aggregated_payables_current,
                aggregated_payables_prev,
            )

        expense_group_codes = sorted({
            code for code in current_group_totals
            if code.startswith('51')
        } | {
            code for code in note_prev_group_totals
            if code.startswith('51')
        })
        cost_codes = set(COST_OF_REVENUE_GROUPS['Cost of revenue'])
        depreciation_codes = set(DEPRECIATION_GROUPS['Depreciation'])
        tax_codes = {'5127'}
        operating_expense_codes = [
            code
            for code in expense_group_codes
            if code not in cost_codes | depreciation_codes | tax_codes
        ]

        note_prev_revenue_total = prev_revenue_total if show_prior_year else 0.0
        note_prev_cost_of_revenue_total = prev_cost_of_revenue_total if show_prior_year else 0.0
        note_prev_operating_expenses_total = prev_operating_expenses_total if show_prior_year else 0.0
        if revenue_total or note_prev_revenue_total:
            _add_note(
                'pl_revenue',
                'Revenue',
                REVENUE_GROUPS['Revenue'],
                revenue_total,
                note_prev_revenue_total,
                current_map=period_account_heads,
                prev_map=note_prev_period_account_heads,
            )
        if cost_of_revenue_total or note_prev_cost_of_revenue_total:
            _add_note(
                'pl_cost',
                'Cost of revenue',
                COST_OF_REVENUE_GROUPS['Cost of revenue'],
                cost_of_revenue_total,
                note_prev_cost_of_revenue_total,
                current_map=period_account_heads,
                prev_map=note_prev_period_account_heads,
            )
        if operating_expenses_total or note_prev_operating_expenses_total:
            current_total = sum(period_group_totals.get(code, 0.0) for code in operating_expense_codes)
            prev_total = sum(note_prev_period_group_totals.get(code, 0.0) for code in operating_expense_codes)
            _add_note(
                'pl_opex',
                'Operating expenses',
                operating_expense_codes,
                current_total,
                prev_total,
                current_map=period_account_heads,
                prev_map=note_prev_period_account_heads,
            )

        post_table_note_keys = []
        if self.show_related_parties_note:
            post_table_note_keys.append('related_parties')
        post_table_note_keys.extend([
            'risk_management',
            'financial_assets_liabilities',
            'contingent_liabilities',
            'general_notes',
        ])
        for key in post_table_note_keys:
            note_numbers[key] = note_number
            note_number += 1
        last_note_number = note_number - 1

        opening_date_end = date_start - relativedelta(days=1) if date_start else False
        opening_rows = _fetch_account_rows(False, opening_date_end)
        opening_prefix_totals = {
            1: _sum_by_prefix(opening_rows, 1),
            2: _sum_by_prefix(opening_rows, 2),
            4: _sum_by_prefix(opening_rows, 4),
            6: _sum_by_prefix(opening_rows, 6),
            8: _sum_by_prefix(opening_rows, 8),
        }
        opening_group_totals = opening_prefix_totals[4]

        if show_prior_year:
            prior_opening_date_end = prior_date_start - relativedelta(days=1) if prior_date_start else False
            prior_opening_rows = _fetch_account_rows(False, prior_opening_date_end)
            prior_opening_prefix_totals = {
                1: _sum_by_prefix(prior_opening_rows, 1),
                2: _sum_by_prefix(prior_opening_rows, 2),
                4: _sum_by_prefix(prior_opening_rows, 4),
                6: _sum_by_prefix(prior_opening_rows, 6),
                8: _sum_by_prefix(prior_opening_rows, 8),
            }
        else:
            prior_opening_prefix_totals = {
                1: {},
                2: {},
                4: {},
                6: {},
                8: {},
            }
        prior_opening_group_totals = prior_opening_prefix_totals[4]

        ###### Variables for Cash Flow Statement ######
        eosb_liability_code = '21040101'
        owner_current_account_code = '12040102'
        dividend_paid_code = '31010202'
        tax_liability_code = '2204'
        tax_expense_code = '512701'

        def _liability_to_positive(value):
            return -value

        current_depreciation_total = period_group_totals.get('5114', 0.0)
        prior_depreciation_total = prev_period_group_totals.get('5114', 0.0)

        eosb_movement = _liability_to_positive(period_prefix_totals[8].get(eosb_liability_code, 0.0))
        prior_eosb_movement = _liability_to_positive(prev_period_prefix_totals[8].get(eosb_liability_code, 0.0))

        end_service_benefits_adjustment = max(eosb_movement, 0.0)
        prior_end_service_benefits_adjustment = max(prior_eosb_movement, 0.0)
        end_service_benefits_paid = -max(-eosb_movement, 0.0)
        prior_end_service_benefits_paid = -max(-prior_eosb_movement, 0.0)

        operating_cashflow_before_working_capital = (
            net_profit_before_tax
            + current_depreciation_total
            + end_service_benefits_adjustment
        )
        prior_operating_cashflow_before_working_capital = (
            prev_net_profit_before_tax
            + prior_depreciation_total
            + prior_end_service_benefits_adjustment
        )

        current_wc_assets = (
            current_group_totals.get('1201', 0.0)
            + current_group_totals.get('1202', 0.0)
            + current_group_totals.get('1203', 0.0)
        )
        opening_wc_assets = (
            opening_group_totals.get('1201', 0.0)
            + opening_group_totals.get('1202', 0.0)
            + opening_group_totals.get('1203', 0.0)
        )
        prior_wc_assets = (
            prev_group_totals.get('1201', 0.0)
            + prev_group_totals.get('1202', 0.0)
            + prev_group_totals.get('1203', 0.0)
        )
        prior_opening_wc_assets = (
            prior_opening_group_totals.get('1201', 0.0)
            + prior_opening_group_totals.get('1202', 0.0)
            + prior_opening_group_totals.get('1203', 0.0)
        )

        change_in_current_assets = -(current_wc_assets - opening_wc_assets)
        prior_change_in_current_assets = -(prior_wc_assets - prior_opening_wc_assets)

        current_wc_liabilities = _liability_to_positive(
            current_group_totals.get('2202', 0.0) + current_group_totals.get('2203', 0.0)
        )
        opening_wc_liabilities = _liability_to_positive(
            opening_group_totals.get('2202', 0.0) + opening_group_totals.get('2203', 0.0)
        )
        prior_wc_liabilities = _liability_to_positive(
            prev_group_totals.get('2202', 0.0) + prev_group_totals.get('2203', 0.0)
        )
        prior_opening_wc_liabilities = _liability_to_positive(
            prior_opening_group_totals.get('2202', 0.0) + prior_opening_group_totals.get('2203', 0.0)
        )

        change_in_current_liabilities = current_wc_liabilities - opening_wc_liabilities
        prior_change_in_current_liabilities = prior_wc_liabilities - prior_opening_wc_liabilities

        current_tax_liability = _liability_to_positive(current_group_totals.get(tax_liability_code, 0.0))
        opening_tax_liability = _liability_to_positive(opening_group_totals.get(tax_liability_code, 0.0))
        prior_tax_liability = _liability_to_positive(prev_group_totals.get(tax_liability_code, 0.0))
        prior_opening_tax_liability = _liability_to_positive(
            prior_opening_group_totals.get(tax_liability_code, 0.0)
        )
        current_tax_expense = period_prefix_totals[6].get(tax_expense_code, 0.0)
        prior_tax_expense = prev_period_prefix_totals[6].get(tax_expense_code, 0.0)

        corporate_tax_paid = -(opening_tax_liability + current_tax_expense - current_tax_liability)
        prior_corporate_tax_paid = -(prior_opening_tax_liability + prior_tax_expense - prior_tax_liability)

        net_cash_generated_from_operations = (
            operating_cashflow_before_working_capital
            + change_in_current_assets
            + change_in_current_liabilities
            + corporate_tax_paid
            + end_service_benefits_paid
        )
        prior_net_cash_generated_from_operations = (
            prior_operating_cashflow_before_working_capital
            + prior_change_in_current_assets
            + prior_change_in_current_liabilities
            + prior_corporate_tax_paid
            + prior_end_service_benefits_paid
        )

        current_property = -(period_group_totals.get('1101', 0.0))
        prior_property = -(prev_period_group_totals.get('1101', 0.0))
        net_cash_generated_from_investing_activities = current_property
        prior_net_cash_generated_from_investing_activities = prior_property

        company = self.company_id
        company_share_capital_total = sum(
            (getattr(company, f'total_share_{i}', 0.0) or 0.0)
            for i in range(1, 11)
        )
        paid_up_capital = company_share_capital_total
        prior_paid_up_capital = company_share_capital_total if show_prior_year else 0.0

        current_dividend = current_prefix_totals[8].get(dividend_paid_code, 0.0)
        opening_dividend = opening_prefix_totals[8].get(dividend_paid_code, 0.0)
        prior_dividend = prev_prefix_totals[8].get(dividend_paid_code, 0.0)
        prior_opening_dividend = prior_opening_prefix_totals[8].get(dividend_paid_code, 0.0)
        dividend_paid = -(current_dividend - opening_dividend)
        prior_dividend_paid = -(prior_dividend - prior_opening_dividend)

        current_owner_ca = current_prefix_totals[8].get(owner_current_account_code, 0.0)
        opening_owner_ca = opening_prefix_totals[8].get(owner_current_account_code, 0.0)
        prior_owner_ca = prev_prefix_totals[8].get(owner_current_account_code, 0.0)
        prior_opening_owner_ca = prior_opening_prefix_totals[8].get(owner_current_account_code, 0.0)
        owner_current_account = -(current_owner_ca - opening_owner_ca)
        prior_owner_current_account = -(prior_owner_ca - prior_opening_owner_ca)

        net_cash_generated_from_financing_activities = (
            paid_up_capital + dividend_paid + owner_current_account
        )
        prior_net_cash_generated_from_financing_activities = (
            prior_paid_up_capital + prior_dividend_paid + prior_owner_current_account
        )

        current_cash_and_bank = current_group_totals.get('1204', 0.0)
        current_wallets = current_group_totals.get('1205', 0.0)
        current_interbank = current_group_totals.get('1206', 0.0)
        opening_cash_and_bank = opening_group_totals.get('1204', 0.0)
        opening_wallets = opening_group_totals.get('1205', 0.0)
        opening_interbank = opening_group_totals.get('1206', 0.0)
        prior_cash_and_bank = prev_group_totals.get('1204', 0.0)
        prior_wallets = prev_group_totals.get('1205', 0.0)
        prior_interbank = prev_group_totals.get('1206', 0.0)
        prior_opening_cash_and_bank = prior_opening_group_totals.get('1204', 0.0)
        prior_opening_wallets = prior_opening_group_totals.get('1205', 0.0)
        prior_opening_interbank = prior_opening_group_totals.get('1206', 0.0)

        current_cash_equivalents = (
            current_cash_and_bank + current_wallets - current_interbank - current_owner_ca
        )
        opening_cash_equivalents = (
            opening_cash_and_bank + opening_wallets - opening_interbank - opening_owner_ca
        )
        prior_cash_equivalents = (
            prior_cash_and_bank + prior_wallets - prior_interbank - prior_owner_ca
        )
        prior_opening_cash_equivalents = (
            prior_opening_cash_and_bank + prior_opening_wallets - prior_opening_interbank - prior_opening_owner_ca
        )

        net_cash_and_cash_equivalents = (
            net_cash_generated_from_operations
            + net_cash_generated_from_investing_activities
            + net_cash_generated_from_financing_activities
        )
        cash_beginning_year = opening_cash_equivalents
        cash_end_of_year = current_cash_equivalents

        prior_net_cash_and_cash_equivalents = (
            prior_net_cash_generated_from_operations
            + prior_net_cash_generated_from_investing_activities
            + prior_net_cash_generated_from_financing_activities
        )
        prior_cash_beginning_year = prior_opening_cash_equivalents
        prior_cash_end_of_year = prior_cash_equivalents


        ##############################################################################################

        ############# Shareholders Section #############


        # Shareholders START #
        #########################################################################################################
        company = self.company_id
        # Shareholders (explicit variables)
        sh_name_1 = company.shareholder_1
        sh_nat_1 = company.nationality_1
        sh_shares_1 = company.number_of_shares_1
        sh_value_1 = company.share_value_1
        sh_total_1 = company.total_share_1

        sh_name_2 = company.shareholder_2
        sh_nat_2 = company.nationality_2
        sh_shares_2 = company.number_of_shares_2
        sh_value_2 = company.share_value_2
        sh_total_2 = company.total_share_2

        sh_name_3 = company.shareholder_3
        sh_nat_3 = company.nationality_3
        sh_shares_3 = company.number_of_shares_3
        sh_value_3 = company.share_value_3
        sh_total_3 = company.total_share_3

        sh_name_4 = company.shareholder_4
        sh_nat_4 = company.nationality_4
        sh_shares_4 = company.number_of_shares_4
        sh_value_4 = company.share_value_4
        sh_total_4 = company.total_share_4

        sh_name_5 = company.shareholder_5
        sh_nat_5 = company.nationality_5
        sh_shares_5 = company.number_of_shares_5
        sh_value_5 = company.share_value_5
        sh_total_5 = company.total_share_5

        sh_name_6 = company.shareholder_6
        sh_nat_6 = company.nationality_6
        sh_shares_6 = company.number_of_shares_6
        sh_value_6 = company.share_value_6
        sh_total_6 = company.total_share_6

        sh_name_7 = company.shareholder_7
        sh_nat_7 = company.nationality_7
        sh_shares_7 = company.number_of_shares_7
        sh_value_7 = company.share_value_7
        sh_total_7 = company.total_share_7

        sh_name_8 = company.shareholder_8
        sh_nat_8 = company.nationality_8
        sh_shares_8 = company.number_of_shares_8
        sh_value_8 = company.share_value_8
        sh_total_8 = company.total_share_8

        sh_name_9 = company.shareholder_9
        sh_nat_9 = company.nationality_9
        sh_shares_9 = company.number_of_shares_9
        sh_value_9 = company.share_value_9
        sh_total_9 = company.total_share_9

        sh_name_10 = company.shareholder_10
        sh_nat_10 = company.nationality_10
        sh_shares_10 = company.number_of_shares_10
        sh_value_10 = company.share_value_10
        sh_total_10 = company.total_share_10

        share_rows = []
        for i in range(1, 11):
            name = getattr(company, f'shareholder_{i}', False)
            if not name:
                continue
            share_rows.append({
                'name': name,
                'value': getattr(company, f'share_value_{i}', 0.0) or 0.0,
                'shares': getattr(company, f'number_of_shares_{i}', 0) or 0,
                'total': getattr(company, f'total_share_{i}', 0.0) or 0.0,
            })

        authorized_share_capital = sum(row['total'] for row in share_rows)
        total_shares_count = sum(row['shares'] for row in share_rows)
        share_value_default = share_rows[0]['value'] if share_rows else 0.0

        signature_names = [
            name.strip()
            for name in (
                sh_name_1,
                sh_name_2,
                sh_name_3,
                sh_name_4,
                sh_name_5,
                sh_name_6,
                sh_name_7,
                sh_name_8,
                sh_name_9,
                sh_name_10,
            )
            if name and name.strip()
        ]

        signature_display_names = []
        for i in range(1, 11):
            name = getattr(company, f'shareholder_{i}', False)
            if not name:
                continue
            nationality = getattr(company, f'nationality_{i}', False)
            if nationality:
                signature_display_names.append(f"{name} – {nationality}")
            else:
                signature_display_names.append(name)

        shareholder_display_names = []
        for i in range(1, 11):
            name = getattr(company, f'shareholder_{i}', False)
            if not name:
                continue
            nationality = getattr(company, f'nationality_{i}', False)
            if nationality:
                shareholder_display_names.append(f"{name} ({nationality})")
            else:
                shareholder_display_names.append(name)

        def _join_names(names):
            if not names:
                return ''
            if len(names) == 1:
                return names[0]
            if len(names) == 2:
                return f"{names[0]} and {names[1]}"
            return f"{', '.join(names[:-1])} and {names[-1]}"

        shareholder_display_text = _join_names(shareholder_display_names)
        generated_date = fields.Date.context_today(self)
        generated_date_display = generated_date.strftime("%d/%m/%Y") if generated_date else ''

        def _format_long_date(date_value):
            return date_value.strftime('%d %B %Y') if date_value else ''

        emphasis_note_items = []
        emphasis_note_lines = []
        emphasis_sub_note = 6

        def _next_emphasis_note_ref():
            nonlocal emphasis_sub_note
            note_ref = f'1.{emphasis_sub_note}'
            emphasis_sub_note += 1
            return note_ref

        if self.emphasis_change_period:
            changed_from = _format_long_date(
                fields.Date.to_date(self.emphasis_change_from_date) if self.emphasis_change_from_date else None
            )
            changed_to = _format_long_date(
                fields.Date.to_date(self.emphasis_change_to_date) if self.emphasis_change_to_date else None
            )
            change_period_note_ref = _next_emphasis_note_ref()
            emphasis_note_items.append({
                'key': 'change_period',
                'label': 'Change in Financial Year/Period',
                'note_ref': change_period_note_ref,
                'matter_text': (
                    f"the change in the Entity’s financial reporting period from {changed_from} "
                    f"to {changed_to}"
                ),
            })
            emphasis_note_lines.append({
                'note_ref': change_period_note_ref,
                'note_text': (
                    f"The Entity previously issued audited financial statements for the period ended {changed_from}. "
                    f"To align with regulatory requirements, the Entity has revised its financial reporting period to "
                    f"{changed_to}, and this change has been applied retrospectively. Accordingly, the comparative "
                    f"information presented is for the period ended {changed_to}."
                ),
            })

        if self.additional_note_legal_status_change:
            legal_change_date = _format_long_date(
                fields.Date.to_date(self.emphasis_legal_change_date) if self.emphasis_legal_change_date else None
            )
            legal_status_from = (self.emphasis_legal_status_from or '').strip()
            legal_status_to = (self.emphasis_legal_status_to or '').strip()
            legal_registration_authority = (getattr(company, 'free_zone', '') or '').strip()
            if not legal_registration_authority:
                legal_registration_authority = 'Department of Economy and Tourism'
            emphasis_note_lines.append({
                'note_ref': _next_emphasis_note_ref(),
                'note_text': (
                    f'On {legal_change_date}, the Entity officially changed its legal status from "{legal_status_from}" '
                    f'to "{legal_status_to}". The change was approved by the Director and has been '
                    f'registered with the {legal_registration_authority}, Dubai, United Arab Emirates.'
                ),
            })

        if self.additional_note_no_active_bank_account:
            emphasis_note_lines.append({
                'note_ref': _next_emphasis_note_ref(),
                'note_text': (
                    f"{(self.company_name or 'The Entity').upper()} (the Entity) currently has no active bank account. "
                    'All expenses were paid by the Director from his personal resources.'
                ),
            })

        if self.emphasis_correction_error:
            correction_note_ref = _next_emphasis_note_ref()
            emphasis_note_items.append({
                'key': 'correction_error',
                'label': 'Correction of Error',
                'note_ref': correction_note_ref,
                'matter_text': "the correction of a prior period error",
            })
            emphasis_note_lines.append({
                'note_ref': correction_note_ref,
                'note_text': (
                    "The Entity corrected a prior period error and reflected the impact "
                    "in these financial statements."
                ),
            })

        if self.emphasis_liquidation:
            liquidation_note_ref = _next_emphasis_note_ref()
            emphasis_note_items.append({
                'key': 'liquidation',
                'label': 'Liquidation',
                'note_ref': liquidation_note_ref,
                'matter_text': "the Entity’s liquidation",
            })
            emphasis_note_lines.append({
                'note_ref': liquidation_note_ref,
                'note_text': (
                    "Management has resolved to liquidate the Entity and this matter has "
                    "been disclosed in these financial statements."
                ),
            })

        show_emphasis_of_matter = bool(emphasis_note_items)



        # Shareholders END #
        #########################################################################################################

        # Changes in Equity START #
        #########################################################################################################
        total_shares = company_share_capital_total

        retained_earnings_code = '31010203'
        prior_retained_earnings_balance = _equity_head_balance(prev_account_heads, retained_earnings_code)
        prev_prev_retained_earnings_balance = _equity_head_balance(prev_prev_account_heads, retained_earnings_code)
        retained_earnings = net_profit_after_tax
        prev_retained_earnings = prev_net_profit_after_tax
        prev_prev_retained_earnings = prev_prev_net_profit_after_tax
        if show_prior_year:
            # For 2-year reports, each displayed year accumulates NPAT for that
            # year and the immediately preceding year.
            prev_prev_retained_earnings_balance = prev_prev_retained_earnings
            prev_retained_earnings_balance = prev_prev_retained_earnings + prev_retained_earnings
            retained_earnings_balance = prev_prev_retained_earnings + prev_retained_earnings + retained_earnings
        else:
            prev_retained_earnings_balance = prior_retained_earnings_balance
            retained_earnings_balance = prior_retained_earnings_balance + retained_earnings

        equity_total_display = total_shares + retained_earnings_balance
        prev_equity_total_display = total_shares + prev_retained_earnings_balance
        prev_prev_equity_total_display = total_shares + prev_prev_retained_earnings_balance

        # Total Equity to show on the statement of changes in equity
        total_soce = equity_total_display
        prev_total_soce = prev_equity_total_display
        prev_prev_total_soce = prev_prev_equity_total_display
        total_of_equity_and_liabilities = equity_total_display + total_liabilities
        prev_total_of_equity_and_liabilities = prev_equity_total_display + prev_total_liabilities
        show_current_year_profit_line = True
        def _format_date_label(date_value):
            return date_value.strftime('%d %B %Y') if date_value else ''

        def _total_comprehensive_label(amount, period_word):
            profit_or_loss = 'net loss' if (amount or 0.0) < 0 else 'net profit'
            return f"Total comprehensive {profit_or_loss} for the {period_word}"

        soce_rows = []
        if show_prior_year and prior_prior_date_end:
            soce_rows.append({
                'label': f"Balance as at {_format_date_label(prior_prior_date_end)}",
                'share_capital': total_shares,
                'retained_earnings': prev_prev_retained_earnings_balance,
                'total_equity': prev_prev_equity_total_display,
                'is_balance': True,
            })
            if total_shares:
                soce_rows.append({
                    'label': "Share capital",
                    'share_capital': total_shares,
                    'retained_earnings': None,
                    'total_equity': total_shares,
                    'is_balance': False,
                })
        if prior_date_end:
            if show_prior_year:
                soce_rows.append({
                    'label': _total_comprehensive_label(prev_retained_earnings, 'year'),
                    'share_capital': None,
                    'retained_earnings': prev_retained_earnings,
                    'total_equity': prev_retained_earnings,
                    'is_balance': False,
                })
            opening_current_date = date_start if not show_prior_year else prior_date_end
            if not opening_current_date:
                opening_current_date = prior_date_end
            opening_share_capital = None if not show_prior_year else total_shares
            opening_retained_earnings = None if not show_prior_year else prev_retained_earnings_balance
            opening_total_equity = None if not show_prior_year else prev_equity_total_display
            soce_rows.append({
                'label': f"Balance as at {_format_date_label(opening_current_date)}",
                'share_capital': opening_share_capital,
                'retained_earnings': opening_retained_earnings,
                'total_equity': opening_total_equity,
                'is_balance': True,
            })
            if total_shares or not show_prior_year:
                share_capital_value = total_shares
                total_equity_value = total_shares
                soce_rows.append({
                    'label': "Share capital",
                    'share_capital': share_capital_value,
                    'retained_earnings': None,
                    'total_equity': total_equity_value,
                    'is_balance': False,
                })
        if show_current_year_profit_line:
            period_word = "period" if not show_prior_year else "year"
            current_profit_label = _total_comprehensive_label(retained_earnings, period_word)
            soce_rows.append({
                'label': current_profit_label,
                'share_capital': None,
                'retained_earnings': retained_earnings,
                'total_equity': retained_earnings,
                'is_balance': False,
            })
        if date_end:
            soce_rows.append({
                'label': f"Balance as at {date_end.strftime('%d %B %Y')}",
                'share_capital': total_shares,
                'retained_earnings': retained_earnings_balance,
                'total_equity': equity_total_display,
                'is_balance': True,
            })

        # Changes in Equity END #
        #########################################################################################################

        # DMCC Supplementary Sheet START #
        #########################################################################################################
        dmcc_fixed_assets_net = sum(
            account.get('balance', 0.0)
            for account in current_account_heads.get('1101', {}).values()
            if 'accumulated depreciation' not in (account.get('name') or '').strip().lower()
        )
        dmcc_non_current_assets_excl_fixed_assets = non_current_assets_total - dmcc_fixed_assets_net
        dmcc_reserves = abs(current_prefix_totals[8].get('31010301', 0.0))
        dmcc_shareholders_current_account_loans = abs(
            current_prefix_totals[8].get(owner_current_account_code, 0.0)
        )
        dmcc_total_equity_system = equity_total_display
        dmcc_total_salaries = (
            period_group_totals.get('5108', 0.0)
            + period_prefix_totals[8].get('51070101', 0.0)
        )
        dmcc_all_other_expenses = operating_expenses_total - dmcc_total_salaries
        dmcc_sheet_data = {
            'company_name': self.company_name or '',
            'portal_account_no': '',
            'customer_license_no': self.company_license_number or '',
            'year_start_date': date_start.strftime('%d/%m/%Y') if date_start else '',
            'year_end_date': date_end.strftime('%d/%m/%Y') if date_end else '',
            'total_share_capital': total_shares,
            'reserves': dmcc_reserves,
            'retained_earnings': retained_earnings_balance,
            'shareholders_current_account_loans': dmcc_shareholders_current_account_loans,
            'total_equity_system': dmcc_total_equity_system,
            'fixed_assets_net': dmcc_fixed_assets_net,
            'total_depreciation': depreciation_total,
            'current_assets': current_assets_total,
            'non_current_assets_excl_fixed_assets': dmcc_non_current_assets_excl_fixed_assets,
            'total_assets_system': total_assets,
            'current_liabilities': abs(current_liabilities_total),
            'non_current_liabilities': abs(non_current_liabilities_total),
            'total_liabilities_system': total_liabilities,
            'annual_sales_turnover': revenue_total,
            'cost_of_revenue_goods_sold': cost_of_revenue_total,
            'total_salaries': dmcc_total_salaries,
            'all_other_expenses': dmcc_all_other_expenses,
            'all_other_income': other_income_total,
            'gross_profit_loss_system': gross_profit,
            'net_profit_loss_system': net_profit_after_tax,
            'audit_firm_name': 'Assurance Corp Audit and Accounting',
            'auditor_signature': '',
            'auditor_date': generated_date_display,
            'auditor_seal': '',
        }
        # DMCC Supplementary Sheet END #
        #########################################################################################################

        # Statement of Cash Flows START #
        #########################################################################################################


        


        # Statement of Cash Flows END #
        #########################################################################################################

        return {

            # Balance Sheet
            'balance_rows': balance_rows,
            'profit_loss_accounts': profit_loss_accounts,
            'total_assets': total_assets,
            'total_liabilities': total_liabilities,
            'total_equity': equity_total_display,
            'current_assets': current_assets,
            'current_liabilities': current_liabilities,
            'equity': equity,
            'non_current_assets': non_current_assets,
            'non_current_liabilities': non_current_liabilities,
            'current_liabilities_total': current_liabilities_total,
            'non_current_liabilities_total': non_current_liabilities_total,
            'current_assets_total': current_assets_total,
            'non_current_assets_total': non_current_assets_total,
            'total_of_equity_and_liabilities': total_of_equity_and_liabilities,
            'prev_current_assets_total': prev_current_assets_total,
            'prev_non_current_assets_total': prev_non_current_assets_total,
            'prev_total_assets': prev_total_assets,
            'prev_current_liabilities_total': prev_current_liabilities_total,
            'prev_non_current_liabilities_total': prev_non_current_liabilities_total,
            'prev_total_liabilities': prev_total_liabilities,
            'prev_total_equity': prev_equity_total_display,
            'prev_total_of_equity_and_liabilities': prev_total_of_equity_and_liabilities,

            # PnL
             'cost_of_revenue_total':cost_of_revenue_total,
             'depreciation_total':depreciation_total,
             'operating_expenses_total':operating_expenses_total,
             'revenue_total':revenue_total,
             'gross_profit':gross_profit,
             'net_profit_before_tax':net_profit_before_tax,
             'net_profit_after_tax':net_profit_after_tax,
             'other_income_total': other_income_total,
             'gross_profit_margin': gross_profit_margin,
             'net_profit_margin': net_profit_margin,
             'tax_amount':tax_amount,
             'prev_revenue_total': prev_revenue_total,
             'prev_cost_of_revenue_total': prev_cost_of_revenue_total,
             'prev_gross_profit': prev_gross_profit,
             'prev_operating_expenses_total': prev_operating_expenses_total,
             'prev_net_profit_before_tax': prev_net_profit_before_tax,
             'prev_tax_amount': prev_tax_amount,
             'prev_net_profit_after_tax': prev_net_profit_after_tax,
             'prev_other_income_total': prev_other_income_total,
             'prev_gross_profit_margin': prev_gross_profit_margin,
             'prev_net_profit_margin': prev_net_profit_margin,
             'net_profit_before_tax_label': net_profit_before_tax_label,
             'net_profit_after_tax_label': net_profit_after_tax_label,

             # Statement of Changes in Equity
             'retained_earnings':retained_earnings,
            'total_soce':total_soce,
            'prev_retained_earnings': prev_retained_earnings,
            'prev_total_soce': prev_total_soce,
            'prev_prev_retained_earnings': prev_prev_retained_earnings,
            'prev_prev_total_soce': prev_prev_total_soce,
            'share_capital_total': total_shares,
            'prev_share_capital_total': total_shares,
            'retained_earnings_balance': retained_earnings_balance,
            'prev_retained_earnings_balance': prev_retained_earnings_balance,
            'prev_prev_retained_earnings_balance': prev_prev_retained_earnings_balance,
            'equity_total_display': equity_total_display,
            'prev_equity_total_display': prev_equity_total_display,
            'prev_prev_equity_total_display': prev_prev_equity_total_display,
            'soce_rows': soce_rows,
            'signature_names': signature_names,
            'signature_display_names': signature_display_names,
            'shareholder_display_text': shareholder_display_text,
            'generated_date_display': generated_date_display,
            'share_rows': share_rows,
            'authorized_share_capital': authorized_share_capital,
            'total_shares_count': total_shares_count,
            'share_value_default': share_value_default,
            'share_capital_paid_status': self.share_capital_paid_status,
            'related_party_name': self.related_party_name,
            'related_party_relationship': self.related_party_relationship,
            'related_party_transaction': self.related_party_transaction,
            'related_party_amount': self.related_party_amount,
            'related_party_amount_prior': self.related_party_amount_prior,
            'show_related_parties_note': self.show_related_parties_note,
            'gap_report_of_directors': self.gap_report_of_directors,
            'gap_independent_auditor_report': self.gap_independent_auditor_report,
            'gap_notes_to_financial_statements': self.gap_notes_to_financial_statements,
            'signature_break_lines_report_of_directors': max(
                int(self.signature_break_lines_report_of_directors or 0), 0
            ),
            'signature_break_lines_balance_sheet': max(int(self.signature_break_lines_balance_sheet or 0), 0),
            'signature_break_lines_profit_loss': max(int(self.signature_break_lines_profit_loss or 0), 0),
            'signature_break_lines_changes_in_equity': max(
                int(self.signature_break_lines_changes_in_equity or 0), 0
            ),
            'signature_break_lines_cash_flows': max(int(self.signature_break_lines_cash_flows or 0), 0),
            'signature_break_lines_notes': max(int(self.signature_break_lines_notes or 0), 0),

            # Shareholders
            'sh_name_1':sh_name_1,
             'sh_nat_1':sh_nat_1,
             'sh_shares_1':sh_shares_1,
             'sh_value_1':sh_value_1,
             'sh_total_1':sh_total_1,
             'sh_name_2':sh_name_2,
             'sh_nat_2':sh_nat_2,
             'sh_shares_2':sh_shares_2,
             'sh_value_2':sh_value_2,
             'sh_total_2':sh_total_2,
             'sh_name_3':sh_name_3,
             'sh_nat_3':sh_nat_3,
             'sh_shares_3':sh_shares_3,
             'sh_value_3':sh_value_3,
             'sh_total_3':sh_total_3,

             # Property and equipment subheads
             'current_ppe_subheads': current_ppe_subheads,
             'current_ppe_total': current_ppe_total,
             'prev_ppe_subheads': prev_ppe_subheads,
             'prev_ppe_total': prev_ppe_total,
             'current_subheads_by_group': current_subheads_by_group,
             'prev_subheads_by_group': prev_subheads_by_group,
             'current_main_heads': current_main_heads,
             'prev_main_heads': prev_main_heads,
            'main_head_labels': MAIN_HEAD_LABELS,
            'current_group_totals': current_group_totals,
            'prev_group_totals': prev_group_totals,
            'show_prior_year': show_prior_year,
            'audit_period_category': period_category,
            'is_dormant_period': period_category.startswith('dormant_'),
            'fa_other_receivables_current': other_receivables_current,
            'fa_other_receivables_prev': other_receivables_prev,

            # Cash flow
            'current_depreciation_total': current_depreciation_total,
            'prior_depreciation_total': prior_depreciation_total,
            'end_service_benefits_adjustment': end_service_benefits_adjustment,
            'prior_end_service_benefits_adjustment': prior_end_service_benefits_adjustment,
            'operating_cashflow_before_working_capital': operating_cashflow_before_working_capital,
            'prior_operating_cashflow_before_working_capital': prior_operating_cashflow_before_working_capital,
            'change_in_current_assets': change_in_current_assets,
            'prior_change_in_current_assets': prior_change_in_current_assets,
            'change_in_current_liabilities': change_in_current_liabilities,
            'prior_change_in_current_liabilities': prior_change_in_current_liabilities,
            'corporate_tax_paid': corporate_tax_paid,
            'prior_corporate_tax_paid': prior_corporate_tax_paid,
            'end_service_benefits_paid': end_service_benefits_paid,
            'prior_end_service_benefits_paid': prior_end_service_benefits_paid,
            'net_cash_generated_from_operations': net_cash_generated_from_operations,
            'prior_net_cash_generated_from_operations': prior_net_cash_generated_from_operations,
            'current_property': current_property,
            'prior_property': prior_property,
            'net_cash_generated_from_investing_activities': net_cash_generated_from_investing_activities,
            'prior_net_cash_generated_from_investing_activities': prior_net_cash_generated_from_investing_activities,
            'paid_up_capital': paid_up_capital,
            'prior_paid_up_capital': prior_paid_up_capital,
            'dividend_paid': dividend_paid,
            'prior_dividend_paid': prior_dividend_paid,
            'owner_current_account': owner_current_account,
            'prior_owner_current_account': prior_owner_current_account,
            'net_cash_generated_from_financing_activities': net_cash_generated_from_financing_activities,
            'prior_net_cash_generated_from_financing_activities': prior_net_cash_generated_from_financing_activities,
            'net_cash_and_cash_equivalents': net_cash_and_cash_equivalents,
            'prior_net_cash_and_cash_equivalents': prior_net_cash_and_cash_equivalents,
            'cash_beginning_year': cash_beginning_year,
            'cash_end_of_year': cash_end_of_year,
            'prior_cash_beginning_year': prior_cash_beginning_year,
            'prior_cash_end_of_year': prior_cash_end_of_year,

            # Notes
            'show_emphasis_of_matter': show_emphasis_of_matter,
            'emphasis_note_items': emphasis_note_items,
            'emphasis_note_lines': emphasis_note_lines,
            'note_numbers': note_numbers,
            'note_sections': note_sections,
            'last_note_number': last_note_number,
            'dmcc_sheet_data': dmcc_sheet_data,
            }


    @staticmethod
    def _normalize_account_code(code):
        return ''.join(ch for ch in (code or '') if ch.isdigit())

    @staticmethod
    def _to_float(value):
        try:
            return float(value or 0.0)
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _sum_prefix_balances(balance_by_code, *prefixes):
        return sum(
            amount
            for code, amount in (balance_by_code or {}).items()
            if any((code or '').startswith(prefix) for prefix in prefixes)
        )

    @staticmethod
    def _clear_rows(ws, start_row, end_row, min_col, max_col):
        for row in range(start_row, end_row + 1):
            for col in range(min_col, max_col + 1):
                ws.cell(row=row, column=col, value=None)

    def _get_afs_template_path(self):
        module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        candidates = [
            os.path.join(os.path.dirname(module_path), 'AFS template.xlsx'),
            os.path.join(module_path, 'AFS template.xlsx'),
        ]
        for path in candidates:
            if os.path.exists(path):
                return path
        raise ValidationError(
            "AFS template file was not found. Expected 'AFS template.xlsx' under Custom/."
        )

    def _get_excel_periods(self):
        self.ensure_one()
        date_start = fields.Date.to_date(self.excel_date_start or self.date_start)
        date_end = fields.Date.to_date(self.excel_date_end or self.date_end)
        if not date_start or not date_end:
            raise ValidationError("Please set both Excel Date Start and Excel Date End.")
        if date_start > date_end:
            raise ValidationError("Excel Date End must be after Excel Date Start.")

        prior_mode = self.excel_prior_year_mode or 'auto'
        if prior_mode == 'manual':
            prior_date_start = fields.Date.to_date(self.excel_prior_date_start)
            prior_date_end = fields.Date.to_date(self.excel_prior_date_end)
            if not prior_date_start or not prior_date_end:
                raise ValidationError(
                    "Please set both Excel Prior Date Start and Excel Prior Date End for manual prior mode."
                )
        else:
            prior_date_start = date_start - relativedelta(years=1)
            prior_date_end = date_end - relativedelta(years=1)
        if prior_date_start > prior_date_end:
            raise ValidationError("Excel Prior Date End must be after Excel Prior Date Start.")

        return {
            'date_start': date_start,
            'date_end': date_end,
            'prior_mode': prior_mode,
            'prior_date_start': prior_date_start,
            'prior_date_end': prior_date_end,
            'opening_date_end': date_start - relativedelta(days=1),
        }

    def _read_group_account_balances(self, date_start=False, date_end=False):
        self.ensure_one()
        domain = [
            ('company_id', '=', self.company_id.id),
            ('move_id.state', '=', 'posted'),
        ]
        if date_start:
            domain.append(('date', '>=', date_start))
        if date_end:
            domain.append(('date', '<=', date_end))

        move_line_env = self.env['account.move.line'].with_context(
            allowed_company_ids=[self.company_id.id]
        )
        rows = move_line_env.read_group(
            domain=domain,
            fields=['balance', 'account_id'],
            groupby=['account_id'],
        )
        account_ids = [row['account_id'][0] for row in rows if row.get('account_id')]
        accounts = self.env['account.account'].browse(account_ids)
        account_map = {acc.id: acc for acc in accounts}
        balances = {}
        for row in rows:
            account_info = row.get('account_id')
            if not account_info:
                continue
            account = account_map.get(account_info[0])
            if not account:
                continue
            code = self._normalize_account_code(account.code or account.code_store or '')
            if not code:
                continue
            balances[code] = balances.get(code, 0.0) + self._to_float(row.get('balance'))
        return balances

    def _fetch_sales_rows(self, date_start, date_end):
        self.ensure_one()
        moves = self.env['account.move'].search(
            [
                ('company_id', '=', self.company_id.id),
                ('state', '=', 'posted'),
                ('move_type', 'in', ['out_invoice', 'out_refund']),
                ('invoice_date', '>=', date_start),
                ('invoice_date', '<=', date_end),
            ],
            order='invoice_date, id',
        )
        standard_rows = []
        zero_rows = []
        totals = {
            'standard_net': 0.0,
            'standard_vat': 0.0,
            'standard_gross': 0.0,
            'zero_net': 0.0,
            'zero_vat': 0.0,
            'zero_gross': 0.0,
        }

        for move in moves:
            sign = -1.0 if move.move_type == 'out_refund' else 1.0
            buckets = {
                'standard': {'gross': 0.0, 'vat': 0.0, 'net': 0.0},
                'zero': {'gross': 0.0, 'vat': 0.0, 'net': 0.0},
            }
            for line in move.invoice_line_ids.filtered(lambda l: not l.display_type):
                taxes = line.tax_ids.filtered(lambda t: t.type_tax_use in ('sale', 'none'))
                has_non_zero_tax = any(abs(self._to_float(t.amount)) > 1e-9 for t in taxes)
                bucket = 'standard' if has_non_zero_tax else 'zero'
                gross = sign * self._to_float(line.price_total)
                net = sign * self._to_float(line.price_subtotal)
                vat = gross - net
                buckets[bucket]['gross'] += gross
                buckets[bucket]['net'] += net
                buckets[bucket]['vat'] += vat

            partner_name = move.partner_id.name or ''
            invoice_date = move.invoice_date or move.date
            invoice_no = move.name or move.ref or move.payment_reference or ''
            if any(abs(v) > 1e-9 for v in buckets['standard'].values()):
                standard_rows.append(
                    {
                        'partner': partner_name,
                        'date': invoice_date,
                        'invoice': invoice_no,
                        'gross': buckets['standard']['gross'],
                        'vat': buckets['standard']['vat'],
                        'net': buckets['standard']['net'],
                    }
                )
                totals['standard_gross'] += buckets['standard']['gross']
                totals['standard_vat'] += buckets['standard']['vat']
                totals['standard_net'] += buckets['standard']['net']
            if any(abs(v) > 1e-9 for v in buckets['zero'].values()):
                zero_rows.append(
                    {
                        'partner': partner_name,
                        'date': invoice_date,
                        'invoice': invoice_no,
                        'gross': buckets['zero']['gross'],
                        'vat': buckets['zero']['vat'],
                        'net': buckets['zero']['net'],
                    }
                )
                totals['zero_gross'] += buckets['zero']['gross']
                totals['zero_vat'] += buckets['zero']['vat']
                totals['zero_net'] += buckets['zero']['net']
        return standard_rows, zero_rows, totals

    def _fetch_purchase_rows(self, date_start, date_end):
        self.ensure_one()
        moves = self.env['account.move'].search(
            [
                ('company_id', '=', self.company_id.id),
                ('state', '=', 'posted'),
                ('move_type', 'in', ['in_invoice', 'in_refund']),
                ('invoice_date', '>=', date_start),
                ('invoice_date', '<=', date_end),
            ],
            order='invoice_date, id',
        )
        claimable_rows = []
        non_claimable_rows = []
        totals = {
            'claimable_net': 0.0,
            'claimable_vat': 0.0,
            'claimable_gross': 0.0,
            'claimable_paid': 0.0,
            'claimable_due': 0.0,
            'non_claimable_amount': 0.0,
            'non_claimable_net': 0.0,
            'non_claimable_due': 0.0,
        }

        for move in moves:
            sign = -1.0 if move.move_type == 'in_refund' else 1.0
            buckets = {
                'claimable': {'gross': 0.0, 'vat': 0.0, 'net': 0.0},
                'non_claimable': {'gross': 0.0, 'vat': 0.0, 'net': 0.0},
            }
            for line in move.invoice_line_ids.filtered(lambda l: not l.display_type):
                taxes = line.tax_ids.filtered(lambda t: t.type_tax_use in ('purchase', 'none'))
                is_claimable = any(abs(self._to_float(t.amount)) > 1e-9 for t in taxes)
                key = 'claimable' if is_claimable else 'non_claimable'
                gross = sign * self._to_float(line.price_total)
                net = sign * self._to_float(line.price_subtotal)
                vat = gross - net
                buckets[key]['gross'] += gross
                buckets[key]['net'] += net
                buckets[key]['vat'] += vat

            due_total = sign * self._to_float(move.amount_residual)
            gross_total = buckets['claimable']['gross'] + buckets['non_claimable']['gross']

            def _alloc_due(gross_part):
                if abs(gross_total) <= 1e-9:
                    return 0.0
                return due_total * (gross_part / gross_total)

            partner_name = move.partner_id.name or ''
            invoice_date = move.invoice_date or move.date
            invoice_no = move.name or move.ref or move.payment_reference or ''
            payment_date = move.invoice_date_due

            if any(abs(v) > 1e-9 for v in buckets['claimable'].values()):
                due_share = _alloc_due(buckets['claimable']['gross'])
                paid_value = buckets['claimable']['gross'] - due_share
                row = {
                    'date': invoice_date,
                    'partner': partner_name,
                    'invoice': invoice_no,
                    'net': buckets['claimable']['net'],
                    'vat': buckets['claimable']['vat'],
                    'gross_paid': paid_value,
                    'due': due_share,
                    'payment_date': payment_date,
                }
                claimable_rows.append(row)
                totals['claimable_net'] += row['net']
                totals['claimable_vat'] += row['vat']
                totals['claimable_paid'] += row['gross_paid']
                totals['claimable_due'] += row['due']
                totals['claimable_gross'] += row['gross_paid'] + row['due']

            if any(abs(v) > 1e-9 for v in buckets['non_claimable'].values()):
                due_share = _alloc_due(buckets['non_claimable']['gross'])
                row = {
                    'date': invoice_date,
                    'partner': partner_name,
                    'invoice': invoice_no,
                    'amount': buckets['non_claimable']['gross'],
                    'exchange_rate': 1.0,
                    'net_aed': buckets['non_claimable']['net'],
                    'due': due_share,
                    'payment_date': payment_date,
                }
                non_claimable_rows.append(row)
                totals['non_claimable_amount'] += row['amount']
                totals['non_claimable_net'] += row['net_aed']
                totals['non_claimable_due'] += row['due']

        return claimable_rows, non_claimable_rows, totals

    def _fetch_bank_statement_rows(self, date_start, date_end):
        self.ensure_one()
        account_env = self.env['account.account'].with_company(self.company_id).with_context(
            allowed_company_ids=[self.company_id.id]
        )
        bank_accounts = account_env.search([]).filtered(
            lambda acc: self._normalize_account_code(acc.code or acc.code_store or '').startswith('1204')
        )
        if not bank_accounts:
            bank_accounts = account_env.search([('account_type', '=', 'asset_cash')])
        bank_ids = set(bank_accounts.ids)
        if not bank_ids:
            return {
                'opening_balance': 0.0,
                'rows': [],
                'closing_balance': 0.0,
                'account_balances': [],
            }

        ml_env = self.env['account.move.line'].with_context(allowed_company_ids=[self.company_id.id])
        opening_rows = ml_env.read_group(
            domain=[
                ('company_id', '=', self.company_id.id),
                ('move_id.state', '=', 'posted'),
                ('account_id', 'in', list(bank_ids)),
                ('date', '<=', date_start - relativedelta(days=1)),
            ],
            fields=['balance:sum'],
            groupby=[],
        )
        opening_balance = self._to_float(opening_rows[0].get('balance') if opening_rows else 0.0)

        lines = ml_env.search(
            [
                ('company_id', '=', self.company_id.id),
                ('move_id.state', '=', 'posted'),
                ('account_id', 'in', list(bank_ids)),
                ('date', '>=', date_start),
                ('date', '<=', date_end),
            ],
            order='date, id',
        )

        def _nature_for_line(bank_line):
            counterparts = bank_line.move_id.line_ids.filtered(
                lambda l: l.id != bank_line.id and l.account_id.id not in bank_ids and not l.display_type
            )
            cp_line = counterparts[:1]
            if not cp_line:
                return 'Other'
            cp_code = self._normalize_account_code(cp_line.account_id.code or cp_line.account_id.code_store or '')
            if cp_code.startswith('41'):
                return 'Revenue'
            if cp_code.startswith('5107'):
                return 'Director salary'
            if cp_code.startswith('5109'):
                return 'Audit and accounting fee'
            if cp_code.startswith('5123'):
                return 'Bank charges'
            if cp_code.startswith('1203'):
                return 'Prepayment'
            if cp_code.startswith('12040102'):
                return 'Owner current account'
            if cp_code.startswith('2203') or cp_code.startswith('2204'):
                return 'Liability'
            return cp_line.account_id.name or 'Other'

        running = opening_balance
        rows = []
        for line in lines:
            amount = self._to_float(line.debit) - self._to_float(line.credit)
            if abs(amount) <= 1e-9:
                continue
            running += amount
            rows.append(
                {
                    'date': line.date,
                    'description': line.name or line.move_id.ref or line.move_id.name or '',
                    'currency': self.company_id.currency_id.name or 'AED',
                    'amount': amount,
                    'exchange_rate': 1.0,
                    'gross_dr': max(-amount, 0.0),
                    'vat_dr': 0.0,
                    'net_dr': max(-amount, 0.0),
                    'gross_cr': max(amount, 0.0),
                    'vat_cr': 0.0,
                    'net_cr': max(amount, 0.0),
                    'nature': _nature_for_line(line),
                    'balance_bs': running,
                    'balance_calc': running,
                }
            )

        balance_rows = ml_env.read_group(
            domain=[
                ('company_id', '=', self.company_id.id),
                ('move_id.state', '=', 'posted'),
                ('account_id', 'in', list(bank_ids)),
                ('date', '<=', date_end),
            ],
            fields=['balance:sum', 'account_id'],
            groupby=['account_id'],
        )
        balance_by_account_id = {
            row['account_id'][0]: self._to_float(row.get('balance'))
            for row in balance_rows
            if row.get('account_id')
        }

        account_balances = []
        for account in bank_accounts:
            balance = self._to_float(balance_by_account_id.get(account.id))
            if abs(balance) <= 1e-9:
                continue
            bank_no = ''
            bank_name = ''
            if hasattr(account, 'bank_ids') and account.bank_ids:
                bank_no = account.bank_ids[0].acc_number or ''
                bank_name = account.bank_ids[0].bank_id.name or ''
            account_balances.append(
                {
                    'bank_name': bank_name,
                    'account_title': account.name or '',
                    'account_no': bank_no,
                    'currency': self.company_id.currency_id.name or 'AED',
                    'amount': balance,
                    'exchange_rate': 1.0,
                    'amount_aed': balance,
                }
            )

        return {
            'opening_balance': opening_balance,
            'rows': rows,
            'closing_balance': running,
            'account_balances': account_balances,
        }

    def _fetch_gl_rows(self, date_start, date_end, limit=500):
        self.ensure_one()
        lines = self.env['account.move.line'].search(
            [
                ('company_id', '=', self.company_id.id),
                ('move_id.state', '=', 'posted'),
                ('date', '>=', date_start),
                ('date', '<=', date_end),
            ],
            order='date, id',
            limit=limit,
        )
        results = []
        for line in lines:
            results.append(
                {
                    'date': line.date,
                    'move': line.move_id.name or '',
                    'account': f"{line.account_id.code or ''} {line.account_id.name or ''}".strip(),
                    'label': line.name or '',
                    'debit': self._to_float(line.debit),
                    'credit': self._to_float(line.credit),
                    'balance': self._to_float(line.debit) - self._to_float(line.credit),
                }
            )
        return results

    def _generate_afs_excel_binary_fast(
        self,
        periods,
        report_data,
        period_balances,
        prior_period_balances,
        end_balances,
        prior_end_balances,
        opening_balances,
        sales_standard_rows,
        sales_zero_rows,
        sales_totals,
        purchase_claimable_rows,
        purchase_non_claimable_rows,
        purchase_totals,
        bank_data,
        gl_rows,
    ):
        self.ensure_one()
        try:
            import xlsxwriter  # noqa: PLC0415
            from xlsxwriter.utility import xl_cell_to_rowcol  # noqa: PLC0415
        except Exception as exc:
            raise ValidationError(
                "xlsxwriter is not available in this environment. Install it to generate AFS Excel."
            ) from exc

        output = BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        date_fmt = workbook.add_format({'num_format': 'yyyy-mm-dd'})

        sheet_names = [
            'Client Details',
            'SoFP',
            'SoCI',
            'SoCE',
            'SoCF',
            'SUMMARY',
            'Sale ',
            'Purchases',
            'Bank Statement',
            'Bank Ticked Back',
            'Bank Balance',
            'Bank Control',
            'SL Control',
            'PL Control',
            'VAT Control',
            'Accruals',
            'Prepayment',
            'Share Capital',
            'Cash in hand',
            'GLs',
            'Pivot',
        ]
        sheets = {name: workbook.add_worksheet(name) for name in sheet_names}

        def _to_datetime(value):
            if isinstance(value, py_datetime):
                return value
            if isinstance(value, py_date):
                return py_datetime.combine(value, py_time.min)
            return None

        def _write_rc(ws, row, col, value):
            if value is None:
                return
            dt_value = _to_datetime(value)
            if dt_value is not None:
                ws.write_datetime(row - 1, col - 1, dt_value, date_fmt)
                return
            ws.write(row - 1, col - 1, value)

        def _write_formula_rc(ws, row, col, formula):
            formula_value = str(formula or '')
            if not formula_value.startswith('='):
                formula_value = f'={formula_value}'
            ws.write_formula(row - 1, col - 1, formula_value)

        def _write_cell(ws, cell, value):
            row, col = xl_cell_to_rowcol(cell)
            _write_rc(ws, row + 1, col + 1, value)

        def _write_formula_cell(ws, cell, formula):
            row, col = xl_cell_to_rowcol(cell)
            _write_formula_rc(ws, row + 1, col + 1, formula)

        company = self.company_id
        revenue_related = -self._sum_prefix_balances(period_balances, '4102')
        prev_revenue_related = -self._sum_prefix_balances(prior_period_balances, '4102')
        revenue_main = -self._sum_prefix_balances(period_balances, '4101')
        prev_revenue_main = -self._sum_prefix_balances(prior_period_balances, '4101')

        client_ws = sheets['Client Details']
        _write_cell(client_ws, 'B4', company.name or '')
        _write_cell(client_ws, 'B5', periods['date_start'])
        _write_cell(client_ws, 'B6', periods['date_end'])
        _write_cell(client_ws, 'B8', self.company_license_number or '')
        _write_cell(client_ws, 'B9', self.company_free_zone or '')
        _write_cell(client_ws, 'B11', self.incorporation_date or '')
        _write_cell(client_ws, 'B13', self.trade_license_activities or '')
        _write_cell(client_ws, 'B14', report_data.get('shareholder_display_text') or '')
        _write_cell(client_ws, 'B16', self.corporate_tax_registration_number or '')
        _write_cell(client_ws, 'B20', self.vat_registration_number or '')

        sofp_ws = sheets['SoFP']
        prev_group_totals = report_data.get('prev_group_totals') or {}
        current_group_totals = report_data.get('current_group_totals') or {}
        _write_cell(sofp_ws, 'B9', self._to_float(report_data.get('current_ppe_total')))
        _write_cell(sofp_ws, 'C9', self._to_float(report_data.get('prev_ppe_total')))
        _write_cell(sofp_ws, 'B12', self._to_float(current_group_totals.get('1202')))
        _write_cell(sofp_ws, 'C12', self._to_float(prev_group_totals.get('1202')))
        _write_cell(sofp_ws, 'B13', self._to_float(current_group_totals.get('1203')))
        _write_cell(sofp_ws, 'C13', self._to_float(prev_group_totals.get('1203')))
        _write_cell(sofp_ws, 'B14', self._sum_prefix_balances(end_balances, '120304'))
        _write_cell(sofp_ws, 'C14', self._sum_prefix_balances(prior_end_balances, '120304'))
        _write_cell(sofp_ws, 'B15', self._to_float(current_group_totals.get('1204')))
        _write_cell(sofp_ws, 'C15', self._to_float(prev_group_totals.get('1204')))
        _write_cell(sofp_ws, 'B21', self._to_float(report_data.get('share_capital_total')))
        _write_cell(sofp_ws, 'C21', self._to_float(report_data.get('prev_share_capital_total')))
        _write_cell(sofp_ws, 'B22', self._to_float(report_data.get('retained_earnings_balance')))
        _write_cell(sofp_ws, 'C22', self._to_float(report_data.get('prev_retained_earnings_balance')))
        _write_cell(sofp_ws, 'B23', -self._sum_prefix_balances(end_balances, '12040102'))
        _write_cell(sofp_ws, 'C23', -self._sum_prefix_balances(prior_end_balances, '12040102'))
        _write_cell(sofp_ws, 'B26', abs(self._sum_prefix_balances(end_balances, '2101', '2102')))
        _write_cell(sofp_ws, 'C26', abs(self._sum_prefix_balances(prior_end_balances, '2101', '2102')))
        _write_cell(sofp_ws, 'B28', abs(self._sum_prefix_balances(end_balances, '220303')))
        _write_cell(sofp_ws, 'C28', abs(self._sum_prefix_balances(prior_end_balances, '220303')))
        _write_cell(sofp_ws, 'B29', abs(self._sum_prefix_balances(end_balances, '220302', '2204')))
        _write_cell(sofp_ws, 'C29', abs(self._sum_prefix_balances(prior_end_balances, '220302', '2204')))

        soti_ws = sheets['SoCI']
        _write_cell(soti_ws, 'B8', revenue_main)
        _write_cell(soti_ws, 'C8', prev_revenue_main)
        _write_cell(soti_ws, 'B9', revenue_related)
        _write_cell(soti_ws, 'C9', prev_revenue_related)
        _write_cell(soti_ws, 'B11', self._sum_prefix_balances(period_balances, '5101'))
        _write_cell(soti_ws, 'C11', self._sum_prefix_balances(prior_period_balances, '5101'))
        _write_cell(soti_ws, 'B16', self._sum_prefix_balances(period_balances, '5107'))
        _write_cell(soti_ws, 'C16', self._sum_prefix_balances(prior_period_balances, '5107'))
        _write_cell(soti_ws, 'B17', self._sum_prefix_balances(period_balances, '5108'))
        _write_cell(soti_ws, 'C17', self._sum_prefix_balances(prior_period_balances, '5108'))
        _write_cell(soti_ws, 'B18', self._sum_prefix_balances(period_balances, '5102'))
        _write_cell(soti_ws, 'C18', self._sum_prefix_balances(prior_period_balances, '5102'))
        _write_cell(soti_ws, 'B19', self._sum_prefix_balances(period_balances, '5109'))
        _write_cell(soti_ws, 'C19', self._sum_prefix_balances(prior_period_balances, '5109'))
        _write_cell(soti_ws, 'B24', self._sum_prefix_balances(period_balances, '5123'))
        _write_cell(soti_ws, 'C24', self._sum_prefix_balances(prior_period_balances, '5123'))
        _write_cell(soti_ws, 'B25', self._sum_prefix_balances(period_balances, '410305'))
        _write_cell(soti_ws, 'C25', self._sum_prefix_balances(prior_period_balances, '410305'))
        _write_cell(soti_ws, 'B29', self._to_float(report_data.get('other_income_total')))
        _write_cell(soti_ws, 'C29', self._to_float(report_data.get('prev_other_income_total')))
        _write_cell(soti_ws, 'B31', self._to_float(report_data.get('net_profit_after_tax')))
        _write_cell(soti_ws, 'C31', self._to_float(report_data.get('prev_net_profit_after_tax')))

        soce_ws = sheets['SoCE']
        _write_cell(soce_ws, 'B7', self._to_float(report_data.get('share_capital_total')))
        _write_cell(soce_ws, 'C7', -self._sum_prefix_balances(prior_end_balances, '12040102'))
        _write_cell(soce_ws, 'D7', self._to_float(report_data.get('prev_prev_retained_earnings_balance')))
        _write_cell(soce_ws, 'C9', self._to_float(report_data.get('prior_owner_current_account')))
        _write_cell(soce_ws, 'D10', self._to_float(report_data.get('prev_net_profit_after_tax')))
        _write_cell(soce_ws, 'B13', 0.0)
        _write_cell(soce_ws, 'C14', self._to_float(report_data.get('owner_current_account')))
        _write_cell(soce_ws, 'D15', self._to_float(report_data.get('net_profit_after_tax')))

        socf_ws = sheets['SoCF']
        _write_cell(socf_ws, 'B9', self._to_float(report_data.get('net_profit_after_tax')))
        _write_cell(socf_ws, 'C9', self._to_float(report_data.get('prev_net_profit_after_tax')))
        _write_cell(
            socf_ws, 'B10', self._to_float(report_data.get('operating_cashflow_before_working_capital'))
        )
        _write_cell(
            socf_ws, 'C10', self._to_float(report_data.get('prior_operating_cashflow_before_working_capital'))
        )
        _write_cell(socf_ws, 'B12', self._to_float(report_data.get('change_in_current_assets')))
        _write_cell(socf_ws, 'C12', self._to_float(report_data.get('prior_change_in_current_assets')))
        _write_cell(socf_ws, 'B13', self._to_float(report_data.get('change_in_current_liabilities')))
        _write_cell(socf_ws, 'C13', self._to_float(report_data.get('prior_change_in_current_liabilities')))
        _write_cell(socf_ws, 'B16', self._to_float(report_data.get('current_property')))
        _write_cell(socf_ws, 'C16', self._to_float(report_data.get('prior_property')))
        _write_cell(socf_ws, 'B19', self._to_float(report_data.get('paid_up_capital')))
        _write_cell(socf_ws, 'C19', self._to_float(report_data.get('prior_paid_up_capital')))
        _write_cell(socf_ws, 'B20', self._to_float(report_data.get('owner_current_account')))
        _write_cell(socf_ws, 'C20', self._to_float(report_data.get('prior_owner_current_account')))
        _write_cell(socf_ws, 'B23', self._to_float(report_data.get('cash_beginning_year')))
        _write_cell(socf_ws, 'C23', self._to_float(report_data.get('prior_cash_beginning_year')))
        _write_cell(socf_ws, 'B24', self._to_float(report_data.get('cash_end_of_year')))
        _write_cell(socf_ws, 'C24', self._to_float(report_data.get('prior_cash_end_of_year')))

        summary_ws = sheets['SUMMARY']
        _write_cell(summary_ws, 'B7', revenue_main)
        _write_cell(
            summary_ws,
            'B8',
            self._to_float(report_data.get('operating_expenses_total')) - self._sum_prefix_balances(
                period_balances, '5107'
            ),
        )
        _write_cell(summary_ws, 'B9', self._sum_prefix_balances(period_balances, '5107'))
        _write_cell(summary_ws, 'B10', self._to_float(report_data.get('net_profit_after_tax')))
        _write_cell(summary_ws, 'B11', self._to_float(report_data.get('total_assets')))
        _write_cell(summary_ws, 'B12', self._to_float(report_data.get('total_liabilities')))
        _write_cell(summary_ws, 'B13', self._to_float(report_data.get('total_equity')))
        _write_cell(summary_ws, 'B15', revenue_related)
        _write_cell(summary_ws, 'B16', -self._sum_prefix_balances(end_balances, '12040102'))
        _write_cell(summary_ws, 'B17', -self._sum_prefix_balances(period_balances, '410301'))
        _write_cell(summary_ws, 'B18', -self._sum_prefix_balances(period_balances, '410302'))

        ws = sheets['Sale ']
        _write_rc(ws, 6, 1, 'Standard rated sales')
        _write_rc(ws, 7, 1, 'Client Name')
        _write_rc(ws, 7, 2, 'Date')
        _write_rc(ws, 7, 3, 'Invoice Number')
        _write_rc(ws, 7, 4, 'Gross')
        _write_rc(ws, 7, 5, 'VAT')
        _write_rc(ws, 7, 6, 'Net')
        row = 8
        for rec in sales_standard_rows:
            _write_rc(ws, row, 1, rec['partner'])
            _write_rc(ws, row, 2, rec['date'])
            _write_rc(ws, row, 3, rec['invoice'])
            _write_rc(ws, row, 4, rec['gross'])
            _write_rc(ws, row, 5, rec['vat'])
            _write_rc(ws, row, 6, rec['net'])
            row += 1
        std_total_row = row
        _write_formula_rc(ws, std_total_row, 4, f"=SUM(D8:D{max(row - 1, 8)})")
        _write_formula_rc(ws, std_total_row, 5, f"=SUM(E8:E{max(row - 1, 8)})")
        _write_formula_rc(ws, std_total_row, 6, f"=SUM(F8:F{max(row - 1, 8)})")

        zero_title_row = std_total_row + 2
        zero_header_row = zero_title_row + 1
        zero_data_start = zero_header_row + 1
        _write_rc(ws, zero_title_row, 1, 'Zero rated sales')
        _write_rc(ws, zero_header_row, 1, 'Client Name')
        _write_rc(ws, zero_header_row, 2, 'Date')
        _write_rc(ws, zero_header_row, 3, 'Invoice Number')
        _write_rc(ws, zero_header_row, 4, 'Gross')
        _write_rc(ws, zero_header_row, 5, 'VAT')
        _write_rc(ws, zero_header_row, 6, 'Net')

        row = zero_data_start
        for rec in sales_zero_rows:
            _write_rc(ws, row, 1, rec['partner'])
            _write_rc(ws, row, 2, rec['date'])
            _write_rc(ws, row, 3, rec['invoice'])
            _write_rc(ws, row, 4, rec['gross'])
            _write_rc(ws, row, 5, rec['vat'])
            _write_rc(ws, row, 6, rec['net'])
            row += 1
        zero_total_row = row
        _write_formula_rc(ws, zero_total_row, 4, f"=SUM(D{zero_data_start}:D{max(row - 1, zero_data_start)})")
        _write_formula_rc(ws, zero_total_row, 5, f"=SUM(E{zero_data_start}:E{max(row - 1, zero_data_start)})")
        _write_formula_rc(ws, zero_total_row, 6, f"=SUM(F{zero_data_start}:F{max(row - 1, zero_data_start)})")

        ws = sheets['Purchases']
        _write_rc(ws, 6, 1, 'Invoiced purchases')
        _write_rc(ws, 7, 1, 'VAT claimable')
        _write_rc(ws, 8, 1, 'Date')
        _write_rc(ws, 8, 2, 'Vendor Name')
        _write_rc(ws, 8, 3, 'Inv No')
        _write_rc(ws, 8, 4, 'Net (AED)')
        _write_rc(ws, 8, 5, 'VAT 5%')
        _write_rc(ws, 8, 6, 'Gross(AED) Paid')
        _write_rc(ws, 8, 7, 'Amount Due')
        _write_rc(ws, 8, 8, 'Payment Date')

        row = 9
        for rec in purchase_claimable_rows:
            _write_rc(ws, row, 1, rec['date'])
            _write_rc(ws, row, 2, rec['partner'])
            _write_rc(ws, row, 3, rec['invoice'])
            _write_rc(ws, row, 4, rec['net'])
            _write_rc(ws, row, 5, rec['vat'])
            _write_rc(ws, row, 6, rec['gross_paid'])
            _write_rc(ws, row, 7, rec['due'])
            _write_rc(ws, row, 8, rec['payment_date'])
            row += 1
        claim_total_row = row
        _write_rc(ws, claim_total_row, 2, 'Total')
        _write_formula_rc(ws, claim_total_row, 4, f"=SUM(D9:D{max(row - 1, 9)})")
        _write_formula_rc(ws, claim_total_row, 5, f"=SUM(E9:E{max(row - 1, 9)})")
        _write_formula_rc(ws, claim_total_row, 6, f"=SUM(F9:F{max(row - 1, 9)})")
        _write_formula_rc(ws, claim_total_row, 7, f"=SUM(G9:G{max(row - 1, 9)})")

        non_claim_title_row = claim_total_row + 2
        non_claim_header_row = non_claim_title_row + 1
        non_claim_data_start = non_claim_header_row + 1
        _write_rc(ws, non_claim_title_row, 1, 'VAT not claimable')
        _write_rc(ws, non_claim_header_row, 1, 'Date')
        _write_rc(ws, non_claim_header_row, 2, 'Vendor Name')
        _write_rc(ws, non_claim_header_row, 3, 'Inv No')
        _write_rc(ws, non_claim_header_row, 4, 'Amount')
        _write_rc(ws, non_claim_header_row, 5, 'Exchange Rate')
        _write_rc(ws, non_claim_header_row, 6, 'Net (AED)')
        _write_rc(ws, non_claim_header_row, 7, 'Amount Due')
        _write_rc(ws, non_claim_header_row, 8, 'Payment Date')

        row = non_claim_data_start
        for rec in purchase_non_claimable_rows:
            _write_rc(ws, row, 1, rec['date'])
            _write_rc(ws, row, 2, rec['partner'])
            _write_rc(ws, row, 3, rec['invoice'])
            _write_rc(ws, row, 4, rec['amount'])
            _write_rc(ws, row, 5, rec['exchange_rate'])
            _write_rc(ws, row, 6, rec['net_aed'])
            _write_rc(ws, row, 7, rec['due'])
            _write_rc(ws, row, 8, rec['payment_date'])
            row += 1
        non_claim_total_row = row
        _write_rc(ws, non_claim_total_row, 2, 'Total')
        _write_formula_rc(
            ws,
            non_claim_total_row,
            4,
            f"=SUM(D{non_claim_data_start}:D{max(row - 1, non_claim_data_start)})",
        )
        _write_formula_rc(
            ws,
            non_claim_total_row,
            6,
            f"=SUM(F{non_claim_data_start}:F{max(row - 1, non_claim_data_start)})",
        )
        _write_formula_rc(
            ws,
            non_claim_total_row,
            7,
            f"=SUM(G{non_claim_data_start}:G{max(row - 1, non_claim_data_start)})",
        )

        ws = sheets['Bank Statement']
        _write_rc(ws, 10, 2, 'Opening Balance')
        _write_rc(ws, 10, 9, bank_data['opening_balance'])
        _write_rc(ws, 10, 12, 'Opening Balance')
        _write_formula_rc(ws, 10, 13, '=I10')
        row = 11
        for rec in bank_data['rows']:
            _write_rc(ws, row, 1, rec['date'])
            _write_rc(ws, row, 2, rec['description'])
            _write_rc(ws, row, 3, rec['currency'])
            _write_rc(ws, row, 4, rec['amount'])
            _write_rc(ws, row, 5, rec['exchange_rate'])
            _write_rc(ws, row, 6, rec['gross_dr'])
            _write_rc(ws, row, 7, rec['vat_dr'])
            _write_rc(ws, row, 8, rec['net_dr'])
            _write_rc(ws, row, 9, rec['gross_cr'])
            _write_rc(ws, row, 10, rec['vat_cr'])
            _write_rc(ws, row, 11, rec['net_cr'])
            _write_rc(ws, row, 12, rec['nature'])
            _write_rc(ws, row, 13, rec['balance_bs'])
            _write_formula_rc(ws, row, 14, f"=M{row - 1}-F{row}+I{row}")
            row += 1
        _write_rc(ws, row, 2, 'Closing Balance')
        _write_formula_rc(ws, row, 6, f"=N{max(row - 1, 10)}")
        _write_rc(ws, row, 12, 'Closing Balance')

        tick_ws = sheets['Bank Ticked Back']
        row = 10
        for rec in bank_data['rows']:
            _write_rc(tick_ws, row, 1, rec['date'])
            _write_rc(tick_ws, row, 2, rec['description'])
            _write_rc(tick_ws, row, 3, rec['net_dr'])
            _write_rc(tick_ws, row, 4, rec['net_cr'])
            row += 1

        bal_ws = sheets['Bank Balance']
        row = 7
        for rec in bank_data['account_balances']:
            _write_rc(bal_ws, row, 1, rec['bank_name'])
            _write_rc(bal_ws, row, 2, rec['account_title'])
            _write_rc(bal_ws, row, 3, rec['account_no'])
            _write_rc(bal_ws, row, 4, rec['currency'])
            _write_rc(bal_ws, row, 5, rec['amount'])
            _write_rc(bal_ws, row, 6, rec['exchange_rate'])
            _write_rc(bal_ws, row, 7, rec['amount_aed'])
            row += 1
        _write_formula_cell(bal_ws, 'G20', f"=SUM(G7:G{max(row - 1, 7)})")

        bank_control_ws = sheets['Bank Control']
        opening_bank = self._sum_prefix_balances(opening_balances, '1204')
        receipts = sum(max(self._to_float(r.get('amount')), 0.0) for r in bank_data['rows'])
        payments = sum(max(-self._to_float(r.get('amount')), 0.0) for r in bank_data['rows'])
        closing_bank = self._sum_prefix_balances(end_balances, '1204')
        _write_cell(bank_control_ws, 'B7', opening_bank)
        _write_cell(bank_control_ws, 'C8', receipts)
        _write_cell(bank_control_ws, 'B9', payments)
        _write_cell(bank_control_ws, 'B11', closing_bank)

        sl_ws = sheets['SL Control']
        opening_receivable = self._sum_prefix_balances(opening_balances, '1202')
        closing_receivable = self._sum_prefix_balances(end_balances, '1202')
        _write_cell(sl_ws, 'B7', opening_receivable)
        _write_cell(sl_ws, 'C8', sales_totals['standard_net'] + sales_totals['zero_net'])
        _write_cell(sl_ws, 'C10', sales_totals['standard_vat'])
        _write_cell(sl_ws, 'B14', closing_receivable)

        pl_ws = sheets['PL Control']
        opening_payables = abs(self._sum_prefix_balances(opening_balances, '2202'))
        closing_payables = abs(self._sum_prefix_balances(end_balances, '2202'))
        _write_cell(pl_ws, 'C7', opening_payables)
        _write_cell(pl_ws, 'B8', purchase_totals['claimable_net'])
        _write_cell(pl_ws, 'B10', purchase_totals['claimable_vat'])
        _write_cell(pl_ws, 'C12', closing_payables)

        vat_ws = sheets['VAT Control']
        opening_vat_payable = abs(self._sum_prefix_balances(opening_balances, '220302', '2204'))
        output_vat = sales_totals['standard_vat']
        input_vat = purchase_totals['claimable_vat']
        closing_vat = opening_vat_payable + output_vat - input_vat
        _write_cell(vat_ws, 'C8', opening_vat_payable)
        _write_cell(vat_ws, 'C10', output_vat)
        _write_cell(vat_ws, 'B14', input_vat)
        if closing_vat >= 0:
            _write_cell(vat_ws, 'C16', closing_vat)
            _write_cell(vat_ws, 'B16', 0.0)
        else:
            _write_cell(vat_ws, 'B16', -closing_vat)
            _write_cell(vat_ws, 'C16', 0.0)
        _write_cell(vat_ws, 'B22', closing_vat)
        _write_formula_cell(vat_ws, 'C22', '=SUM(B22)')

        acc_ws = sheets['Accruals']
        opening_accrual = abs(self._sum_prefix_balances(opening_balances, '220303'))
        closing_accrual = abs(self._sum_prefix_balances(end_balances, '220303'))
        audit_fees = self._sum_prefix_balances(period_balances, '5109')
        _write_cell(acc_ws, 'C7', opening_accrual)
        _write_cell(acc_ws, 'C8', audit_fees)
        _write_cell(acc_ws, 'C9', closing_accrual)

        pre_ws = sheets['Prepayment']
        prepayment_balance = self._sum_prefix_balances(end_balances, '1203')
        _write_cell(pre_ws, 'B8', abs(prepayment_balance))
        _write_cell(pre_ws, 'B13', periods['date_end'])
        _write_cell(pre_ws, 'B16', abs(prepayment_balance))

        share_ws = sheets['Share Capital']
        shareholders = []
        for i in range(1, 11):
            name = getattr(self.company_id, f'shareholder_{i}', False)
            shares = getattr(self.company_id, f'number_of_shares_{i}', 0) or 0
            value = getattr(self.company_id, f'share_value_{i}', 0.0) or 0.0
            if not name and not shares and not value:
                continue
            shareholders.append((name or '', shares, value))
        row = 7
        for name, shares, value in shareholders[:100]:
            _write_rc(share_ws, row, 1, name)
            _write_rc(share_ws, row, 2, shares)
            _write_rc(share_ws, row, 3, value)
            _write_formula_rc(share_ws, row, 4, f"=B{row}*C{row}")
            row += 1
        total_row = max(row, 11)
        _write_formula_rc(share_ws, total_row, 2, f"=SUM(B7:B{max(row - 1, 7)})")
        _write_formula_rc(share_ws, total_row, 3, f"=SUM(C7:C{max(row - 1, 7)})")
        _write_formula_rc(share_ws, total_row, 4, f"=SUM(D7:D{max(row - 1, 7)})")

        cash_ws = sheets['Cash in hand']
        _write_cell(cash_ws, 'B8', self._sum_prefix_balances(end_balances, '120401'))

        gl_ws = sheets['GLs']
        _write_rc(gl_ws, 6, 1, 'Date')
        _write_rc(gl_ws, 6, 2, 'Move')
        _write_rc(gl_ws, 6, 3, 'Account')
        _write_rc(gl_ws, 6, 4, 'Label')
        _write_rc(gl_ws, 6, 5, 'Debit')
        _write_rc(gl_ws, 6, 6, 'Credit')
        _write_rc(gl_ws, 6, 7, 'Balance')
        row = 7
        for rec in gl_rows:
            _write_rc(gl_ws, row, 1, rec['date'])
            _write_rc(gl_ws, row, 2, rec['move'])
            _write_rc(gl_ws, row, 3, rec['account'])
            _write_rc(gl_ws, row, 4, rec['label'])
            _write_rc(gl_ws, row, 5, rec['debit'])
            _write_rc(gl_ws, row, 6, rec['credit'])
            _write_rc(gl_ws, row, 7, rec['balance'])
            row += 1

        pivot_ws = sheets['Pivot']
        _write_cell(pivot_ws, 'A7', 'Revenue')
        _write_cell(pivot_ws, 'B7', sales_totals['standard_net'] + sales_totals['zero_net'])
        _write_cell(pivot_ws, 'C7', 0.0)
        _write_cell(pivot_ws, 'A8', 'Purchases')
        _write_cell(
            pivot_ws,
            'B8',
            purchase_totals['claimable_net'] + purchase_totals['non_claimable_net'],
        )
        _write_cell(pivot_ws, 'C8', 0.0)

        workbook.close()
        output.seek(0)
        filename = (
            f"AFS_{(self.company_id.name or 'Company').replace('/', '-')}_{periods['date_end'].strftime('%Y%m%d')}.xlsx"
        )
        return output.getvalue(), filename

    def _generate_afs_excel_binary(self):
        self.ensure_one()

        periods = self._get_excel_periods()
        ctx_report = self.with_context(
            audit_date_start=periods['date_start'],
            audit_date_end=periods['date_end'],
            audit_prior_year_mode=periods['prior_mode'],
            audit_prior_date_start=periods['prior_date_start'],
            audit_prior_date_end=periods['prior_date_end'],
        )
        report_data = ctx_report._get_report_data()

        period_balances = self._read_group_account_balances(
            date_start=periods['date_start'],
            date_end=periods['date_end'],
        )
        prior_period_balances = self._read_group_account_balances(
            date_start=periods['prior_date_start'],
            date_end=periods['prior_date_end'],
        )
        end_balances = self._read_group_account_balances(date_end=periods['date_end'])
        prior_end_balances = self._read_group_account_balances(date_end=periods['prior_date_end'])
        opening_balances = self._read_group_account_balances(date_end=periods['opening_date_end'])

        sales_standard_rows, sales_zero_rows, sales_totals = self._fetch_sales_rows(
            periods['date_start'],
            periods['date_end'],
        )
        purchase_claimable_rows, purchase_non_claimable_rows, purchase_totals = self._fetch_purchase_rows(
            periods['date_start'],
            periods['date_end'],
        )
        bank_data = self._fetch_bank_statement_rows(
            periods['date_start'],
            periods['date_end'],
        )
        gl_rows = self._fetch_gl_rows(periods['date_start'], periods['date_end'])

        use_template = bool(self.env.context.get('audit_xlsx_use_template'))
        if not use_template:
            return self._generate_afs_excel_binary_fast(
                periods,
                report_data,
                period_balances,
                prior_period_balances,
                end_balances,
                prior_end_balances,
                opening_balances,
                sales_standard_rows,
                sales_zero_rows,
                sales_totals,
                purchase_claimable_rows,
                purchase_non_claimable_rows,
                purchase_totals,
                bank_data,
                gl_rows,
            )

        if load_workbook is None:
            _logger.warning(
                "openpyxl is unavailable; using fast XLSX generator for audit report %s",
                self.id,
            )
            return self._generate_afs_excel_binary_fast(
                periods,
                report_data,
                period_balances,
                prior_period_balances,
                end_balances,
                prior_end_balances,
                opening_balances,
                sales_standard_rows,
                sales_zero_rows,
                sales_totals,
                purchase_claimable_rows,
                purchase_non_claimable_rows,
                purchase_totals,
                bank_data,
                gl_rows,
            )

        try:
            workbook = load_workbook(self._get_afs_template_path())
        except MemoryError:
            _logger.warning(
                "Template workbook load exceeded memory; using fast XLSX generator for audit report %s",
                self.id,
            )
            return self._generate_afs_excel_binary_fast(
                periods,
                report_data,
                period_balances,
                prior_period_balances,
                end_balances,
                prior_end_balances,
                opening_balances,
                sales_standard_rows,
                sales_zero_rows,
                sales_totals,
                purchase_claimable_rows,
                purchase_non_claimable_rows,
                purchase_totals,
                bank_data,
                gl_rows,
            )
        except Exception as exc:
            _logger.warning(
                "Template workbook load failed (%s); using fast XLSX generator for audit report %s",
                exc,
                self.id,
            )
            return self._generate_afs_excel_binary_fast(
                periods,
                report_data,
                period_balances,
                prior_period_balances,
                end_balances,
                prior_end_balances,
                opening_balances,
                sales_standard_rows,
                sales_zero_rows,
                sales_totals,
                purchase_claimable_rows,
                purchase_non_claimable_rows,
                purchase_totals,
                bank_data,
                gl_rows,
            )

        def _write_statement_cells():
            client_ws = workbook['Client Details']
            company = self.company_id
            client_ws['B4'] = company.name or ''
            client_ws['B5'] = periods['date_start']
            client_ws['B6'] = periods['date_end']
            client_ws['B8'] = self.company_license_number or ''
            client_ws['B9'] = self.company_free_zone or ''
            client_ws['B11'] = self.incorporation_date or ''
            client_ws['B13'] = self.trade_license_activities or ''
            client_ws['B14'] = report_data.get('shareholder_display_text') or ''
            client_ws['B16'] = self.corporate_tax_registration_number or ''
            client_ws['B20'] = self.vat_registration_number or ''

            sofp_ws = workbook['SoFP']
            prev_group_totals = report_data.get('prev_group_totals') or {}
            current_group_totals = report_data.get('current_group_totals') or {}
            sofp_ws['B9'] = self._to_float(report_data.get('current_ppe_total'))
            sofp_ws['C9'] = self._to_float(report_data.get('prev_ppe_total'))
            sofp_ws['B12'] = self._to_float(current_group_totals.get('1202'))
            sofp_ws['C12'] = self._to_float(prev_group_totals.get('1202'))
            sofp_ws['B13'] = self._to_float(current_group_totals.get('1203'))
            sofp_ws['C13'] = self._to_float(prev_group_totals.get('1203'))
            sofp_ws['B14'] = self._sum_prefix_balances(end_balances, '120304')
            sofp_ws['C14'] = self._sum_prefix_balances(prior_end_balances, '120304')
            sofp_ws['B15'] = self._to_float(current_group_totals.get('1204'))
            sofp_ws['C15'] = self._to_float(prev_group_totals.get('1204'))
            sofp_ws['B21'] = self._to_float(report_data.get('share_capital_total'))
            sofp_ws['C21'] = self._to_float(report_data.get('prev_share_capital_total'))
            sofp_ws['B22'] = self._to_float(report_data.get('retained_earnings_balance'))
            sofp_ws['C22'] = self._to_float(report_data.get('prev_retained_earnings_balance'))
            sofp_ws['B23'] = -self._sum_prefix_balances(end_balances, '12040102')
            sofp_ws['C23'] = -self._sum_prefix_balances(prior_end_balances, '12040102')
            sofp_ws['B26'] = abs(self._sum_prefix_balances(end_balances, '2101', '2102'))
            sofp_ws['C26'] = abs(self._sum_prefix_balances(prior_end_balances, '2101', '2102'))
            sofp_ws['B28'] = abs(self._sum_prefix_balances(end_balances, '220303'))
            sofp_ws['C28'] = abs(self._sum_prefix_balances(prior_end_balances, '220303'))
            sofp_ws['B29'] = abs(self._sum_prefix_balances(end_balances, '220302', '2204'))
            sofp_ws['C29'] = abs(self._sum_prefix_balances(prior_end_balances, '220302', '2204'))

            soti_ws = workbook['SoCI']
            revenue_related = -self._sum_prefix_balances(period_balances, '4102')
            prev_revenue_related = -self._sum_prefix_balances(prior_period_balances, '4102')
            revenue_main = -self._sum_prefix_balances(period_balances, '4101')
            prev_revenue_main = -self._sum_prefix_balances(prior_period_balances, '4101')
            soti_ws['B8'] = revenue_main
            soti_ws['C8'] = prev_revenue_main
            soti_ws['B9'] = revenue_related
            soti_ws['C9'] = prev_revenue_related
            soti_ws['B11'] = self._sum_prefix_balances(period_balances, '5101')
            soti_ws['C11'] = self._sum_prefix_balances(prior_period_balances, '5101')
            soti_ws['B16'] = self._sum_prefix_balances(period_balances, '5107')
            soti_ws['C16'] = self._sum_prefix_balances(prior_period_balances, '5107')
            soti_ws['B17'] = self._sum_prefix_balances(period_balances, '5108')
            soti_ws['C17'] = self._sum_prefix_balances(prior_period_balances, '5108')
            soti_ws['B18'] = self._sum_prefix_balances(period_balances, '5102')
            soti_ws['C18'] = self._sum_prefix_balances(prior_period_balances, '5102')
            soti_ws['B19'] = self._sum_prefix_balances(period_balances, '5109')
            soti_ws['C19'] = self._sum_prefix_balances(prior_period_balances, '5109')
            soti_ws['B24'] = self._sum_prefix_balances(period_balances, '5123')
            soti_ws['C24'] = self._sum_prefix_balances(prior_period_balances, '5123')
            soti_ws['B25'] = self._sum_prefix_balances(period_balances, '410305')
            soti_ws['C25'] = self._sum_prefix_balances(prior_period_balances, '410305')
            soti_ws['B29'] = self._to_float(report_data.get('other_income_total'))
            soti_ws['C29'] = self._to_float(report_data.get('prev_other_income_total'))
            soti_ws['B31'] = self._to_float(report_data.get('net_profit_after_tax'))
            soti_ws['C31'] = self._to_float(report_data.get('prev_net_profit_after_tax'))

            soce_ws = workbook['SoCE']
            soce_ws['B7'] = self._to_float(report_data.get('share_capital_total'))
            soce_ws['C7'] = -self._sum_prefix_balances(prior_end_balances, '12040102')
            soce_ws['D7'] = self._to_float(report_data.get('prev_prev_retained_earnings_balance'))
            soce_ws['C9'] = self._to_float(report_data.get('prior_owner_current_account'))
            soce_ws['D10'] = self._to_float(report_data.get('prev_net_profit_after_tax'))
            soce_ws['B13'] = 0.0
            soce_ws['C14'] = self._to_float(report_data.get('owner_current_account'))
            soce_ws['D15'] = self._to_float(report_data.get('net_profit_after_tax'))

            socf_ws = workbook['SoCF']
            socf_ws['B9'] = self._to_float(report_data.get('net_profit_after_tax'))
            socf_ws['C9'] = self._to_float(report_data.get('prev_net_profit_after_tax'))
            socf_ws['B10'] = self._to_float(report_data.get('operating_cashflow_before_working_capital'))
            socf_ws['C10'] = self._to_float(report_data.get('prior_operating_cashflow_before_working_capital'))
            socf_ws['B12'] = self._to_float(report_data.get('change_in_current_assets'))
            socf_ws['C12'] = self._to_float(report_data.get('prior_change_in_current_assets'))
            socf_ws['B13'] = self._to_float(report_data.get('change_in_current_liabilities'))
            socf_ws['C13'] = self._to_float(report_data.get('prior_change_in_current_liabilities'))
            socf_ws['B16'] = self._to_float(report_data.get('current_property'))
            socf_ws['C16'] = self._to_float(report_data.get('prior_property'))
            socf_ws['B19'] = self._to_float(report_data.get('paid_up_capital'))
            socf_ws['C19'] = self._to_float(report_data.get('prior_paid_up_capital'))
            socf_ws['B20'] = self._to_float(report_data.get('owner_current_account'))
            socf_ws['C20'] = self._to_float(report_data.get('prior_owner_current_account'))
            socf_ws['B23'] = self._to_float(report_data.get('cash_beginning_year'))
            socf_ws['C23'] = self._to_float(report_data.get('prior_cash_beginning_year'))
            socf_ws['B24'] = self._to_float(report_data.get('cash_end_of_year'))
            socf_ws['C24'] = self._to_float(report_data.get('prior_cash_end_of_year'))

            summary_ws = workbook['SUMMARY']
            summary_ws['B7'] = revenue_main
            summary_ws['B8'] = self._to_float(report_data.get('operating_expenses_total')) - self._sum_prefix_balances(
                period_balances, '5107'
            )
            summary_ws['B9'] = self._sum_prefix_balances(period_balances, '5107')
            summary_ws['B10'] = self._to_float(report_data.get('net_profit_after_tax'))
            summary_ws['B11'] = self._to_float(report_data.get('total_assets'))
            summary_ws['B12'] = self._to_float(report_data.get('total_liabilities'))
            summary_ws['B13'] = self._to_float(report_data.get('total_equity'))
            summary_ws['B15'] = revenue_related
            summary_ws['B16'] = -self._sum_prefix_balances(end_balances, '12040102')
            summary_ws['B17'] = -self._sum_prefix_balances(period_balances, '410301')
            summary_ws['B18'] = -self._sum_prefix_balances(period_balances, '410302')

        def _write_sales_sheet():
            ws = workbook['Sale ']
            self._clear_rows(ws, 6, 400, 1, 6)
            ws['A6'] = 'Standard rated sales'
            ws['A7'] = 'Client Name'
            ws['B7'] = 'Date'
            ws['C7'] = 'Invoice Number'
            ws['D7'] = 'Gross'
            ws['E7'] = 'VAT'
            ws['F7'] = 'Net'
            row = 8
            for rec in sales_standard_rows:
                ws.cell(row=row, column=1, value=rec['partner'])
                ws.cell(row=row, column=2, value=rec['date'])
                ws.cell(row=row, column=3, value=rec['invoice'])
                ws.cell(row=row, column=4, value=rec['gross'])
                ws.cell(row=row, column=5, value=rec['vat'])
                ws.cell(row=row, column=6, value=rec['net'])
                row += 1
            std_total_row = row
            ws[f'D{std_total_row}'] = f"=SUM(D8:D{max(row - 1, 8)})"
            ws[f'E{std_total_row}'] = f"=SUM(E8:E{max(row - 1, 8)})"
            ws[f'F{std_total_row}'] = f"=SUM(F8:F{max(row - 1, 8)})"

            zero_title_row = std_total_row + 2
            zero_header_row = zero_title_row + 1
            zero_data_start = zero_header_row + 1
            ws[f'A{zero_title_row}'] = 'Zero rated sales'
            ws[f'A{zero_header_row}'] = 'Client Name'
            ws[f'B{zero_header_row}'] = 'Date'
            ws[f'C{zero_header_row}'] = 'Invoice Number'
            ws[f'D{zero_header_row}'] = 'Gross'
            ws[f'E{zero_header_row}'] = 'VAT'
            ws[f'F{zero_header_row}'] = 'Net'

            row = zero_data_start
            for rec in sales_zero_rows:
                ws.cell(row=row, column=1, value=rec['partner'])
                ws.cell(row=row, column=2, value=rec['date'])
                ws.cell(row=row, column=3, value=rec['invoice'])
                ws.cell(row=row, column=4, value=rec['gross'])
                ws.cell(row=row, column=5, value=rec['vat'])
                ws.cell(row=row, column=6, value=rec['net'])
                row += 1
            zero_total_row = row
            ws[f'D{zero_total_row}'] = f"=SUM(D{zero_data_start}:D{max(row - 1, zero_data_start)})"
            ws[f'E{zero_total_row}'] = f"=SUM(E{zero_data_start}:E{max(row - 1, zero_data_start)})"
            ws[f'F{zero_total_row}'] = f"=SUM(F{zero_data_start}:F{max(row - 1, zero_data_start)})"

        def _write_purchases_sheet():
            ws = workbook['Purchases']
            self._clear_rows(ws, 6, 500, 1, 8)
            ws['A6'] = 'Invoiced purchases'
            ws['A7'] = 'VAT claimable'
            ws['A8'] = 'Date'
            ws['B8'] = 'Vendor Name'
            ws['C8'] = 'Inv No'
            ws['D8'] = 'Net (AED)'
            ws['E8'] = 'VAT 5%'
            ws['F8'] = 'Gross(AED) Paid'
            ws['G8'] = 'Amount Due'
            ws['H8'] = 'Payment Date'

            row = 9
            for rec in purchase_claimable_rows:
                ws.cell(row=row, column=1, value=rec['date'])
                ws.cell(row=row, column=2, value=rec['partner'])
                ws.cell(row=row, column=3, value=rec['invoice'])
                ws.cell(row=row, column=4, value=rec['net'])
                ws.cell(row=row, column=5, value=rec['vat'])
                ws.cell(row=row, column=6, value=rec['gross_paid'])
                ws.cell(row=row, column=7, value=rec['due'])
                ws.cell(row=row, column=8, value=rec['payment_date'])
                row += 1
            claim_total_row = row
            ws[f'B{claim_total_row}'] = 'Total'
            ws[f'D{claim_total_row}'] = f"=SUM(D9:D{max(row - 1, 9)})"
            ws[f'E{claim_total_row}'] = f"=SUM(E9:E{max(row - 1, 9)})"
            ws[f'F{claim_total_row}'] = f"=SUM(F9:F{max(row - 1, 9)})"
            ws[f'G{claim_total_row}'] = f"=SUM(G9:G{max(row - 1, 9)})"

            non_claim_title_row = claim_total_row + 2
            non_claim_header_row = non_claim_title_row + 1
            non_claim_data_start = non_claim_header_row + 1
            ws[f'A{non_claim_title_row}'] = 'VAT not claimable'
            ws[f'A{non_claim_header_row}'] = 'Date'
            ws[f'B{non_claim_header_row}'] = 'Vendor Name'
            ws[f'C{non_claim_header_row}'] = 'Inv No'
            ws[f'D{non_claim_header_row}'] = 'Amount'
            ws[f'E{non_claim_header_row}'] = 'Exchange Rate'
            ws[f'F{non_claim_header_row}'] = 'Net (AED)'
            ws[f'G{non_claim_header_row}'] = 'Amount Due'
            ws[f'H{non_claim_header_row}'] = 'Payment Date'

            row = non_claim_data_start
            for rec in purchase_non_claimable_rows:
                ws.cell(row=row, column=1, value=rec['date'])
                ws.cell(row=row, column=2, value=rec['partner'])
                ws.cell(row=row, column=3, value=rec['invoice'])
                ws.cell(row=row, column=4, value=rec['amount'])
                ws.cell(row=row, column=5, value=rec['exchange_rate'])
                ws.cell(row=row, column=6, value=rec['net_aed'])
                ws.cell(row=row, column=7, value=rec['due'])
                ws.cell(row=row, column=8, value=rec['payment_date'])
                row += 1
            non_claim_total_row = row
            ws[f'B{non_claim_total_row}'] = 'Total'
            ws[f'D{non_claim_total_row}'] = (
                f"=SUM(D{non_claim_data_start}:D{max(row - 1, non_claim_data_start)})"
            )
            ws[f'F{non_claim_total_row}'] = (
                f"=SUM(F{non_claim_data_start}:F{max(row - 1, non_claim_data_start)})"
            )
            ws[f'G{non_claim_total_row}'] = (
                f"=SUM(G{non_claim_data_start}:G{max(row - 1, non_claim_data_start)})"
            )

        def _write_bank_sheets():
            ws = workbook['Bank Statement']
            self._clear_rows(ws, 10, 600, 1, 16)
            ws['B10'] = 'Opening Balance'
            ws['I10'] = bank_data['opening_balance']
            ws['L10'] = 'Opening Balance'
            ws['M10'] = '=I10'
            row = 11
            for rec in bank_data['rows']:
                ws.cell(row=row, column=1, value=rec['date'])
                ws.cell(row=row, column=2, value=rec['description'])
                ws.cell(row=row, column=3, value=rec['currency'])
                ws.cell(row=row, column=4, value=rec['amount'])
                ws.cell(row=row, column=5, value=rec['exchange_rate'])
                ws.cell(row=row, column=6, value=rec['gross_dr'])
                ws.cell(row=row, column=7, value=rec['vat_dr'])
                ws.cell(row=row, column=8, value=rec['net_dr'])
                ws.cell(row=row, column=9, value=rec['gross_cr'])
                ws.cell(row=row, column=10, value=rec['vat_cr'])
                ws.cell(row=row, column=11, value=rec['net_cr'])
                ws.cell(row=row, column=12, value=rec['nature'])
                ws.cell(row=row, column=13, value=rec['balance_bs'])
                ws.cell(row=row, column=14, value=f"=M{row - 1}-F{row}+I{row}")
                row += 1
            ws.cell(row=row, column=2, value='Closing Balance')
            ws.cell(row=row, column=6, value=f"=N{max(row - 1, 10)}")
            ws.cell(row=row, column=12, value='Closing Balance')

            tick_ws = workbook['Bank Ticked Back']
            self._clear_rows(tick_ws, 10, 500, 1, 4)
            row = 10
            for rec in bank_data['rows']:
                tick_ws.cell(row=row, column=1, value=rec['date'])
                tick_ws.cell(row=row, column=2, value=rec['description'])
                tick_ws.cell(row=row, column=3, value=rec['net_dr'])
                tick_ws.cell(row=row, column=4, value=rec['net_cr'])
                row += 1

            bal_ws = workbook['Bank Balance']
            self._clear_rows(bal_ws, 7, 120, 1, 7)
            row = 7
            for rec in bank_data['account_balances']:
                bal_ws.cell(row=row, column=1, value=rec['bank_name'])
                bal_ws.cell(row=row, column=2, value=rec['account_title'])
                bal_ws.cell(row=row, column=3, value=rec['account_no'])
                bal_ws.cell(row=row, column=4, value=rec['currency'])
                bal_ws.cell(row=row, column=5, value=rec['amount'])
                bal_ws.cell(row=row, column=6, value=rec['exchange_rate'])
                bal_ws.cell(row=row, column=7, value=rec['amount_aed'])
                row += 1
            bal_ws['G20'] = f"=SUM(G7:G{max(row - 1, 7)})"

            bank_control_ws = workbook['Bank Control']
            opening_bank = self._sum_prefix_balances(opening_balances, '1204')
            receipts = sum(max(self._to_float(r.get('amount')), 0.0) for r in bank_data['rows'])
            payments = sum(max(-self._to_float(r.get('amount')), 0.0) for r in bank_data['rows'])
            closing_bank = self._sum_prefix_balances(end_balances, '1204')
            bank_control_ws['B7'] = opening_bank
            bank_control_ws['C8'] = receipts
            bank_control_ws['B9'] = payments
            bank_control_ws['B11'] = closing_bank

        def _write_control_sheets():
            sl_ws = workbook['SL Control']
            opening_receivable = self._sum_prefix_balances(opening_balances, '1202')
            closing_receivable = self._sum_prefix_balances(end_balances, '1202')
            sl_ws['B7'] = opening_receivable
            sl_ws['C8'] = sales_totals['standard_net'] + sales_totals['zero_net']
            sl_ws['C10'] = sales_totals['standard_vat']
            sl_ws['B14'] = closing_receivable

            pl_ws = workbook['PL Control']
            opening_payables = abs(self._sum_prefix_balances(opening_balances, '2202'))
            closing_payables = abs(self._sum_prefix_balances(end_balances, '2202'))
            pl_ws['C7'] = opening_payables
            pl_ws['B8'] = purchase_totals['claimable_net']
            pl_ws['B10'] = purchase_totals['claimable_vat']
            pl_ws['C12'] = closing_payables

            vat_ws = workbook['VAT Control']
            opening_vat_payable = abs(self._sum_prefix_balances(opening_balances, '220302', '2204'))
            output_vat = sales_totals['standard_vat']
            input_vat = purchase_totals['claimable_vat']
            closing_vat = opening_vat_payable + output_vat - input_vat
            vat_ws['C8'] = opening_vat_payable
            vat_ws['C10'] = output_vat
            vat_ws['B14'] = input_vat
            if closing_vat >= 0:
                vat_ws['C16'] = closing_vat
                vat_ws['B16'] = 0.0
            else:
                vat_ws['B16'] = -closing_vat
                vat_ws['C16'] = 0.0
            vat_ws['B22'] = closing_vat
            vat_ws['C22'] = '=SUM(B22)'

            acc_ws = workbook['Accruals']
            opening_accrual = abs(self._sum_prefix_balances(opening_balances, '220303'))
            closing_accrual = abs(self._sum_prefix_balances(end_balances, '220303'))
            audit_fees = self._sum_prefix_balances(period_balances, '5109')
            acc_ws['C7'] = opening_accrual
            acc_ws['C8'] = audit_fees
            acc_ws['C9'] = closing_accrual

            pre_ws = workbook['Prepayment']
            prepayment_balance = self._sum_prefix_balances(end_balances, '1203')
            pre_ws['B8'] = abs(prepayment_balance)
            pre_ws['B13'] = periods['date_end']
            pre_ws['B16'] = abs(prepayment_balance)

            share_ws = workbook['Share Capital']
            shareholders = []
            for i in range(1, 11):
                name = getattr(self.company_id, f'shareholder_{i}', False)
                shares = getattr(self.company_id, f'number_of_shares_{i}', 0) or 0
                value = getattr(self.company_id, f'share_value_{i}', 0.0) or 0.0
                if not name and not shares and not value:
                    continue
                shareholders.append((name or '', shares, value))
            self._clear_rows(share_ws, 7, 120, 1, 4)
            row = 7
            for name, shares, value in shareholders[:100]:
                share_ws.cell(row=row, column=1, value=name)
                share_ws.cell(row=row, column=2, value=shares)
                share_ws.cell(row=row, column=3, value=value)
                share_ws.cell(row=row, column=4, value=f"=B{row}*C{row}")
                row += 1
            total_row = max(row, 11)
            share_ws.cell(row=total_row, column=2, value=f"=SUM(B7:B{max(row - 1, 7)})")
            share_ws.cell(row=total_row, column=3, value=f"=SUM(C7:C{max(row - 1, 7)})")
            share_ws.cell(row=total_row, column=4, value=f"=SUM(D7:D{max(row - 1, 7)})")

            cash_ws = workbook['Cash in hand']
            cash_ws['B8'] = self._sum_prefix_balances(end_balances, '120401')

            gl_ws = workbook['GLs']
            self._clear_rows(gl_ws, 6, 1200, 1, 8)
            gl_ws['A6'] = 'Date'
            gl_ws['B6'] = 'Move'
            gl_ws['C6'] = 'Account'
            gl_ws['D6'] = 'Label'
            gl_ws['E6'] = 'Debit'
            gl_ws['F6'] = 'Credit'
            gl_ws['G6'] = 'Balance'
            row = 7
            for rec in gl_rows:
                gl_ws.cell(row=row, column=1, value=rec['date'])
                gl_ws.cell(row=row, column=2, value=rec['move'])
                gl_ws.cell(row=row, column=3, value=rec['account'])
                gl_ws.cell(row=row, column=4, value=rec['label'])
                gl_ws.cell(row=row, column=5, value=rec['debit'])
                gl_ws.cell(row=row, column=6, value=rec['credit'])
                gl_ws.cell(row=row, column=7, value=rec['balance'])
                row += 1

            pivot_ws = workbook['Pivot']
            pivot_ws['A7'] = 'Revenue'
            pivot_ws['B7'] = sales_totals['standard_net'] + sales_totals['zero_net']
            pivot_ws['C7'] = 0.0
            pivot_ws['A8'] = 'Purchases'
            pivot_ws['B8'] = purchase_totals['claimable_net'] + purchase_totals['non_claimable_net']
            pivot_ws['C8'] = 0.0

        _write_statement_cells()
        _write_sales_sheet()
        _write_purchases_sheet()
        _write_bank_sheets()
        _write_control_sheets()

        output = BytesIO()
        workbook.save(output)
        output.seek(0)
        filename = (
            f"AFS_{(self.company_id.name or 'Company').replace('/', '-')}_{periods['date_end'].strftime('%Y%m%d')}.xlsx"
        )
        return output.getvalue(), filename

    def action_download_afs_excel(self):
        self.ensure_one()
        self._validate_emphasis_options()
        self._get_excel_periods()
        if self.use_previous_settings:
            self._store_previous_settings()
        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/xlsx/{self.id}',
            'target': 'new',
        }


    def action_print_account_report_lines(self):
        """Generate and display report"""
        self.ensure_one()
        self._validate_emphasis_options()

        if self.use_previous_settings:
            self._store_previous_settings()

        # report_data = self._get_report_data()
        # You can now pass `report_data` to your Word/PDF renderer

        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/view/{self.id}',
            'target': 'new',
        } 

    def _get_saved_document_name(self):
        self.ensure_one()
        report_type_label = dict(self._fields['report_type'].selection).get(self.report_type, self.report_type or '')
        company_name = self.company_id.name or 'Company'
        end_date_label = self.date_end.strftime('%d %B %Y') if self.date_end else ''
        name = f"{company_name} - {report_type_label} {end_date_label}".strip()
        return name or f"Audit Report {self.id}"

    def _get_wizard_snapshot_json(self):
        self.ensure_one()
        snapshot = {
            'wizard_id': self.id,
            'company_id': self.company_id.id,
            'date_start': self.date_start.isoformat() if self.date_start else False,
            'date_end': self.date_end.isoformat() if self.date_end else False,
            'balance_sheet_date_mode': self.balance_sheet_date_mode,
            'report_type': self.report_type,
            'audit_period_category': self.audit_period_category,
            'auditor_type': self.auditor_type,
            'prior_year_mode': self.prior_year_mode,
            'prior_date_start': self.prior_date_start.isoformat() if self.prior_date_start else False,
            'prior_date_end': self.prior_date_end.isoformat() if self.prior_date_end else False,
            'excel_date_start': self.excel_date_start.isoformat() if self.excel_date_start else False,
            'excel_date_end': self.excel_date_end.isoformat() if self.excel_date_end else False,
            'excel_prior_year_mode': self.excel_prior_year_mode,
            'excel_prior_date_start': (
                self.excel_prior_date_start.isoformat() if self.excel_prior_date_start else False
            ),
            'excel_prior_date_end': (
                self.excel_prior_date_end.isoformat() if self.excel_prior_date_end else False
            ),
            'show_related_parties_note': self.show_related_parties_note,
            'share_capital_paid_status': self.share_capital_paid_status,
            'generated_by_user_id': self.env.user.id,
        }
        return json.dumps(snapshot)

    def action_save_editable_report(self):
        """Create a company-scoped saved report document and initial revision."""
        self.ensure_one()
        self._validate_emphasis_options()

        if self.use_previous_settings:
            self._store_previous_settings()

        from ..controllers.main import AuditReportController

        controller = AuditReportController()
        try:
            toc_entries = controller._compute_toc_entries(self)
        except Exception:
            toc_entries = None

        html_with_style = controller._render_report_html(self, toc_entries=toc_entries)
        if not html_with_style:
            raise ValidationError("Unable to render report HTML for saving.")

        document = self.env['audit.report.document'].create({
            'name': self._get_saved_document_name(),
            'company_id': self.company_id.id,
            'date_start': self.date_start,
            'date_end': self.date_end,
            'report_type': self.report_type,
            'audit_period_category': self.audit_period_category,
            'source_wizard_json': self._get_wizard_snapshot_json(),
        })
        revision = document.create_revision_from_html(html_with_style)
        revision._get_pdf_content()

        return {
            'type': 'ir.actions.act_window',
            'name': 'Saved Audit Report',
            'res_model': 'audit.report.document',
            'view_mode': 'form',
            'res_id': document.id,
            'target': 'current',
        }

    def action_print_account_report_pdf(self):
        """Generate and display report as server-side PDF (headless Chrome)."""
        self.ensure_one()
        self._validate_emphasis_options()

        if self.use_previous_settings:
            self._store_previous_settings()

        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/pdf/{self.id}',
            'target': 'new',
        }

    
    

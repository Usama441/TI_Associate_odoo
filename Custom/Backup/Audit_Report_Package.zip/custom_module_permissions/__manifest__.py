{
    'name': 'Custom Module Permissions',
    'version': '19.0.1.0.0',
    'summary': 'Core per-user permission framework for custom modules',
    'description': """
        Core permission category + Users form controls for custom module access.
        Module-specific restrictions are provided by bridge addons.
    """,
    'author': 'TI Associates',
    'license': 'LGPL-3',
    'category': 'Tools',
    'depends': [
        'base',
    ],
    'data': [
        'security/custom_module_permission_groups.xml',
        'views/res_users_views.xml',
    ],
    'installable': True,
    'application': False,
}

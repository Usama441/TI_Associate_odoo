from odoo import http
from odoo.http import request
from jinja2 import Environment, FileSystemLoader
import json
import html as html_lib
import os
import re
import logging
from urllib.parse import quote_plus

_logger = logging.getLogger(__name__)


class AuditReportController(http.Controller):
    _DMCC_FREEZONE_NAME = 'Dubai Multi Commodities Centre Free Zone'

    def _is_dmcc_summary_enabled(self, report):
        return (getattr(report.company_id, 'free_zone', '') or '') == self._DMCC_FREEZONE_NAME

    def _html_to_pdf(self, html_content, base_url=None):
        """Render HTML+CSS to PDF server-side.

        WeasyPrint supports CSS paged media (@page, counters, margin boxes) and
        matches browser print output better than wkhtmltopdf in most cases.
        """
        try:
            from weasyprint import HTML
        except Exception as e:
            raise RuntimeError(f"WeasyPrint is not available in this Odoo environment: {e}")

        return HTML(string=html_content, base_url=base_url).write_pdf()

    def _html_to_pdf_doc(self, html_content, base_url=None):
        """Render HTML to a WeasyPrint document for page counting."""
        try:
            from weasyprint import HTML
        except Exception as e:
            raise RuntimeError(f"WeasyPrint is not available in this Odoo environment: {e}")

        return HTML(string=html_content, base_url=base_url).render()

    def _default_toc_entries(self, report, data):
        signature_names = data.get('signature_names') or []
        director_label_lower = 'director' if len(signature_names) == 1 else 'directors'
        entries = [
            {'label': 'Entity information', 'page_range': '1'},
            {'label': f'Report of {director_label_lower}', 'page_range': '2-3'},
            {'label': 'Independent auditor report', 'page_range': '4-5'},
            {'label': 'Statement of financial position', 'page_range': '6'},
            {'label': 'Statement of profit and loss and other comprehensive income', 'page_range': '7'},
            {'label': 'Statement of changes in equity', 'page_range': '8'},
            {'label': 'Statement of cash flows', 'page_range': '9'},
            {'label': 'Notes to the financial statements', 'page_range': '10-22'},
        ]
        if self._is_dmcc_summary_enabled(report):
            entries.append({'label': 'Summary sheet', 'page_range': '23'})
        return entries

    def _compute_toc_entries(self, report):
        module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        data = report._get_report_data()
        signature_names = data.get('signature_names') or []
        director_label_lower = 'director' if len(signature_names) == 1 else 'directors'
        sections = [
            ('entity_information', 'Entity information'),
            ('report_of_directors', f'Report of {director_label_lower}'),
            ('independent_auditor_report', 'Independent auditor report'),
            ('balance_sheet_page', 'Statement of financial position'),
            ('profit_loss', 'Statement of profit and loss and other comprehensive income'),
            ('changes_in_equity', 'Statement of changes in equity'),
            ('cash_flows', 'Statement of cash flows'),
            ('notes_to_financial_statements', 'Notes to the financial statements'),
        ]
        if self._is_dmcc_summary_enabled(report):
            sections.append(('dmcc_sheet', 'Summary sheet'))

        toc_entries = []
        current_page = 1
        for section_key, label in sections:
            html_with_style = self._render_report_html(
                report,
                sections_to_render=[section_key],
                toc_entries=self._default_toc_entries(report, data),
            )
            doc = self._html_to_pdf_doc(html_with_style, base_url=module_path)
            page_count = len(doc.pages)
            if page_count <= 0:
                continue
            end_page = current_page + page_count - 1
            page_range = str(current_page) if page_count == 1 else f"{current_page}-{end_page}"
            toc_entries.append({'label': label, 'page_range': page_range})
            current_page = end_page + 1

        return toc_entries

    def _render_report_html(self, report, sections_to_render=None, toc_entries=None):
        company = report.company_id
        if not report.exists():
            return None

        module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        templates_path = os.path.join(module_path, 'templates')
        env = Environment(loader=FileSystemLoader(templates_path))
        default_format = env.filters.get('format')

        def format_filter(fmt, *args, **kwargs):
            # Ensure consistent accounting formatting:
            # - thousands separators (12,345.67)
            # - negatives in parentheses ((12,345.67))
            # Applies to printf-style float formats like "%.2f", "%.0f", etc.
            if isinstance(fmt, str) and args:
                m = re.fullmatch(r"%\.(\d+)f", fmt)
            else:
                m = None
            if m and args:
                # Round to whole numbers for all figures in the report.
                decimals = 0
                value = args[0] or 0.0
                try:
                    number = float(value)
                except (TypeError, ValueError):
                    return default_format(fmt, *args, **kwargs) if default_format else fmt % args
                rounded_number = round(number, decimals)
                if rounded_number == 0:
                    return "-"
                if rounded_number < 0:
                    return f"({abs(rounded_number):,.{decimals}f})"
                return f"{rounded_number:,.{decimals}f}"
            return default_format(fmt, *args, **kwargs) if default_format else fmt % args

        def format_percent(fmt, *args, **kwargs):
            """Format percentages with the requested decimals (no rounding to whole)."""
            if isinstance(fmt, str) and args:
                m = re.fullmatch(r"%\.(\d+)f", fmt)
            else:
                m = None
            if m and args:
                decimals = int(m.group(1))
                value = args[0] or 0.0
                try:
                    number = float(value)
                except (TypeError, ValueError):
                    return default_format(fmt, *args, **kwargs) if default_format else fmt % args
                formatted = f"{abs(number):,.{decimals}f}"
                if decimals:
                    formatted = formatted.rstrip('0').rstrip('.')
                if number < 0:
                    return f"({formatted})"
                return formatted
            return default_format(fmt, *args, **kwargs) if default_format else fmt % args

        def running_case_filter(value):
            """Convert headings/labels to sentence case while keeping acronyms (VAT/IFRS/UAE/ROU/etc)."""
            if value is None:
                return ''
            text = str(value).strip()
            if not text:
                return ''

            parts = re.split(r'(\s+)', text)
            out = []
            for part in parts:
                if not part or part.isspace():
                    out.append(part)
                    continue
                token = part
                # Keep acronyms and codes (all-caps), and anything containing digits.
                if token.isupper() or any(ch.isdigit() for ch in token):
                    out.append(token)
                else:
                    out.append(token.lower())

            # Capitalize the first alphabetic character (if the first token isn't an acronym).
            for i, part in enumerate(out):
                if not part or part.isspace():
                    continue
                if part.isupper():  # acronym in first position
                    break
                for j, ch in enumerate(part):
                    if ch.isalpha():
                        out[i] = part[:j] + ch.upper() + part[j + 1:]
                        break
                break
            return ''.join(out)

        env.filters['format'] = format_filter
        env.filters['format_percent'] = format_percent
        env.filters['rcase'] = running_case_filter

        data = report._get_report_data()
        period_category = (report.audit_period_category or '').lower()
        if period_category.startswith('dormant_'):
            template_name = (
                'audit_report_template_dormant_2y.html'
                if data.get('show_prior_year')
                else 'audit_report_template_dormant_1y.html'
            )
        else:
            template_name = (
                'audit_report_template_2y.html'
                if data.get('show_prior_year')
                else 'audit_report_template_1y.html'
            )
        template = env.get_template(template_name)
        report_type_label = dict(report._fields['report_type'].selection).get(report.report_type, '')
        report_period_end = report.date_end.strftime("%d %B %Y") if report.date_end else ''
        report_title = f"{report_type_label} {report_period_end}".strip()
        activity = getattr(company, 'trade_license_activities', '') or ''
        implementing_regulations_freezone = getattr(company, 'implementing_regulations_freezone', '') or ''
        if not implementing_regulations_freezone and hasattr(company, '_get_free_zone_implementing_regulations'):
            implementing_regulations_freezone = (
                company._get_free_zone_implementing_regulations(getattr(company, 'free_zone', '')) or ''
            )

        context = {
            'company': company,
            'company_name': getattr(company, 'name', ''),
            'freezone': getattr(company, 'free_zone', ''),
            'implementing_regulations_freezone': implementing_regulations_freezone,
            'license': getattr(company, 'company_license_number', ''),
            'owner': getattr(company, 'owner', ''),
            'business_activity': activity.lower(),
            'date_start': report.date_start,
            'date_end': report.date_end,
            'freezone_selection': report.auditor_type,
            'report_title': report_title,
            'report_type': report.report_type,
            'report_period_end': report_period_end,
            'sections_to_render': sections_to_render,
        }
        context.update(data)
        if toc_entries is None:
            toc_entries = self._default_toc_entries(report, data)
        context['toc_entries'] = toc_entries

        html_content = template.render(**context)
        css_path = os.path.join(templates_path, 'audit_report_style.css')
        with open(css_path, 'r') as f:
            css_content = f.read()

        return html_content.replace('</head>', f'<style>{css_content}</style></head>')
    
    @http.route('/audit_report/view/<int:report_id>', type='http', auth='user')
    def view_report(self, report_id, **kwargs):
        report = request.env['audit.report'].browse(report_id)
        html_with_style = self._render_report_html(report)
        if not html_with_style:
            return request.not_found()
        
        return request.make_response(
            html_with_style,
            headers=[
                ('Content-Type', 'text/html; charset=utf-8'),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ]
        )

    @http.route('/audit_report/pdf/<int:report_id>', type='http', auth='user')
    def view_report_pdf(self, report_id, **kwargs):
        report = request.env['audit.report'].browse(report_id)
        try:
            toc_entries = self._compute_toc_entries(report)
        except Exception as e:
            _logger.exception("Audit report TOC generation failed: %s", e)
            toc_entries = None
        html_with_style = self._render_report_html(report, toc_entries=toc_entries)
        if not html_with_style:
            return request.not_found()

        try:
            module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            pdf_content = self._html_to_pdf(html_with_style, base_url=module_path)
        except Exception as e:
            _logger.exception("Audit report PDF generation failed: %s", e)
            return request.make_response(
                f"Audit report PDF generation failed.\n\n{e}\n",
                headers=[('Content-Type', 'text/plain; charset=utf-8')],
                status=500,
            )
        filename = f'Audit_Report_{report.id}.pdf'
        return request.make_response(
            pdf_content,
            headers=[
                ('Content-Type', 'application/pdf'),
                ('Content-Disposition', f'inline; filename="{filename}"'),
                ('Content-Length', str(len(pdf_content))),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ]
        )

    def _forbidden_response(self, message='Forbidden'):
        return request.make_response(
            message,
            headers=[('Content-Type', 'text/plain; charset=utf-8')],
            status=403,
        )

    def _load_revision(self, revision_id, include_removed=True):
        revision = request.env['audit.report.revision'].browse(revision_id)
        if not revision.exists():
            return None
        user_company_ids = request.env.user.company_ids.ids
        if revision.company_id.id not in user_company_ids:
            return None
        if not include_removed and revision.is_removed:
            return None
        return revision

    def _render_editor_shell(self, title, body_html):
        title_escaped = html_lib.escape(title or 'Editor')
        return f"""
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>{title_escaped}</title>
    <style>
      body {{
        margin: 0;
        font-family: Arial, sans-serif;
        background: #f6f7fb;
        color: #1d2733;
      }}
      .page {{
        max-width: 1400px;
        margin: 0 auto;
        padding: 20px;
      }}
      .panel {{
        background: #fff;
        border: 1px solid #d9dee8;
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 16px;
      }}
      .muted {{
        color: #6b7280;
        font-size: 13px;
      }}
      .ok {{
        background: #e8f7ec;
        border: 1px solid #9bd7ac;
        color: #0f5132;
        border-radius: 6px;
        padding: 10px 12px;
        margin-bottom: 12px;
      }}
      .btn {{
        display: inline-block;
        background: #235dff;
        color: #fff;
        border: none;
        border-radius: 6px;
        padding: 10px 14px;
        text-decoration: none;
        cursor: pointer;
        font-size: 14px;
      }}
      .btn-secondary {{
        background: #4b5563;
      }}
      .btn-danger {{
        background: #b91c1c;
      }}
      .links a {{
        margin-right: 8px;
      }}
      table {{
        border-collapse: collapse;
        width: 100%;
      }}
      th, td {{
        border: 1px solid #d0d7e2;
        padding: 6px;
        vertical-align: top;
      }}
      input[type=\"text\"], textarea, select {{
        width: 100%;
        box-sizing: border-box;
        padding: 8px;
        border: 1px solid #c6cdd9;
        border-radius: 6px;
        font-size: 14px;
      }}
      textarea {{
        min-height: 65vh;
        font-family: monospace;
      }}
      .table-list {{
        display: grid;
        grid-template-columns: 320px 1fr;
        gap: 16px;
      }}
      .table-list ul {{
        list-style: none;
        margin: 0;
        padding: 0;
      }}
      .table-list li {{
        border: 1px solid #d9dee8;
        border-radius: 6px;
        margin-bottom: 8px;
        background: #fff;
      }}
      .table-list li a {{
        display: block;
        padding: 10px 12px;
        text-decoration: none;
        color: #1d2733;
      }}
      .table-list li.active {{
        background: #ecf2ff;
        border-color: #9cb6ff;
      }}
      .small {{
        font-size: 12px;
        color: #6b7280;
      }}
      .toolbar {{
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 12px;
      }}
      .toolbar button {{
        background: #eef2ff;
        border: 1px solid #bfccff;
        color: #243b85;
        border-radius: 6px;
        padding: 8px 10px;
        cursor: pointer;
      }}
      .editor-frame {{
        width: 100%;
        min-height: 78vh;
        border: 1px solid #c9d4e5;
        border-radius: 8px;
        background: white;
      }}
    </style>
  </head>
  <body>
    <div class=\"page\">
      {body_html}
    </div>
  </body>
</html>
"""

    def _render_structured_editor_page(self, revision, selected_table_key=None, saved=False):
        tables = revision.get_table_index()
        if not tables:
            content = (
                "<div class='panel'><h2>Structured Table Editor</h2>"
                "<p class='muted'>No tables were found in this revision.</p></div>"
            )
            return self._render_editor_shell('Structured Table Editor', content)

        selected_table_key = selected_table_key or tables[0].get('key')
        if selected_table_key not in [table.get('key') for table in tables]:
            selected_table_key = tables[0].get('key')

        payload = revision.get_table_payload(selected_table_key)
        selected_table_meta = next(
            (table for table in tables if table.get('key') == selected_table_key),
            {}
        )
        is_soce_table = (selected_table_meta.get('section') or '') == 'changes_in_equity'
        csrf = request.csrf_token()
        saved_banner = "<div class='ok'>Saved as a new revision successfully.</div>" if saved else ""
        back_url = f"/web#id={revision.id}&model=audit.report.revision&view_type=form"
        preview_url = f"/audit_report/revision/{revision.id}/preview"
        freeform_url = f"/audit_report/revision/{revision.id}/edit/freeform"
        table_rows = payload.get('rows') or []
        row_count = int(payload.get('body_row_count') or len(table_rows) or 0)
        col_count = int(selected_table_meta.get('cols') or 0) or max((len(row) for row in table_rows), default=0)
        default_target_row = row_count or 1
        default_target_col = col_count or 1
        if is_soce_table:
            column_controls_html = (
                f"<div class=\"toolbar\">"
                f"<label class=\"small\">Column #:"
                f"<input type=\"number\" name=\"target_col\" min=\"2\" value=\"{max(default_target_col, 2)}\" style=\"width: 90px; margin-left: 4px;\" />"
                f"</label>"
                f"<button class=\"btn btn-secondary\" type=\"submit\" name=\"table_action\" value=\"add_col_after\">Add SOCE Column After</button>"
                f"<button class=\"btn btn-secondary\" type=\"submit\" name=\"table_action\" value=\"remove_col\">Remove SOCE Column</button>"
                f"</div>"
                "<p class='small'><strong>SOCE rule:</strong> Column #1 is description and cannot be removed.</p>"
            )
        else:
            column_controls_html = (
                f"<div class=\"toolbar\">"
                f"<label class=\"small\">Column #:"
                f"<input type=\"number\" name=\"target_col\" min=\"1\" value=\"{default_target_col}\" style=\"width: 90px; margin-left: 4px;\" />"
                f"</label>"
                f"<button class=\"btn btn-secondary\" type=\"submit\" name=\"table_action\" value=\"add_col_after\">Add Column After</button>"
                f"<button class=\"btn btn-secondary\" type=\"submit\" name=\"table_action\" value=\"remove_col\">Remove Column</button>"
                f"</div>"
            )

        table_links = []
        for table in tables:
            key = table.get('key') or ''
            section = html_lib.escape(table.get('section') or 'section')
            preview = html_lib.escape(table.get('preview') or '')
            rows = table.get('rows') or 0
            cols = table.get('cols') or 0
            active_class = 'active' if key == selected_table_key else ''
            url = f"/audit_report/revision/{revision.id}/edit/structured?table_key={quote_plus(key)}"
            table_links.append(
                "<li class='{active}'>"
                "<a href='{url}'><strong>{section} / {key}</strong><br>"
                "<span class='small'>{rows} rows x {cols} cols</span><br>"
                "<span class='small'>{preview}</span></a></li>".format(
                    active=active_class,
                    url=url,
                    section=section,
                    key=html_lib.escape(key),
                    rows=rows,
                    cols=cols,
                    preview=preview,
                )
            )

        matrix_rows = []
        for row in payload.get('rows') or []:
            cells = []
            for cell in row:
                value = html_lib.escape(cell.get('value') or '')
                field_name = html_lib.escape(cell.get('name') or '')
                tag = (cell.get('tag') or 'td').lower()
                if tag == 'th':
                    cells.append(f"<th><input type='text' name='{field_name}' value='{value}' /></th>")
                else:
                    cells.append(f"<td><input type='text' name='{field_name}' value='{value}' /></td>")
            matrix_rows.append(f"<tr>{''.join(cells)}</tr>")

        body = f"""
{saved_banner}
<div class=\"panel\">
  <h2>Structured Table Editor</h2>
  <p class=\"muted\">Revision v{revision.version_no} of {html_lib.escape(revision.document_id.name)}</p>
  <div class=\"links\">
    <a class=\"btn btn-secondary\" href=\"{back_url}\">Back to Revision</a>
    <a class=\"btn btn-secondary\" href=\"{preview_url}\" target=\"_blank\">Preview</a>
    <a class=\"btn\" href=\"{freeform_url}\" target=\"_blank\">Open Freeform Editor</a>
  </div>
</div>
<div class=\"table-list\">
  <div class=\"panel\">
    <h3>All Tables</h3>
    <ul>{''.join(table_links)}</ul>
  </div>
  <div class=\"panel\">
    <h3>Editing: {html_lib.escape(selected_table_key)}</h3>
    <p class=\"muted\">You can edit values below, and also add/remove rows or columns.</p>
    <form method=\"post\" action=\"/audit_report/revision/{revision.id}/save/structured\">
      <input type=\"hidden\" name=\"csrf_token\" value=\"{html_lib.escape(csrf)}\" />
      <input type=\"hidden\" name=\"table_key\" value=\"{html_lib.escape(selected_table_key)}\" />
      <div class=\"toolbar\">
        <label class=\"small\">Body Row #:
          <input type=\"number\" name=\"target_row\" min=\"1\" value=\"{default_target_row}\" style=\"width: 90px; margin-left: 4px;\" />
        </label>
        <button class=\"btn btn-secondary\" type=\"submit\" name=\"table_action\" value=\"add_row_after\">Add Row After</button>
        <button class=\"btn btn-secondary\" type=\"submit\" name=\"table_action\" value=\"remove_row\">Remove Row</button>
      </div>
      {column_controls_html}
      <table>{''.join(matrix_rows)}</table>
      <br/>
      <button class=\"btn\" type=\"submit\" name=\"table_action\" value=\"save\">Save as New Revision</button>
    </form>
  </div>
</div>
"""
        return self._render_editor_shell('Structured Table Editor', body)

    def _render_freeform_editor_page(self, revision, saved=False):
        csrf = request.csrf_token()
        saved_banner = "<div class='ok'>Saved as a new revision successfully.</div>" if saved else ""
        initial_html_js = json.dumps(revision.html_content or '')
        back_url = f"/web#id={revision.id}&model=audit.report.revision&view_type=form"
        preview_url = f"/audit_report/revision/{revision.id}/preview"
        structured_url = f"/audit_report/revision/{revision.id}/edit/structured"

        body = f"""
{saved_banner}
<div class=\"panel\">
  <h2>Visual Layout Editor</h2>
  <p class=\"muted\">Revision v{revision.version_no} of {html_lib.escape(revision.document_id.name)}</p>
  <p class=\"muted\">Edit directly on the report layout below (non-technical mode). Use Save to create a new revision.</p>
  <div class=\"links\">
    <a class=\"btn btn-secondary\" href=\"{back_url}\">Back to Revision</a>
    <a class=\"btn btn-secondary\" href=\"{preview_url}\" target=\"_blank\">Preview</a>
    <a class=\"btn\" href=\"{structured_url}\" target=\"_blank\">Open Structured Editor</a>
  </div>
</div>
<div class=\"panel\">
  <div class=\"toolbar\">
    <button type=\"button\" data-cmd=\"bold\">Bold</button>
    <button type=\"button\" data-cmd=\"italic\">Italic</button>
    <button type=\"button\" data-cmd=\"underline\">Underline</button>
    <button type=\"button\" data-cmd=\"insertUnorderedList\">Bullet List</button>
    <button type=\"button\" data-cmd=\"justifyLeft\">Align Left</button>
    <button type=\"button\" data-cmd=\"justifyCenter\">Align Center</button>
    <button type=\"button\" data-cmd=\"justifyRight\">Align Right</button>
    <button type=\"button\" id=\"undoBtn\">Undo</button>
    <button type=\"button\" id=\"redoBtn\">Redo</button>
    <button type=\"button\" id=\"resetBtn\">Reset</button>
  </div>
  <iframe id=\"visualEditorFrame\" class=\"editor-frame\"></iframe>
  <form method=\"post\" action=\"/audit_report/revision/{revision.id}/save/freeform\">
    <input type=\"hidden\" name=\"csrf_token\" value=\"{html_lib.escape(csrf)}\" />
    <input type=\"hidden\" id=\"visualHtmlPayload\" name=\"html_content\" value=\"\" />
    <br/><br/>
    <button class=\"btn\" type=\"button\" id=\"saveVisualBtn\">Save as New Revision</button>
  </form>
</div>
<script>
  (function () {{
    const initialHtml = {initial_html_js};
    const iframe = document.getElementById('visualEditorFrame');
    const payload = document.getElementById('visualHtmlPayload');
    const saveBtn = document.getElementById('saveVisualBtn');
    const resetBtn = document.getElementById('resetBtn');
    const undoBtn = document.getElementById('undoBtn');
    const redoBtn = document.getElementById('redoBtn');
    const commandButtons = Array.from(document.querySelectorAll('.toolbar button[data-cmd]'));

    function loadEditorContent() {{
      iframe.srcdoc = initialHtml || '<!doctype html><html><head><meta charset=\"utf-8\"></head><body></body></html>';
    }}

    function focusEditor() {{
      if (iframe.contentWindow) {{
        iframe.contentWindow.focus();
      }}
    }}

    iframe.addEventListener('load', function () {{
      const doc = iframe.contentDocument;
      if (!doc) {{
        return;
      }}
      try {{
        doc.designMode = 'on';
      }} catch (e) {{
        // Fallback if designMode is restricted.
      }}
      if (doc.body) {{
        doc.body.setAttribute('contenteditable', 'true');
      }}
    }});

    commandButtons.forEach(function (button) {{
      button.addEventListener('click', function () {{
        const cmd = button.getAttribute('data-cmd');
        const doc = iframe.contentDocument;
        if (!doc) {{
          return;
        }}
        focusEditor();
        doc.execCommand(cmd, false, null);
      }});
    }});

    undoBtn.addEventListener('click', function () {{
      const doc = iframe.contentDocument;
      if (doc) {{
        focusEditor();
        doc.execCommand('undo', false, null);
      }}
    }});

    redoBtn.addEventListener('click', function () {{
      const doc = iframe.contentDocument;
      if (doc) {{
        focusEditor();
        doc.execCommand('redo', false, null);
      }}
    }});

    resetBtn.addEventListener('click', function () {{
      if (confirm('Reset editor to the revision start state? Unsaved changes will be lost.')) {{
        loadEditorContent();
      }}
    }});

    saveBtn.addEventListener('click', function () {{
      const doc = iframe.contentDocument;
      if (!doc || !doc.documentElement) {{
        alert('Editor is not ready yet. Please wait a second and try again.');
        return;
      }}
      payload.value = '<!doctype html>\\n' + doc.documentElement.outerHTML;
      saveBtn.form.submit();
    }});

    loadEditorContent();
  }})();
</script>
"""
        return self._render_editor_shell('Visual Layout Editor', body)

    @http.route('/audit_report/revision/<int:revision_id>/preview', type='http', auth='user')
    def view_revision_preview(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()
        return request.make_response(
            revision.html_content or '',
            headers=[
                ('Content-Type', 'text/html; charset=utf-8'),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ],
        )

    @http.route('/audit_report/revision/<int:revision_id>/pdf', type='http', auth='user')
    def view_revision_pdf(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()

        try:
            pdf_content = revision._get_pdf_content()
        except Exception as e:
            _logger.exception("Saved revision PDF generation failed: %s", e)
            return request.make_response(
                f"Revision PDF generation failed.\n\n{e}\n",
                headers=[('Content-Type', 'text/plain; charset=utf-8')],
                status=500,
            )

        filename = f'Audit_Report_{revision.document_id.id}_v{revision.version_no}.pdf'
        return request.make_response(
            pdf_content,
            headers=[
                ('Content-Type', 'application/pdf'),
                ('Content-Disposition', f'inline; filename=\"{filename}\"'),
                ('Content-Length', str(len(pdf_content))),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ],
        )

    @http.route('/audit_report/revision/<int:revision_id>/tables', type='http', auth='user')
    def list_revision_tables(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=True)
        if not revision:
            return request.not_found()
        payload = {
            'revision_id': revision.id,
            'version_no': revision.version_no,
            'company_id': revision.company_id.id,
            'tables': revision.get_table_index(),
        }
        return request.make_response(
            json.dumps(payload),
            headers=[('Content-Type', 'application/json; charset=utf-8')],
        )

    @http.route('/audit_report/revision/<int:revision_id>/edit/structured', type='http', auth='user')
    def edit_revision_structured(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()
        selected_table_key = kwargs.get('table_key')
        saved = str(kwargs.get('saved') or '').lower() in ('1', 'true', 'yes')
        page = self._render_structured_editor_page(revision, selected_table_key=selected_table_key, saved=saved)
        return request.make_response(
            page,
            headers=[('Content-Type', 'text/html; charset=utf-8')],
        )

    @http.route(
        '/audit_report/revision/<int:revision_id>/save/structured',
        type='http',
        auth='user',
        methods=['POST'],
    )
    def save_revision_structured(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()

        table_key = kwargs.get('table_key') or ''
        table_action = kwargs.get('table_action') or 'save'
        target_row = kwargs.get('target_row') or 0
        target_col = kwargs.get('target_col') or 0
        posted_cells = {
            key: value
            for key, value in kwargs.items()
            if key.startswith('cell_')
        }
        try:
            html_content = revision.apply_structured_table_changes(
                table_key,
                posted_cells,
                table_action=table_action,
                target_row=target_row,
                target_col=target_col,
            )
            new_revision = revision.create_next_revision(html_content)
        except Exception as e:
            _logger.exception("Structured table save failed: %s", e)
            return request.make_response(
                f"Structured save failed: {e}",
                headers=[('Content-Type', 'text/plain; charset=utf-8')],
                status=400,
            )

        url = f'/audit_report/revision/{new_revision.id}/edit/structured?saved=1'
        if table_key:
            url += f'&table_key={quote_plus(table_key)}'
        return request.redirect(url)

    @http.route('/audit_report/revision/<int:revision_id>/edit/freeform', type='http', auth='user')
    def edit_revision_freeform(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()

        saved = str(kwargs.get('saved') or '').lower() in ('1', 'true', 'yes')
        page = self._render_freeform_editor_page(revision, saved=saved)
        return request.make_response(
            page,
            headers=[('Content-Type', 'text/html; charset=utf-8')],
        )

    @http.route(
        '/audit_report/revision/<int:revision_id>/save/freeform',
        type='http',
        auth='user',
        methods=['POST'],
    )
    def save_revision_freeform(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()

        html_content = kwargs.get('html_content') or ''
        if not html_content.strip():
            return request.make_response(
                "Freeform HTML cannot be empty.",
                headers=[('Content-Type', 'text/plain; charset=utf-8')],
                status=400,
            )
        try:
            new_revision = revision.create_next_revision(html_content)
        except Exception as e:
            _logger.exception("Freeform save failed: %s", e)
            return request.make_response(
                f"Freeform save failed: {e}",
                headers=[('Content-Type', 'text/plain; charset=utf-8')],
                status=400,
            )

        return request.redirect(f'/audit_report/revision/{new_revision.id}/edit/freeform?saved=1')

    @http.route(
        '/audit_report/revision/<int:revision_id>/remove',
        type='http',
        auth='user',
        methods=['POST'],
    )
    def remove_revision(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=True)
        if not revision:
            return request.not_found()
        revision.action_soft_remove()
        next_url = kwargs.get('next') or (
            f'/web#id={revision.document_id.id}&model=audit.report.document&view_type=form'
        )
        return request.redirect(next_url)

    @http.route(
        '/audit_report/revision/<int:revision_id>/restore',
        type='http',
        auth='user',
        methods=['POST'],
    )
    def restore_revision(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=True)
        if not revision:
            return request.not_found()
        revision.action_restore()
        next_url = kwargs.get('next') or (
            f'/web#id={revision.id}&model=audit.report.revision&view_type=form'
        )
        return request.redirect(next_url)

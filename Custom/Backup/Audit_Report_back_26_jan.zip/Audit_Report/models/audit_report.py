import json
from dateutil.relativedelta import relativedelta
from odoo import models, fields, api


class AuditReport(models.TransientModel):
    _name = 'audit.report'
    _description = 'Audit Report'

    date_start = fields.Date(string='Date Start', required=True)
    date_end = fields.Date(string='Date End', required=True)
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company,
    )

    auditor_type = fields.Selection(
        [
            ('default', 'Default'),
            ('ifza', 'IFZA'),
            ('dmcc', 'DMCC'),
        ],
        string='Freezone City',
        required=True,
        default='default',
    )
    report_type = fields.Selection(
        [
            ('period', 'Financial Statements for the Period Ended'),
            ('year', 'Financial Statements for the Year Ended'),
            ('management', 'Management Accounts for the Period Ended'),
        ],
        string='Report Type',
        required=True,
        default='period',
    )
    use_previous_settings = fields.Boolean(
        string='Use Previous Settings',
        default=True,
    )
    audit_period_category = fields.Selection(
        [
            ('cessation_2y', '2 Years Cessation'),
            ('cessation_1y', '1 Year Cessation'),
            ('normal_1y', '1 Year Normal'),
            ('normal_2y', '2 Years Normal'),
            ('dormant_1y', '1 Year Dormant'),
            ('dormant_2y', '2 Years Dormant'),
        ],
        string='Audit Period Category',
        default='normal_2y',
    )
    prior_year_mode = fields.Selection(
        [
            ('auto', 'Auto (1 year back)'),
            ('manual', 'Manual selection'),
        ],
        string='Prior Year Dates',
        required=True,
        default='auto',
    )
    prior_date_start = fields.Date(string='Prior Date Start')
    prior_date_end = fields.Date(string='Prior Date End')

    # Company info (related to res.company)
    company_street = fields.Char(
        related='company_id.street',
        string='Address',
        readonly=False,
    )
    company_free_zone = fields.Char(
        related='company_id.free_zone',
        readonly=False,
    )
    company_license_number = fields.Char(
        related='company_id.company_license_number',
        readonly=False,
    )
    trade_license_activities = fields.Text(
        related='company_id.trade_license_activities',
        readonly=False,
    )
    incorporation_date = fields.Date(
        related='company_id.incorporation_date',
        readonly=False,
    )
    corporate_tax_registration_number = fields.Char(
        related='company_id.corporate_tax_registration_number',
        readonly=False,
    )
    vat_registration_number = fields.Char(
        related='company_id.vat_registration_number',
        readonly=False,
    )
    corporate_tax_start_date = fields.Date(
        related='company_id.corporate_tax_start_date',
        readonly=False,
    )
    corporate_tax_end_date = fields.Date(
        related='company_id.corporate_tax_end_date',
        readonly=False,
    )
    implementing_regulations_freezone = fields.Text(
        related='company_id.implementing_regulations_freezone',
        readonly=False,
    )

    # Shareholders (related to res.company)
    shareholder_1 = fields.Char(related='company_id.shareholder_1', readonly=False)
    shareholder_2 = fields.Char(related='company_id.shareholder_2', readonly=False)
    shareholder_3 = fields.Char(related='company_id.shareholder_3', readonly=False)
    shareholder_4 = fields.Char(related='company_id.shareholder_4', readonly=False)
    shareholder_5 = fields.Char(related='company_id.shareholder_5', readonly=False)
    shareholder_6 = fields.Char(related='company_id.shareholder_6', readonly=False)
    shareholder_7 = fields.Char(related='company_id.shareholder_7', readonly=False)
    shareholder_8 = fields.Char(related='company_id.shareholder_8', readonly=False)
    shareholder_9 = fields.Char(related='company_id.shareholder_9', readonly=False)
    shareholder_10 = fields.Char(related='company_id.shareholder_10', readonly=False)

    nationality_1 = fields.Char(related='company_id.nationality_1', readonly=False)
    nationality_2 = fields.Char(related='company_id.nationality_2', readonly=False)
    nationality_3 = fields.Char(related='company_id.nationality_3', readonly=False)
    nationality_4 = fields.Char(related='company_id.nationality_4', readonly=False)
    nationality_5 = fields.Char(related='company_id.nationality_5', readonly=False)
    nationality_6 = fields.Char(related='company_id.nationality_6', readonly=False)
    nationality_7 = fields.Char(related='company_id.nationality_7', readonly=False)
    nationality_8 = fields.Char(related='company_id.nationality_8', readonly=False)
    nationality_9 = fields.Char(related='company_id.nationality_9', readonly=False)
    nationality_10 = fields.Char(related='company_id.nationality_10', readonly=False)

    number_of_shares_1 = fields.Integer(related='company_id.number_of_shares_1', readonly=False)
    number_of_shares_2 = fields.Integer(related='company_id.number_of_shares_2', readonly=False)
    number_of_shares_3 = fields.Integer(related='company_id.number_of_shares_3', readonly=False)
    number_of_shares_4 = fields.Integer(related='company_id.number_of_shares_4', readonly=False)
    number_of_shares_5 = fields.Integer(related='company_id.number_of_shares_5', readonly=False)
    number_of_shares_6 = fields.Integer(related='company_id.number_of_shares_6', readonly=False)
    number_of_shares_7 = fields.Integer(related='company_id.number_of_shares_7', readonly=False)
    number_of_shares_8 = fields.Integer(related='company_id.number_of_shares_8', readonly=False)
    number_of_shares_9 = fields.Integer(related='company_id.number_of_shares_9', readonly=False)
    number_of_shares_10 = fields.Integer(related='company_id.number_of_shares_10', readonly=False)

    share_value_1 = fields.Float(related='company_id.share_value_1', readonly=False)
    share_value_2 = fields.Float(related='company_id.share_value_2', readonly=False)
    share_value_3 = fields.Float(related='company_id.share_value_3', readonly=False)
    share_value_4 = fields.Float(related='company_id.share_value_4', readonly=False)
    share_value_5 = fields.Float(related='company_id.share_value_5', readonly=False)
    share_value_6 = fields.Float(related='company_id.share_value_6', readonly=False)
    share_value_7 = fields.Float(related='company_id.share_value_7', readonly=False)
    share_value_8 = fields.Float(related='company_id.share_value_8', readonly=False)
    share_value_9 = fields.Float(related='company_id.share_value_9', readonly=False)
    share_value_10 = fields.Float(related='company_id.share_value_10', readonly=False)

    total_share_1 = fields.Float(related='company_id.total_share_1', readonly=True)
    total_share_2 = fields.Float(related='company_id.total_share_2', readonly=True)
    total_share_3 = fields.Float(related='company_id.total_share_3', readonly=True)
    total_share_4 = fields.Float(related='company_id.total_share_4', readonly=True)
    total_share_5 = fields.Float(related='company_id.total_share_5', readonly=True)
    total_share_6 = fields.Float(related='company_id.total_share_6', readonly=True)
    total_share_7 = fields.Float(related='company_id.total_share_7', readonly=True)
    total_share_8 = fields.Float(related='company_id.total_share_8', readonly=True)
    total_share_9 = fields.Float(related='company_id.total_share_9', readonly=True)
    total_share_10 = fields.Float(related='company_id.total_share_10', readonly=True)

    def _previous_settings_key(self):
        return f'audit_report_wizard.prev_settings.user_{self.env.user.id}'

    def _get_previous_settings(self):
        param = self.env['ir.config_parameter'].sudo()
        raw = param.get_param(self._previous_settings_key(), default='')
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except (TypeError, ValueError):
            return {}

    def _store_previous_settings(self):
        data = {
            'date_start': self.date_start.isoformat() if self.date_start else False,
            'date_end': self.date_end.isoformat() if self.date_end else False,
            'prior_year_mode': self.prior_year_mode,
            'prior_date_start': self.prior_date_start.isoformat() if self.prior_date_start else False,
            'prior_date_end': self.prior_date_end.isoformat() if self.prior_date_end else False,
            'report_type': self.report_type,
            'auditor_type': self.auditor_type,
            'audit_period_category': self.audit_period_category,
            'company_id': self.company_id.id if self.company_id else False,
        }
        self.env['ir.config_parameter'].sudo().set_param(
            self._previous_settings_key(),
            json.dumps(data),
        )

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        if not res.get('use_previous_settings', True):
            return res
        data = self._get_previous_settings()
        if not data:
            return res
        if 'date_start' in fields_list and data.get('date_start'):
            res['date_start'] = fields.Date.to_date(data['date_start'])
        if 'date_end' in fields_list and data.get('date_end'):
            res['date_end'] = fields.Date.to_date(data['date_end'])
        if 'prior_year_mode' in fields_list and data.get('prior_year_mode'):
            res['prior_year_mode'] = data['prior_year_mode']
        if 'prior_date_start' in fields_list and data.get('prior_date_start'):
            res['prior_date_start'] = fields.Date.to_date(data['prior_date_start'])
        if 'prior_date_end' in fields_list and data.get('prior_date_end'):
            res['prior_date_end'] = fields.Date.to_date(data['prior_date_end'])
        if 'report_type' in fields_list and data.get('report_type'):
            res['report_type'] = data['report_type']
        if 'auditor_type' in fields_list and data.get('auditor_type'):
            res['auditor_type'] = data['auditor_type']
        if 'audit_period_category' in fields_list and data.get('audit_period_category'):
            res['audit_period_category'] = data['audit_period_category']
        if 'company_id' in fields_list and data.get('company_id'):
            res['company_id'] = data['company_id']
        return res

    @api.onchange('use_previous_settings')
    def _onchange_use_previous_settings(self):
        if self.use_previous_settings:
            data = self._get_previous_settings()
            if data.get('date_start'):
                self.date_start = fields.Date.to_date(data['date_start'])
            if data.get('date_end'):
                self.date_end = fields.Date.to_date(data['date_end'])
            if data.get('prior_year_mode'):
                self.prior_year_mode = data['prior_year_mode']
            if data.get('prior_date_start'):
                self.prior_date_start = fields.Date.to_date(data['prior_date_start'])
            if data.get('prior_date_end'):
                self.prior_date_end = fields.Date.to_date(data['prior_date_end'])
            if data.get('report_type'):
                self.report_type = data['report_type']
            if data.get('auditor_type'):
                self.auditor_type = data['auditor_type']
            if data.get('audit_period_category'):
                self.audit_period_category = data['audit_period_category']
            if data.get('company_id'):
                self.company_id = data['company_id']
        else:
            self.date_start = False
            self.date_end = False
            self.prior_year_mode = 'auto'
            self.prior_date_start = False
            self.prior_date_end = False
            self.report_type = 'period'
            self.auditor_type = 'default'
            self.audit_period_category = 'normal_2y'
            self.company_id = self.env.company

    def _build_office_address(self):
        company = self.company_id
        parts = [
            company.street,
            company.street2,
            company.city,
            company.state_id.name if company.state_id else False,
            company.zip,
            company.country_id.name if company.country_id else False,
        ]
        return ', '.join([part for part in parts if part])

    def _get_report_data(self):
        """Get report data for the template"""
        if self.prior_year_mode == 'manual' and self.prior_date_start and self.prior_date_end:
            prior_date_start = fields.Date.to_date(self.prior_date_start)
            prior_date_end = fields.Date.to_date(self.prior_date_end)
        else:
            prior_date_start = fields.Date.to_date(self.date_start) - relativedelta(years=1)
            prior_date_end = fields.Date.to_date(self.date_end) - relativedelta(years=1)
        prior_prior_date_start = prior_date_start - relativedelta(years=1)
        prior_prior_date_end = prior_date_end - relativedelta(years=1)

        def _fetch_account_rows(date_start=None, date_end=None):
            def _normalize_code(code):
                return ''.join(ch for ch in code if ch.isdigit())

            domain = [
                ('company_id', '=', self.company_id.id),
                ('move_id.state', '=', 'posted'),
            ]
            if date_start:
                domain.append(('date', '>=', date_start))
            if date_end:
                domain.append(('date', '<=', date_end))

            rows = self.env['account.move.line'].read_group(
                domain=domain,
                fields=['debit', 'credit', 'balance'],
                groupby=['account_id']
            )

            account_ids = [row['account_id'][0] for row in rows if row.get('account_id')]
            account_map = {acc.id: acc for acc in self.env['account.account'].browse(account_ids)}

            final_rows = []
            for row in rows:
                if not row.get('account_id'):
                    continue
                account_id = row['account_id'][0]
                account = account_map.get(account_id)
                if not account:
                    continue
                code_raw = (account.code or getattr(account, 'code_store', '') or '').strip()
                code = _normalize_code(code_raw) if code_raw else ''
                final_rows.append({
                    'id': account_id,
                    'code': code,
                    'name': account.name,
                    'type': account.account_type,
                    'debit': row['debit'],
                    'credit': row['credit'],
                    'balance': row['balance'],
                })
            return final_rows

        def _split_accounts(rows):
            balance_sheet_accounts = []
            profit_loss_accounts = []
            for row in rows:
                if row['type'].startswith(('asset', 'liability', 'equity')):
                    balance_sheet_accounts.append(row)
                else:
                    profit_loss_accounts.append(row)
            return balance_sheet_accounts, profit_loss_accounts

        def _sum_sections(rows, mapping):
            totals = {}
            for row in rows:
                section = mapping.get(row['type'], 'Other')
                totals[section] = totals.get(section, 0.0) + row.get('balance', 0.0)
            return totals

        def _normalize_balance(row, balance):
            account_type = row.get('type', '')
            if account_type.startswith(('liability', 'equity')) or account_type.startswith('income'):
                return -balance
            return balance

        def _build_account_head_map(rows, normalizer=None):
            accounts = {}
            for row in rows:
                code = row.get('code') or ''
                if len(code) < 4:
                    continue
                group_code = code[:4]
                balance = row.get('balance', 0.0)
                if normalizer:
                    balance = normalizer(row, balance)
                accounts.setdefault(group_code, {})
                accounts[group_code][code] = {
                    'code': code,
                    'name': row.get('name') or '',
                    'balance': balance,
                }
            return accounts

        def _collect_note_lines(group_codes, current_map, prev_map):
            account_codes = set()
            for group_code in group_codes:
                account_codes.update(current_map.get(group_code, {}).keys())
                account_codes.update(prev_map.get(group_code, {}).keys())

            lines = []
            for account_code in sorted(account_codes):
                group_code = account_code[:4]
                current_info = current_map.get(group_code, {}).get(account_code, {})
                prev_info = prev_map.get(group_code, {}).get(account_code, {})
                current_balance = current_info.get('balance', 0.0)
                prev_balance = prev_info.get('balance', 0.0)
                if not (current_balance or prev_balance):
                    continue
                lines.append({
                    'code': account_code,
                    'name': current_info.get('name') or prev_info.get('name') or '',
                    'current': current_balance,
                    'prev': prev_balance,
                })
            return lines

        def _sum_by_prefix(rows, length, normalizer=None):
            totals = {}
            for row in rows:
                code = row.get('code') or ''
                if len(code) < length:
                    continue
                key = code[:length]
                balance = row.get('balance', 0.0)
                if normalizer:
                    balance = normalizer(row, balance)
                totals[key] = totals.get(key, 0.0) + balance
            return totals

        def _detect_retained_earnings(rows):
            equity_rows = [row for row in rows if row.get('type', '').startswith('equity')]
            if not equity_rows:
                return 0.0

            def _name(row):
                return (row.get('name') or '').lower()

            retained_rows = [row for row in equity_rows if 'retained' in _name(row)]
            if not retained_rows:
                retained_rows = [row for row in equity_rows if 'earning' in _name(row)]
            if not retained_rows:
                exclude = ('share', 'capital')
                retained_rows = [
                    row for row in equity_rows
                    if not any(word in _name(row) for word in exclude)
                ]
            if not retained_rows:
                retained_rows = equity_rows
            retained_total = sum(row.get('balance', 0.0) for row in retained_rows)
            return -retained_total

        # Map account types to readable sections (account-type based)
        BS_MAP = {
            'asset_receivable': 'Receivable',
            'asset_cash': 'Bank and Cash',
            'asset_current': 'Current Assets',
            'asset_non_current': 'Non-Current Assets',
            'asset_prepayments': 'Prepayments',
            'asset_fixed': 'Fixed Assets',
            'liability_payable': 'Payable',
            'liability_credit_card': 'Credit Card',
            'liability_current': 'Current Liabilities',
            'liability_non_current': 'Non-Current Liabilities',
            'equity': 'Equity',
        }

        PL_MAP = {
            'income': 'Revenue',
            'income_other': 'Other Income',
            'expense': 'Operating Expenses',
            'expense_other': 'Other Expenses',
            'expense_depreciation': 'Depreciation',
            'expense_direct_cost': 'Cost of Revenue',
        }

        # Balance sheet (as-of date_end)
        current_bs_rows_all = _fetch_account_rows(date_end=self.date_end)
        current_bs_rows, _unused_pl_rows = _split_accounts(current_bs_rows_all)
        current_bs_totals = _sum_sections(current_bs_rows, BS_MAP)

        # Profit & Loss (period)
        current_pl_rows_all = _fetch_account_rows(self.date_start, self.date_end)
        _unused_bs_rows, current_pl_rows = _split_accounts(current_pl_rows_all)
        current_pl_totals = _sum_sections(current_pl_rows, PL_MAP)

        current_assets = {
            'Bank and Cash': current_bs_totals.get('Bank and Cash', 0.0),
            'Receivable': current_bs_totals.get('Receivable', 0.0),
            'Prepayments': current_bs_totals.get('Prepayments', 0.0),
            'Current Assets': current_bs_totals.get('Current Assets', 0.0),
        }
        non_current_assets = {
            'Fixed Assets': current_bs_totals.get('Fixed Assets', 0.0),
            'Non-Current Assets': current_bs_totals.get('Non-Current Assets', 0.0),
        }
        current_liabilities = {
            'Payable': -(current_bs_totals.get('Payable', 0.0)),
            'Credit Card': -(current_bs_totals.get('Credit Card', 0.0)),
            'Current Liabilities': -(current_bs_totals.get('Current Liabilities', 0.0)),
        }
        non_current_liabilities = {
            'Non-Current Liabilities': -(current_bs_totals.get('Non-Current Liabilities', 0.0)),
        }
        equity = {
            'Equity': -(current_bs_totals.get('Equity', 0.0)),
        }

        current_assets_total = sum(current_assets.values())
        non_current_assets_total = sum(non_current_assets.values())
        total_assets = current_assets_total + non_current_assets_total

        current_liabilities_total = sum(current_liabilities.values())
        non_current_liabilities_total = sum(non_current_liabilities.values())
        total_liabilities = current_liabilities_total + non_current_liabilities_total

        revenue_total = -(current_pl_totals.get('Revenue', 0.0))
        other_income_total = -(current_pl_totals.get('Other Income', 0.0))
        operating_expenses_total = (
            current_pl_totals.get('Operating Expenses', 0.0)
            + current_pl_totals.get('Other Expenses', 0.0)
        )
        depreciation_total = current_pl_totals.get('Depreciation', 0.0)
        cost_of_revenue_total = current_pl_totals.get('Cost of Revenue', 0.0)

        gross_profit = revenue_total - cost_of_revenue_total
        net_profit_before_tax = gross_profit - operating_expenses_total + other_income_total
        tax_amount = 0.0
        net_profit_after_tax = net_profit_before_tax

        if net_profit_before_tax > 375000:
            tax_amount = (net_profit_before_tax - 375000) * 0.09
            net_profit_after_tax = net_profit_before_tax - tax_amount

        def _calc_margin(amount, base):
            if not base:
                return 0.0
            return (amount / base) * 100.0

        gross_profit_margin = _calc_margin(gross_profit, revenue_total)
        net_profit_margin = _calc_margin(net_profit_after_tax, revenue_total)

        # Prior year (balance sheet as-of prior_date_end, P&L period)
        prev_bs_rows_all = _fetch_account_rows(date_end=prior_date_end)
        prev_bs_rows, _unused_prev_pl_rows = _split_accounts(prev_bs_rows_all)
        prev_bs_totals = _sum_sections(prev_bs_rows, BS_MAP)

        prev_pl_rows_all = _fetch_account_rows(prior_date_start, prior_date_end)
        _unused_prev_bs_rows, prev_pl_rows = _split_accounts(prev_pl_rows_all)
        prev_pl_totals = _sum_sections(prev_pl_rows, PL_MAP)

        prev_current_assets = {
            'Bank and Cash': prev_bs_totals.get('Bank and Cash', 0.0),
            'Receivable': prev_bs_totals.get('Receivable', 0.0),
            'Prepayments': prev_bs_totals.get('Prepayments', 0.0),
            'Current Assets': prev_bs_totals.get('Current Assets', 0.0),
        }
        prev_non_current_assets = {
            'Fixed Assets': prev_bs_totals.get('Fixed Assets', 0.0),
            'Non-Current Assets': prev_bs_totals.get('Non-Current Assets', 0.0),
        }
        prev_current_liabilities = {
            'Payable': -(prev_bs_totals.get('Payable', 0.0)),
            'Credit Card': -(prev_bs_totals.get('Credit Card', 0.0)),
            'Current Liabilities': -(prev_bs_totals.get('Current Liabilities', 0.0)),
        }
        prev_non_current_liabilities = {
            'Non-Current Liabilities': -(prev_bs_totals.get('Non-Current Liabilities', 0.0)),
        }
        prev_equity = {
            'Equity': -(prev_bs_totals.get('Equity', 0.0)),
        }

        prev_current_assets_total = sum(prev_current_assets.values())
        prev_non_current_assets_total = sum(prev_non_current_assets.values())
        prev_total_assets = prev_current_assets_total + prev_non_current_assets_total

        prev_current_liabilities_total = sum(prev_current_liabilities.values())
        prev_non_current_liabilities_total = sum(prev_non_current_liabilities.values())
        prev_total_liabilities = prev_current_liabilities_total + prev_non_current_liabilities_total

        prev_revenue_total = -(prev_pl_totals.get('Revenue', 0.0))
        prev_other_income_total = -(prev_pl_totals.get('Other Income', 0.0))
        prev_operating_expenses_total = (
            prev_pl_totals.get('Operating Expenses', 0.0)
            + prev_pl_totals.get('Other Expenses', 0.0)
        )
        prev_depreciation_total = prev_pl_totals.get('Depreciation', 0.0)
        prev_cost_of_revenue_total = prev_pl_totals.get('Cost of Revenue', 0.0)

        prev_gross_profit = prev_revenue_total - prev_cost_of_revenue_total
        prev_net_profit_before_tax = prev_gross_profit - prev_operating_expenses_total + prev_other_income_total
        prev_tax_amount = 0.0
        prev_net_profit_after_tax = prev_net_profit_before_tax

        if prev_net_profit_before_tax > 375000:
            prev_tax_amount = (prev_net_profit_before_tax - 375000) * 0.09
            prev_net_profit_after_tax = prev_net_profit_before_tax - prev_tax_amount

        prev_gross_profit_margin = _calc_margin(prev_gross_profit, prev_revenue_total)
        prev_net_profit_margin = _calc_margin(prev_net_profit_after_tax, prev_revenue_total)

        # Prior-prior year (balance sheet as-of)
        prev_prev_bs_rows_all = _fetch_account_rows(date_end=prior_prior_date_end)
        prev_prev_bs_rows, _unused_prev_prev_pl = _split_accounts(prev_prev_bs_rows_all)
        prev_prev_bs_totals = _sum_sections(prev_prev_bs_rows, BS_MAP)
        prev_prev_current_assets = {
            'Bank and Cash': prev_prev_bs_totals.get('Bank and Cash', 0.0),
            'Receivable': prev_prev_bs_totals.get('Receivable', 0.0),
            'Prepayments': prev_prev_bs_totals.get('Prepayments', 0.0),
            'Current Assets': prev_prev_bs_totals.get('Current Assets', 0.0),
        }
        prev_prev_current_liabilities = {
            'Payable': -(prev_prev_bs_totals.get('Payable', 0.0)),
            'Credit Card': -(prev_prev_bs_totals.get('Credit Card', 0.0)),
            'Current Liabilities': -(prev_prev_bs_totals.get('Current Liabilities', 0.0)),
        }

        ###### Cash Flow (account-type based) ######
        current_depreciation_total = depreciation_total
        prior_depreciation_total = prev_depreciation_total

        operating_cashflow_before_working_capital = net_profit_before_tax + current_depreciation_total
        decrease_increase_due_related_party = 0.0
        decrease_increase_in_trade_receivables = (
            current_assets.get('Receivable', 0.0) - prev_current_assets.get('Receivable', 0.0)
        )
        increase_decrease_trade_other_payables = (
            current_liabilities.get('Payable', 0.0) - prev_current_liabilities.get('Payable', 0.0)
        )
        decrease_in_payable_director = 0.0
        net_cash_generated_from_operations = (
            operating_cashflow_before_working_capital
            + decrease_increase_due_related_party
            + decrease_increase_in_trade_receivables
            + increase_decrease_trade_other_payables
            + decrease_in_payable_director
        )

        current_property = -(non_current_assets.get('Fixed Assets', 0.0))
        current_rou_assets = 0.0
        current_intangilbe = -(non_current_assets.get('Non-Current Assets', 0.0))

        net_cash_used_in_investing_activities = current_property + current_rou_assets + current_intangilbe

        cash_from_financing_activities = 0.0

        net_cash_and_cash_equivalents = (
            net_cash_generated_from_operations
            + net_cash_used_in_investing_activities
            + cash_from_financing_activities
        )
        cash_beginning_year = prev_current_assets.get('Bank and Cash', 0.0)
        cash_end_of_year = current_assets.get('Bank and Cash', 0.0)

        prior_operating_cashflow_before_working_capital = prev_net_profit_before_tax + prior_depreciation_total
        prior_decrease_increase_due_related_party = 0.0
        prior_decrease_increase_in_trade_receivables = (
            prev_current_assets.get('Receivable', 0.0) - prev_prev_current_assets.get('Receivable', 0.0)
        )
        prior_increase_decrease_trade_other_payables = (
            prev_current_liabilities.get('Payable', 0.0) - prev_prev_current_liabilities.get('Payable', 0.0)
        )
        prior_decrease_in_payable_director = 0.0
        prior_net_cash_generated_from_operations = (
            prior_operating_cashflow_before_working_capital
            + prior_decrease_increase_due_related_party
            + prior_decrease_increase_in_trade_receivables
            + prior_increase_decrease_trade_other_payables
            + prior_decrease_in_payable_director
        )

        prior_property = -(prev_non_current_assets.get('Fixed Assets', 0.0))
        prior_rou_assets = 0.0
        prior_intangilbe = -(prev_non_current_assets.get('Non-Current Assets', 0.0))
        prior_net_cash_used_in_investing_activities = prior_property + prior_rou_assets + prior_intangilbe

        prior_cash_from_financing_activities = 0.0
        prior_net_cash_and_cash_equivalents = (
            prior_net_cash_generated_from_operations
            + prior_net_cash_used_in_investing_activities
            + prior_cash_from_financing_activities
        )
        prior_cash_beginning_year = prev_prev_current_assets.get('Bank and Cash', 0.0)
        prior_cash_end_of_year = cash_beginning_year

        # Shareholders
        company = self.company_id
        sh_name_1 = company.shareholder_1
        sh_nat_1 = company.nationality_1
        sh_shares_1 = company.number_of_shares_1
        sh_value_1 = company.share_value_1
        sh_total_1 = company.total_share_1

        sh_name_2 = company.shareholder_2
        sh_nat_2 = company.nationality_2
        sh_shares_2 = company.number_of_shares_2
        sh_value_2 = company.share_value_2
        sh_total_2 = company.total_share_2

        sh_name_3 = company.shareholder_3
        sh_nat_3 = company.nationality_3
        sh_shares_3 = company.number_of_shares_3
        sh_value_3 = company.share_value_3
        sh_total_3 = company.total_share_3

        sh_name_4 = company.shareholder_4
        sh_nat_4 = company.nationality_4
        sh_shares_4 = company.number_of_shares_4
        sh_value_4 = company.share_value_4
        sh_total_4 = company.total_share_4

        sh_name_5 = company.shareholder_5
        sh_nat_5 = company.nationality_5
        sh_shares_5 = company.number_of_shares_5
        sh_value_5 = company.share_value_5
        sh_total_5 = company.total_share_5

        sh_name_6 = company.shareholder_6
        sh_nat_6 = company.nationality_6
        sh_shares_6 = company.number_of_shares_6
        sh_value_6 = company.share_value_6
        sh_total_6 = company.total_share_6

        sh_name_7 = company.shareholder_7
        sh_nat_7 = company.nationality_7
        sh_shares_7 = company.number_of_shares_7
        sh_value_7 = company.share_value_7
        sh_total_7 = company.total_share_7

        sh_name_8 = company.shareholder_8
        sh_nat_8 = company.nationality_8
        sh_shares_8 = company.number_of_shares_8
        sh_value_8 = company.share_value_8
        sh_total_8 = company.total_share_8

        sh_name_9 = company.shareholder_9
        sh_nat_9 = company.nationality_9
        sh_shares_9 = company.number_of_shares_9
        sh_value_9 = company.share_value_9
        sh_total_9 = company.total_share_9

        sh_name_10 = company.shareholder_10
        sh_nat_10 = company.nationality_10
        sh_shares_10 = company.number_of_shares_10
        sh_value_10 = company.share_value_10
        sh_total_10 = company.total_share_10

        # Changes in Equity
        total_shares = (
            sh_total_1 + sh_total_2 + sh_total_3 + sh_total_4 + sh_total_5
            + sh_total_6 + sh_total_7 + sh_total_8 + sh_total_9 + sh_total_10
        )

        retained_earnings_ledger = _detect_retained_earnings(current_bs_rows)
        prev_retained_earnings_ledger = _detect_retained_earnings(prev_bs_rows)

        retained_earnings = net_profit_after_tax
        prev_retained_earnings = prev_net_profit_after_tax

        retained_earnings_balance = retained_earnings_ledger + retained_earnings
        prev_retained_earnings_balance = prev_retained_earnings_ledger + prev_retained_earnings

        equity_total_display = total_shares + retained_earnings_balance
        prev_equity_total_display = total_shares + prev_retained_earnings_balance

        total_equity = equity_total_display
        prev_total_equity = prev_equity_total_display

        total_soce = total_shares + retained_earnings
        prev_total_soce = total_shares + prev_retained_earnings

        total_of_equity_and_liabilities = equity_total_display + total_liabilities
        prev_total_of_equity_and_liabilities = prev_equity_total_display + prev_total_liabilities

        # Notes (account-code based)
        MAIN_HEAD_LABELS = {
            '1101': 'Property Plant And Equipment',
            '1102': 'Right of Use of Assets',
            '1103': 'Capital Work in Progress',
            '1104': 'Long Term Investment',
            '1105': 'Long Term Deposits',
            '1106': 'Long Term Loans Receivable',
            '1107': 'Intangible Assets',
            '1108': 'Long Term Investment',
            '1109': 'Deferred Tax',
            '1201': 'Inventory',
            '1202': 'Trade Receivables',
            '1203': 'Prepayments, Deposits, Advances & Other Receivables',
            '1204': 'Cash And Bank Balances',
            '1205': 'Stripe & Other Wallets',
            '1206': 'Interbank Transfer',
            '2101': 'Long term loan',
            '2102': 'Long Term Loans Payable - Related Parties',
            '2103': 'Deferred Tax',
            '2104': 'Employee Benefits',
            '2201': 'Short Term Borrowings',
            '2202': 'Trade Payables',
            '2203': 'Other Payables',
            '2204': 'Corporate Tax Liability',
            '3101': 'Equity',
            '4101': 'Revenue',
            '4102': 'Revenue - Related Party',
            '4103': 'Other Income',
            '5101': 'Direct Cost',
        }

        current_bs_account_heads = _build_account_head_map(current_bs_rows, _normalize_balance)
        prev_bs_account_heads = _build_account_head_map(prev_bs_rows, _normalize_balance)
        current_pl_account_heads = _build_account_head_map(current_pl_rows, _normalize_balance)
        prev_pl_account_heads = _build_account_head_map(prev_pl_rows, _normalize_balance)

        current_bs_group_totals = _sum_by_prefix(current_bs_rows, 4, _normalize_balance)
        prev_bs_group_totals = _sum_by_prefix(prev_bs_rows, 4, _normalize_balance)
        current_pl_group_totals = _sum_by_prefix(current_pl_rows, 4, _normalize_balance)
        prev_pl_group_totals = _sum_by_prefix(prev_pl_rows, 4, _normalize_balance)

        note_number = 5
        note_numbers = {}
        note_sections = []

        def _add_note(key, label, group_codes, current_total, prev_total, current_map, prev_map):
            nonlocal note_number
            lines = _collect_note_lines(group_codes, current_map, prev_map)
            if not lines:
                return
            note_numbers[key] = note_number
            note_sections.append({
                'number': note_number,
                'label': label,
                'lines': lines,
                'total_current': current_total,
                'total_prev': prev_total,
            })
            note_number += 1

        non_current_codes = ['1101', '1102', '1103', '1104', '1105', '1106', '1107', '1108', '1109']
        current_codes = ['1201', '1202', '1203', '1204', '1205', '1206']
        equity_codes = ['3101']
        non_current_liability_codes = ['2101', '2102', '2103', '2104']
        current_liability_codes = ['2201', '2202', '2203', '2204']

        for code in non_current_codes + current_codes + equity_codes + non_current_liability_codes + current_liability_codes:
            current_total = current_bs_group_totals.get(code, 0.0)
            prev_total = prev_bs_group_totals.get(code, 0.0)
            if not (current_total or prev_total):
                continue
            _add_note(
                code,
                MAIN_HEAD_LABELS.get(code, code),
                [code],
                current_total,
                prev_total,
                current_bs_account_heads,
                prev_bs_account_heads,
            )

        revenue_codes = ['4101', '4102']
        cost_codes = ['5101']
        expense_group_codes = sorted({
            code for code in current_pl_group_totals
            if code.startswith('51')
        } | {
            code for code in prev_pl_group_totals
            if code.startswith('51')
        })
        operating_expense_codes = [code for code in expense_group_codes if code not in set(cost_codes)]

        if revenue_total or prev_revenue_total:
            current_total = sum(current_pl_group_totals.get(code, 0.0) for code in revenue_codes)
            prev_total = sum(prev_pl_group_totals.get(code, 0.0) for code in revenue_codes)
            _add_note(
                'pl_revenue',
                'Revenue',
                revenue_codes,
                current_total,
                prev_total,
                current_pl_account_heads,
                prev_pl_account_heads,
            )
        if cost_of_revenue_total or prev_cost_of_revenue_total:
            current_total = sum(current_pl_group_totals.get(code, 0.0) for code in cost_codes)
            prev_total = sum(prev_pl_group_totals.get(code, 0.0) for code in cost_codes)
            _add_note(
                'pl_cost',
                'Cost of revenue',
                cost_codes,
                current_total,
                prev_total,
                current_pl_account_heads,
                prev_pl_account_heads,
            )
        if operating_expenses_total or prev_operating_expenses_total:
            current_total = sum(current_pl_group_totals.get(code, 0.0) for code in operating_expense_codes)
            prev_total = sum(prev_pl_group_totals.get(code, 0.0) for code in operating_expense_codes)
            _add_note(
                'pl_opex',
                'Operating expenses',
                operating_expense_codes,
                current_total,
                prev_total,
                current_pl_account_heads,
                prev_pl_account_heads,
            )

        return {
            # Balance Sheet
            'balance_rows': current_bs_rows,
            'profit_loss_accounts': current_pl_rows,
            'total_assets': total_assets,
            'total_liabilities': total_liabilities,
            'total_equity': equity_total_display,
            'current_assets': current_assets,
            'current_liabilities': current_liabilities,
            'equity': equity,
            'non_current_assets': non_current_assets,
            'non_current_liabilities': non_current_liabilities,
            'current_liabilities_total': current_liabilities_total,
            'non_current_liabilities_total': non_current_liabilities_total,
            'current_assets_total': current_assets_total,
            'non_current_assets_total': non_current_assets_total,
            'total_of_equity_and_liabilities': total_of_equity_and_liabilities,
            'prev_current_assets': prev_current_assets,
            'prev_non_current_assets': prev_non_current_assets,
            'prev_current_liabilities': prev_current_liabilities,
            'prev_non_current_liabilities': prev_non_current_liabilities,
            'prev_current_assets_total': prev_current_assets_total,
            'prev_non_current_assets_total': prev_non_current_assets_total,
            'prev_total_assets': prev_total_assets,
            'prev_current_liabilities_total': prev_current_liabilities_total,
            'prev_non_current_liabilities_total': prev_non_current_liabilities_total,
            'prev_total_liabilities': prev_total_liabilities,
            'prev_total_equity': prev_equity_total_display,
            'prev_total_of_equity_and_liabilities': prev_total_of_equity_and_liabilities,

            # PnL
            'cost_of_revenue_total': cost_of_revenue_total,
            'depreciation_total': depreciation_total,
            'operating_expenses_total': operating_expenses_total,
            'revenue_total': revenue_total,
            'gross_profit': gross_profit,
            'net_profit_before_tax': net_profit_before_tax,
            'net_profit_after_tax': net_profit_after_tax,
            'gross_profit_margin': gross_profit_margin,
            'net_profit_margin': net_profit_margin,
            'tax_amount': tax_amount,
            'prev_revenue_total': prev_revenue_total,
            'prev_cost_of_revenue_total': prev_cost_of_revenue_total,
            'prev_gross_profit': prev_gross_profit,
            'prev_operating_expenses_total': prev_operating_expenses_total,
            'prev_net_profit_before_tax': prev_net_profit_before_tax,
            'prev_tax_amount': prev_tax_amount,
            'prev_net_profit_after_tax': prev_net_profit_after_tax,
            'prev_gross_profit_margin': prev_gross_profit_margin,
            'prev_net_profit_margin': prev_net_profit_margin,

            # Statement of Changes in Equity
            'retained_earnings': retained_earnings,
            'total_soce': total_soce,
            'prev_retained_earnings': prev_retained_earnings,
            'prev_total_soce': prev_total_soce,
            'share_capital_total': total_shares,
            'prev_share_capital_total': total_shares,
            'retained_earnings_balance': retained_earnings_balance,
            'prev_retained_earnings_balance': prev_retained_earnings_balance,
            'equity_total_display': equity_total_display,
            'prev_equity_total_display': prev_equity_total_display,

            # Shareholders
            'sh_name_1': sh_name_1,
            'sh_nat_1': sh_nat_1,
            'sh_shares_1': sh_shares_1,
            'sh_value_1': sh_value_1,
            'sh_total_1': sh_total_1,
            'sh_name_2': sh_name_2,
            'sh_nat_2': sh_nat_2,
            'sh_shares_2': sh_shares_2,
            'sh_value_2': sh_value_2,
            'sh_total_2': sh_total_2,
            'sh_name_3': sh_name_3,
            'sh_nat_3': sh_nat_3,
            'sh_shares_3': sh_shares_3,
            'sh_value_3': sh_value_3,
            'sh_total_3': sh_total_3,

            # Cash flow
            'current_depreciation_total': current_depreciation_total,
            'prior_depreciation_total': prior_depreciation_total,
            'operating_cashflow_before_working_capital': operating_cashflow_before_working_capital,
            'decrease_increase_due_related_party': decrease_increase_due_related_party,
            'decrease_increase_in_trade_receivables': decrease_increase_in_trade_receivables,
            'increase_decrease_trade_other_payables': increase_decrease_trade_other_payables,
            'decrease_in_payable_director': decrease_in_payable_director,
            'net_cash_generated_from_operations': net_cash_generated_from_operations,
            'current_property': current_property,
            'current_rou_assets': current_rou_assets,
            'current_intangilbe': current_intangilbe,
            'net_cash_used_in_investing_activities': net_cash_used_in_investing_activities,
            'cash_from_financing_activities': cash_from_financing_activities,
            'net_cash_and_cash_equivalents': net_cash_and_cash_equivalents,
            'cash_beginning_year': cash_beginning_year,
            'cash_end_of_year': cash_end_of_year,
            'prior_operating_cashflow_before_working_capital': prior_operating_cashflow_before_working_capital,
            'prior_decrease_increase_due_related_party': prior_decrease_increase_due_related_party,
            'prior_decrease_increase_in_trade_receivables': prior_decrease_increase_in_trade_receivables,
            'prior_increase_decrease_trade_other_payables': prior_increase_decrease_trade_other_payables,
            'prior_decrease_in_payable_director': prior_decrease_in_payable_director,
            'prior_net_cash_generated_from_operations': prior_net_cash_generated_from_operations,
            'prior_property': prior_property,
            'prior_rou_assets': prior_rou_assets,
            'prior_intangilbe': prior_intangilbe,
            'prior_net_cash_used_in_investing_activities': prior_net_cash_used_in_investing_activities,
            'prior_cash_from_financing_activities': prior_cash_from_financing_activities,
            'prior_net_cash_and_cash_equivalents': prior_net_cash_and_cash_equivalents,
            'prior_cash_beginning_year': prior_cash_beginning_year,
            'prior_cash_end_of_year': prior_cash_end_of_year,

            # Notes
            'note_numbers': note_numbers,
            'note_sections': note_sections,
            'current_group_totals': current_bs_group_totals,
            'prev_group_totals': prev_bs_group_totals,
            'main_head_labels': MAIN_HEAD_LABELS,

            # Company info for template
            'office_address': self._build_office_address(),
            'trade_license_no': company.company_license_number or '',
        }

    def action_print_account_report_lines(self):
        """Generate and display report"""
        self.ensure_one()

        if self.use_previous_settings:
            self._store_previous_settings()

        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/view/{self.id}',
            'target': 'new',
        }

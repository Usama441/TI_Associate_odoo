import base64
import hashlib
import json
import os
from lxml import etree, html

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError


REPORT_TYPE_SELECTION = [
    ('period', 'Financial Statements for the Period Ended'),
    ('year', 'Financial Statements for the Year Ended'),
    ('management', 'Management Accounts for the Period Ended'),
]

AUDIT_PERIOD_CATEGORY_SELECTION = [
    ('cessation_2y', '2 Years Cessation'),
    ('cessation_1y', '1 Year Cessation'),
    ('normal_1y', '1 Year Normal'),
    ('normal_2y', '2 Years Normal'),
    ('dormant_1y', '1 Year Dormant'),
    ('dormant_2y', '2 Years Dormant'),
]


class AuditReportDocument(models.Model):
    _name = 'audit.report.document'
    _description = 'Saved Audit Report Document'
    _order = 'id desc'

    name = fields.Char(required=True)
    company_id = fields.Many2one(
        'res.company',
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    date_start = fields.Date()
    date_end = fields.Date()
    report_type = fields.Selection(REPORT_TYPE_SELECTION)
    audit_period_category = fields.Selection(AUDIT_PERIOD_CATEGORY_SELECTION)
    source_wizard_json = fields.Text()
    active = fields.Boolean(default=True)

    revision_ids = fields.One2many(
        'audit.report.revision',
        'document_id',
        string='Revisions',
    )
    current_revision_id = fields.Many2one(
        'audit.report.revision',
        string='Current Revision',
        readonly=True,
        copy=False,
    )
    revision_count = fields.Integer(
        compute='_compute_revision_count',
        string='Revision Count',
    )

    @api.model
    def _register_hook(self):
        """Keep rule domains in sync even if old records were loaded as noupdate."""
        result = super()._register_hook()
        domain = "[('company_id', 'in', user.company_ids.ids)]"
        xmlids = [
            'Audit_Report.audit_report_document_active_company_rule',
            'Audit_Report.audit_report_revision_active_company_rule',
        ]
        for xmlid in xmlids:
            rule = self.env.ref(xmlid, raise_if_not_found=False)
            if rule:
                rule.sudo().write({
                    'domain_force': domain,
                    'active': True,
                })
        return result

    @api.depends('revision_ids')
    def _compute_revision_count(self):
        for record in self:
            record.revision_count = len(record.revision_ids)

    def action_open_revisions(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Report Revisions'),
            'res_model': 'audit.report.revision',
            'view_mode': 'list,form',
            'domain': [('document_id', '=', self.id)],
            'context': {
                'default_document_id': self.id,
                'default_company_id': self.company_id.id,
                'search_default_active_only': 1,
            },
        }

    def action_open_print_wizard(self):
        self.ensure_one()
        self._ensure_active_company()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Print Saved Revision'),
            'res_model': 'audit.report.print.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_document_id': self.id,
                'default_company_id': self.company_id.id,
            },
        }

    def action_open_current_preview(self):
        self.ensure_one()
        self._ensure_active_company()
        if not self.current_revision_id:
            raise ValidationError(_('No active revision available for preview.'))
        return self.current_revision_id.action_open_preview()

    def _ensure_active_company(self):
        self.ensure_one()
        user_company_ids = self.env.user.company_ids.ids
        if self.company_id.id not in user_company_ids:
            raise ValidationError(_('This report belongs to a company not allowed for your user.'))

    def _next_revision_number(self):
        self.ensure_one()
        last = self.env['audit.report.revision'].search(
            [('document_id', '=', self.id)],
            order='version_no desc',
            limit=1,
        )
        return (last.version_no or 0) + 1

    def create_revision_from_html(self, html_content, parent_revision=False):
        self.ensure_one()
        html_content = html_content or ''
        if not html_content.strip():
            raise ValidationError(_('Cannot create a revision without HTML content.'))

        revision = self.env['audit.report.revision'].create({
            'document_id': self.id,
            'company_id': self.company_id.id,
            'version_no': self._next_revision_number(),
            'parent_revision_id': parent_revision.id if parent_revision else False,
            'html_content': html_content,
        })
        self.current_revision_id = revision.id
        return revision


class AuditReportRevision(models.Model):
    _name = 'audit.report.revision'
    _description = 'Audit Report Revision'
    _order = 'version_no desc, id desc'
    _rec_name = 'display_name'

    display_name = fields.Char(compute='_compute_display_name', store=True)
    document_id = fields.Many2one(
        'audit.report.document',
        required=True,
        ondelete='cascade',
        index=True,
    )
    company_id = fields.Many2one(
        'res.company',
        required=True,
        index=True,
    )
    version_no = fields.Integer(required=True)
    parent_revision_id = fields.Many2one(
        'audit.report.revision',
        ondelete='set null',
    )
    created_by_id = fields.Many2one(
        'res.users',
        default=lambda self: self.env.user,
        readonly=True,
    )
    created_on = fields.Datetime(
        default=fields.Datetime.now,
        readonly=True,
    )

    html_content = fields.Text(required=True)
    table_index_json = fields.Text(readonly=True)
    pdf_attachment_id = fields.Many2one('ir.attachment', ondelete='set null', copy=False)
    pdf_hash = fields.Char(copy=False)
    pdf_generated_on = fields.Datetime(copy=False)

    is_removed = fields.Boolean(default=False, index=True)
    removed_by_id = fields.Many2one('res.users', readonly=True)
    removed_on = fields.Datetime(readonly=True)

    is_current = fields.Boolean(compute='_compute_is_current', string='Current')

    @api.depends('document_id.name', 'version_no')
    def _compute_display_name(self):
        for record in self:
            base = record.document_id.name or _('Saved Audit Report')
            record.display_name = f"{base} - v{record.version_no}"

    @api.depends('document_id.current_revision_id')
    def _compute_is_current(self):
        for record in self:
            record.is_current = record.document_id.current_revision_id == record

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('document_id') and not vals.get('company_id'):
                vals['company_id'] = self.env['audit.report.document'].browse(vals['document_id']).company_id.id
            if vals.get('document_id') and not vals.get('version_no'):
                document = self.env['audit.report.document'].browse(vals['document_id'])
                vals['version_no'] = document._next_revision_number()
            if vals.get('html_content') and not vals.get('table_index_json'):
                vals['table_index_json'] = self._serialize_table_index(
                    self._extract_table_index(vals['html_content'])
                )
        records = super().create(vals_list)
        for record in records:
            if record.document_id.current_revision_id != record:
                record.document_id.current_revision_id = record.id
        return records

    def write(self, vals):
        if 'html_content' in vals and 'table_index_json' not in vals:
            for record in self:
                update_vals = dict(vals)
                update_vals['table_index_json'] = self._serialize_table_index(
                    self._extract_table_index(update_vals.get('html_content') or '')
                )
                update_vals['pdf_hash'] = False
                update_vals['pdf_generated_on'] = False
                update_vals['pdf_attachment_id'] = False
                super(AuditReportRevision, record).write(update_vals)
            return True
        return super().write(vals)

    def action_open_preview(self):
        self.ensure_one()
        self._ensure_active_company()
        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/revision/{self.id}/preview',
            'target': 'new',
        }

    def action_open_pdf(self):
        self.ensure_one()
        self._ensure_active_company()
        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/revision/{self.id}/pdf',
            'target': 'new',
        }

    def action_open_structured_editor(self):
        self.ensure_one()
        self._ensure_active_company()
        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/revision/{self.id}/edit/structured',
            'target': 'new',
        }

    def action_open_freeform_editor(self):
        self.ensure_one()
        self._ensure_active_company()
        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/revision/{self.id}/edit/freeform',
            'target': 'new',
        }

    def action_soft_remove(self):
        now = fields.Datetime.now()
        for record in self:
            record._ensure_active_company()
            if record.is_removed:
                continue
            record.write({
                'is_removed': True,
                'removed_by_id': self.env.user.id,
                'removed_on': now,
            })
        self.mapped('document_id')._refresh_current_revision()
        return True

    def action_restore(self):
        for record in self:
            record._ensure_active_company()
            if not record.is_removed:
                continue
            record.write({
                'is_removed': False,
                'removed_by_id': False,
                'removed_on': False,
            })
        self.mapped('document_id')._refresh_current_revision()
        return True

    def _ensure_active_company(self):
        self.ensure_one()
        user_company_ids = self.env.user.company_ids.ids
        if self.company_id.id not in user_company_ids:
            raise ValidationError(_('This revision belongs to a company not allowed for your user.'))

    @api.model
    def _serialize_table_index(self, table_index):
        return json.dumps(table_index or [], ensure_ascii=False)

    @api.model
    def _parse_html(self, html_content):
        raw = html_content or '<!doctype html><html><body></body></html>'
        parser = html.HTMLParser(encoding='utf-8', recover=True)
        try:
            return html.fromstring(raw, parser=parser)
        except Exception:
            return html.fromstring('<!doctype html><html><body></body></html>', parser=parser)

    @api.model
    def _iter_tables(self, root):
        section_counter = {}
        for global_index, table in enumerate(root.xpath('//table'), start=1):
            section_name = 'document'
            parent = table
            while parent is not None:
                tag_name = getattr(parent, 'tag', '')
                if isinstance(tag_name, str) and tag_name.lower() == 'section':
                    classes = (parent.get('class') or '').split()
                    section_name = classes[0] if classes else 'section'
                    break
                parent = parent.getparent()

            section_index = section_counter.get(section_name, 0) + 1
            section_counter[section_name] = section_index
            table_key = f'{section_name}:{section_index}'
            yield global_index, table_key, section_name, section_index, table

    @api.model
    def _direct_rows(self, table):
        rows = table.xpath('./thead/tr|./tbody/tr|./tfoot/tr|./tr')
        return rows or table.xpath('.//tr')

    @api.model
    def _extract_table_index(self, html_content):
        root = self._parse_html(html_content)
        table_index = []
        for global_index, table_key, section_name, section_index, table in self._iter_tables(root):
            rows = self._direct_rows(table)
            row_count = len(rows)
            col_count = 0
            preview = ''

            for row in rows:
                cells = row.xpath('./th|./td')
                col_span_count = 0
                cell_texts = []
                for cell in cells:
                    span_raw = cell.get('colspan') or '1'
                    try:
                        col_span_count += max(int(span_raw), 1)
                    except ValueError:
                        col_span_count += 1
                    text_value = ' '.join(cell.itertext()).strip()
                    if text_value:
                        cell_texts.append(text_value)
                col_count = max(col_count, col_span_count)
                if not preview and cell_texts:
                    preview = ' | '.join(cell_texts[:3])[:160]

            table_index.append({
                'key': table_key,
                'section': section_name,
                'table_index': section_index,
                'global_index': global_index,
                'rows': row_count,
                'cols': col_count,
                'preview': preview,
            })

        return table_index

    def get_table_index(self):
        self.ensure_one()
        if not self.table_index_json:
            return []
        try:
            parsed = json.loads(self.table_index_json)
            return parsed if isinstance(parsed, list) else []
        except (TypeError, ValueError):
            return []

    def _find_table(self, root, table_key):
        for _global_index, key, _section_name, _section_index, table in self._iter_tables(root):
            if key == table_key:
                return table
        return None

    def get_table_payload(self, table_key):
        self.ensure_one()
        root = self._parse_html(self.html_content)
        table = self._find_table(root, table_key)
        if table is None:
            return None

        row_data = []
        for row_index, row in enumerate(self._direct_rows(table)):
            cell_values = []
            for col_index, cell in enumerate(row.xpath('./th|./td')):
                value = ' '.join(cell.itertext()).strip()
                cell_values.append({
                    'r': row_index,
                    'c': col_index,
                    'name': f'cell_{row_index}_{col_index}',
                    'value': value,
                    'tag': (cell.tag or '').lower(),
                })
            row_data.append(cell_values)

        return {
            'table_key': table_key,
            'rows': row_data,
        }

    def apply_structured_table_changes(self, table_key, posted_cells, table_action='save', target_row=0, target_col=0):
        self.ensure_one()
        root = self._parse_html(self.html_content)
        table = self._find_table(root, table_key)
        if table is None:
            raise ValidationError(_('The selected table no longer exists in this revision.'))

        for row_index, row in enumerate(self._direct_rows(table)):
            cells = row.xpath('./th|./td')
            for col_index, cell in enumerate(cells):
                field_name = f'cell_{row_index}_{col_index}'
                if field_name not in posted_cells:
                    continue

                new_value = posted_cells.get(field_name, '')
                if len(cell):
                    first_child = cell[0]
                    first_child.text = new_value
                    for extra_child in list(cell)[1:]:
                        cell.remove(extra_child)
                    cell.text = None
                else:
                    cell.text = new_value

        rows = self._direct_rows(table)
        row_count = len(rows)
        col_count = max((len(row.xpath('./th|./td')) for row in rows), default=0)

        def _safe_int(value, default=0):
            try:
                return int(value or default)
            except (TypeError, ValueError):
                return default

        table_action = (table_action or 'save').strip().lower()
        target_row = _safe_int(target_row, row_count)
        target_col = _safe_int(target_col, col_count)

        if table_action == 'add_row_after':
            if not rows:
                parent = table.xpath('./tbody')[0] if table.xpath('./tbody') else table
                new_row = etree.Element('tr')
                new_cell = etree.Element('td')
                new_cell.text = ''
                new_row.append(new_cell)
                parent.append(new_row)
            else:
                target_row = min(max(target_row, 1), row_count)
                anchor_row = rows[target_row - 1]
                anchor_cells = anchor_row.xpath('./th|./td')
                new_col_count = max(len(anchor_cells), col_count, 1)
                cell_tag = (anchor_cells[0].tag if anchor_cells else 'td') or 'td'

                new_row = etree.Element('tr')
                for _ in range(new_col_count):
                    new_cell = etree.Element(cell_tag)
                    new_cell.text = ''
                    new_row.append(new_cell)

                parent = anchor_row.getparent()
                parent.insert(parent.index(anchor_row) + 1, new_row)

        elif table_action == 'remove_row':
            if row_count > 1:
                target_row = min(max(target_row, 1), row_count)
                target = rows[target_row - 1]
                parent = target.getparent()
                parent.remove(target)

        elif table_action == 'add_col_after':
            if not rows:
                new_row = etree.Element('tr')
                new_cell = etree.Element('td')
                new_cell.text = ''
                new_row.append(new_cell)
                table.append(new_row)
            else:
                if col_count <= 0:
                    col_count = 1
                target_col = min(max(target_col, 1), col_count)
                for row in rows:
                    cells = row.xpath('./th|./td')
                    if not cells:
                        new_cell = etree.Element('td')
                        new_cell.text = ''
                        row.append(new_cell)
                        continue
                    anchor_index = min(max(target_col - 1, 0), len(cells) - 1)
                    anchor_cell = cells[anchor_index]
                    new_cell = etree.Element((anchor_cell.tag or 'td'))
                    new_cell.text = ''
                    row.insert(row.index(anchor_cell) + 1, new_cell)

        elif table_action == 'remove_col':
            if col_count > 1:
                target_col = min(max(target_col, 1), col_count)
                for row in rows:
                    cells = row.xpath('./th|./td')
                    if len(cells) <= 1:
                        continue
                    idx = min(target_col - 1, len(cells) - 1)
                    row.remove(cells[idx])

        rendered_html = etree.tostring(root, encoding='unicode', method='html')
        return self._sanitize_html_for_storage(rendered_html)

    @api.model
    def _sanitize_html_for_storage(self, html_content):
        root = self._parse_html(html_content)

        for node in root.xpath('//script'):
            parent = node.getparent()
            if parent is not None:
                parent.remove(node)

        for element in root.iter():
            for attr_name in list(element.attrib):
                attr_lower = attr_name.lower()
                attr_value = element.attrib.get(attr_name) or ''
                if attr_lower.startswith('on'):
                    del element.attrib[attr_name]
                elif attr_lower in ('href', 'src') and str(attr_value).strip().lower().startswith('javascript:'):
                    element.attrib[attr_name] = ''

        return etree.tostring(root, encoding='unicode', method='html')

    def create_next_revision(self, html_content):
        self.ensure_one()
        self._ensure_active_company()
        sanitized_html = self._sanitize_html_for_storage(html_content)
        return self.document_id.create_revision_from_html(
            sanitized_html,
            parent_revision=self,
        )

    def _compute_html_hash(self):
        self.ensure_one()
        return hashlib.sha256((self.html_content or '').encode('utf-8')).hexdigest()

    def _get_pdf_content(self):
        self.ensure_one()
        self._ensure_active_company()

        html_hash = self._compute_html_hash()
        if self.pdf_attachment_id and self.pdf_hash == html_hash:
            datas = self.pdf_attachment_id.datas
            if datas:
                return base64.b64decode(datas)

        module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        from ..controllers.main import AuditReportController

        controller = AuditReportController()
        pdf_content = controller._html_to_pdf(self.html_content or '', base_url=module_path)
        datas = base64.b64encode(pdf_content)

        filename = f"Audit_Report_{self.document_id.id}_v{self.version_no}.pdf"
        attachment_vals = {
            'name': filename,
            'datas': datas,
            'res_model': 'audit.report.revision',
            'res_id': self.id,
            'mimetype': 'application/pdf',
            'type': 'binary',
            'company_id': self.company_id.id,
        }

        attachment = self.pdf_attachment_id.sudo()
        if attachment:
            attachment.write(attachment_vals)
        else:
            attachment = self.env['ir.attachment'].sudo().create(attachment_vals)

        self.write({
            'pdf_attachment_id': attachment.id,
            'pdf_hash': html_hash,
            'pdf_generated_on': fields.Datetime.now(),
        })
        return pdf_content


class AuditReportPrintWizard(models.TransientModel):
    _name = 'audit.report.print.wizard'
    _description = 'Print Saved Audit Report Revision'

    company_id = fields.Many2one(
        'res.company',
        required=True,
        default=lambda self: self.env.company,
        readonly=True,
    )
    document_id = fields.Many2one(
        'audit.report.document',
        required=True,
        domain="[('company_id', '=', company_id)]",
    )
    revision_id = fields.Many2one(
        'audit.report.revision',
        required=True,
        domain="[('company_id', '=', company_id), ('document_id', '=', document_id), ('is_removed', '=', False)]",
    )

    @api.model
    def default_get(self, fields_list):
        values = super().default_get(fields_list)
        document_id = values.get('document_id') or self.env.context.get('default_document_id')
        if document_id:
            document = self.env['audit.report.document'].browse(document_id)
            if document and document.company_id == self.env.company and document.current_revision_id:
                values.setdefault('revision_id', document.current_revision_id.id)
        return values

    @api.onchange('document_id')
    def _onchange_document_id(self):
        if not self.document_id:
            self.revision_id = False
            return
        user_company_ids = self.env.user.company_ids.ids
        if self.document_id.company_id.id not in user_company_ids:
            self.document_id = False
            self.revision_id = False
            return
        current = self.document_id.current_revision_id
        self.revision_id = current if current and not current.is_removed else False

    def action_print_revision(self):
        self.ensure_one()
        user_company_ids = self.env.user.company_ids.ids
        if self.document_id.company_id.id not in user_company_ids:
            raise ValidationError(_('You can only print reports from companies allowed for your user.'))
        if self.revision_id.company_id.id not in user_company_ids:
            raise ValidationError(_('You can only print revisions from companies allowed for your user.'))
        if self.revision_id.is_removed:
            raise ValidationError(_('Removed revisions cannot be printed. Please restore the revision first.'))
        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/revision/{self.revision_id.id}/pdf',
            'target': 'new',
        }


class AuditReportDocumentExtension(models.Model):
    _inherit = 'audit.report.document'

    def _refresh_current_revision(self):
        for document in self:
            candidates = document.revision_ids.filtered(lambda rev: not rev.is_removed).sorted(
                key=lambda rev: (rev.version_no, rev.id),
                reverse=True,
            )
            document.current_revision_id = candidates[0].id if candidates else False

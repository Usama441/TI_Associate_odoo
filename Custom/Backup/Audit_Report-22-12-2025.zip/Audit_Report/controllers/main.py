from odoo import http
from odoo.http import request
from jinja2 import Environment, FileSystemLoader
import os


class AuditReportController(http.Controller):
    def _render_report_html(self, report):
        company = report.company_id
        if not report.exists():
            return None

        module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        templates_path = os.path.join(module_path, 'templates')
        env = Environment(loader=FileSystemLoader(templates_path))
        default_format = env.filters.get('format')

        def format_filter(fmt, *args, **kwargs):
            if fmt == "%.2f" and args:
                value = args[0] or 0.0
                try:
                    number = float(value)
                except (TypeError, ValueError):
                    return default_format(fmt, *args, **kwargs) if default_format else fmt % args
                if number < 0:
                    return f"({abs(number):.2f})"
                return f"{number:.2f}"
            return default_format(fmt, *args, **kwargs) if default_format else fmt % args

        env.filters['format'] = format_filter
        template = env.get_template('audit_report_template.html')

        data = report._get_report_data()
        context = {
            'company': company,
            'company_name': getattr(company, 'name', ''),
            'freezone': getattr(company, 'free_zone', ''),
            'license': getattr(company, 'company_license_number', ''),
            'owner': getattr(company, 'owner', ''),
            'date_start': report.date_start,
            'date_end': report.date_end,
            'auditor_name': report._get_auditor_name(),
        }
        context.update(data)

        html_content = template.render(**context)
        css_path = os.path.join(templates_path, 'audit_report_style.css')
        with open(css_path, 'r') as f:
            css_content = f.read()

        return html_content.replace('</head>', f'<style>{css_content}</style></head>')
    
    @http.route('/audit_report/view/<int:report_id>', type='http', auth='user')
    def view_report(self, report_id, **kwargs):
        report = request.env['audit.report'].browse(report_id)
        html_with_style = self._render_report_html(report)
        if not html_with_style:
            return request.not_found()
        
        return request.make_response(
            html_with_style,
            headers=[
                ('Content-Type', 'text/html; charset=utf-8'),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ]
        )

    @http.route('/audit_report/pdf/<int:report_id>', type='http', auth='user')
    def view_report_pdf(self, report_id, **kwargs):
        report = request.env['audit.report'].browse(report_id)
        html_with_style = self._render_report_html(report)
        if not html_with_style:
            return request.not_found()

        pdf_content = request.env['ir.actions.report']._run_wkhtmltopdf([html_with_style])
        filename = f'Audit_Report_{report.id}.pdf'
        return request.make_response(
            pdf_content,
            headers=[
                ('Content-Type', 'application/pdf'),
                ('Content-Disposition', f'inline; filename="{filename}"'),
                ('Content-Length', str(len(pdf_content))),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ]
        )

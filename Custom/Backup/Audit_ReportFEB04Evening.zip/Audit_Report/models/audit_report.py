import csv
import json
import os
from dateutil.relativedelta import relativedelta
from odoo import models, fields, api


class AuditReport(models.TransientModel):
    _name = 'audit.report'
    _description = 'Audit Report'

    date_start = fields.Date(string='Date Start', required=True)
    date_end = fields.Date(string='Date End', required=True)
    balance_sheet_date_mode = fields.Selection(
        [
            ('end_only', 'End date only (snapshot)'),
            ('range', 'Date range (start to end)'),
        ],
        string='Balance Sheet Dates',
        required=True,
        default='end_only',
    )
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company,
    )
    company_name = fields.Char(related='company_id.name', readonly=False)
    company_street = fields.Char(related='company_id.street', readonly=False)
    company_street2 = fields.Char(related='company_id.street2', readonly=False)
    company_city = fields.Char(related='company_id.city', readonly=False)
    company_state_id = fields.Many2one(related='company_id.state_id', readonly=False)
    company_zip = fields.Char(related='company_id.zip', readonly=False)
    company_country_id = fields.Many2one(related='company_id.country_id', readonly=False)
    company_free_zone = fields.Char(related='company_id.free_zone', readonly=False)
    company_license_number = fields.Char(related='company_id.company_license_number', readonly=False)
    trade_license_activities = fields.Text(related='company_id.trade_license_activities', readonly=False)
    incorporation_date = fields.Date(related='company_id.incorporation_date', readonly=False)
    corporate_tax_registration_number = fields.Char(
        related='company_id.corporate_tax_registration_number',
        readonly=False,
    )
    vat_registration_number = fields.Char(
        related='company_id.vat_registration_number',
        readonly=False,
    )
    corporate_tax_start_date = fields.Date(
        related='company_id.corporate_tax_start_date',
        readonly=False,
    )
    corporate_tax_end_date = fields.Date(
        related='company_id.corporate_tax_end_date',
        readonly=False,
    )
    implementing_regulations_freezone = fields.Text(
        related='company_id.implementing_regulations_freezone',
        readonly=False,
    )
    shareholder_1 = fields.Char(related='company_id.shareholder_1', readonly=False)
    shareholder_2 = fields.Char(related='company_id.shareholder_2', readonly=False)
    shareholder_3 = fields.Char(related='company_id.shareholder_3', readonly=False)
    shareholder_4 = fields.Char(related='company_id.shareholder_4', readonly=False)
    shareholder_5 = fields.Char(related='company_id.shareholder_5', readonly=False)
    shareholder_6 = fields.Char(related='company_id.shareholder_6', readonly=False)
    shareholder_7 = fields.Char(related='company_id.shareholder_7', readonly=False)
    shareholder_8 = fields.Char(related='company_id.shareholder_8', readonly=False)
    shareholder_9 = fields.Char(related='company_id.shareholder_9', readonly=False)
    shareholder_10 = fields.Char(related='company_id.shareholder_10', readonly=False)

    nationality_1 = fields.Char(related='company_id.nationality_1', readonly=False)
    nationality_2 = fields.Char(related='company_id.nationality_2', readonly=False)
    nationality_3 = fields.Char(related='company_id.nationality_3', readonly=False)
    nationality_4 = fields.Char(related='company_id.nationality_4', readonly=False)
    nationality_5 = fields.Char(related='company_id.nationality_5', readonly=False)
    nationality_6 = fields.Char(related='company_id.nationality_6', readonly=False)
    nationality_7 = fields.Char(related='company_id.nationality_7', readonly=False)
    nationality_8 = fields.Char(related='company_id.nationality_8', readonly=False)
    nationality_9 = fields.Char(related='company_id.nationality_9', readonly=False)
    nationality_10 = fields.Char(related='company_id.nationality_10', readonly=False)

    number_of_shares_1 = fields.Integer(related='company_id.number_of_shares_1', readonly=False)
    number_of_shares_2 = fields.Integer(related='company_id.number_of_shares_2', readonly=False)
    number_of_shares_3 = fields.Integer(related='company_id.number_of_shares_3', readonly=False)
    number_of_shares_4 = fields.Integer(related='company_id.number_of_shares_4', readonly=False)
    number_of_shares_5 = fields.Integer(related='company_id.number_of_shares_5', readonly=False)
    number_of_shares_6 = fields.Integer(related='company_id.number_of_shares_6', readonly=False)
    number_of_shares_7 = fields.Integer(related='company_id.number_of_shares_7', readonly=False)
    number_of_shares_8 = fields.Integer(related='company_id.number_of_shares_8', readonly=False)
    number_of_shares_9 = fields.Integer(related='company_id.number_of_shares_9', readonly=False)
    number_of_shares_10 = fields.Integer(related='company_id.number_of_shares_10', readonly=False)

    share_value_1 = fields.Float(related='company_id.share_value_1', readonly=False)
    share_value_2 = fields.Float(related='company_id.share_value_2', readonly=False)
    share_value_3 = fields.Float(related='company_id.share_value_3', readonly=False)
    share_value_4 = fields.Float(related='company_id.share_value_4', readonly=False)
    share_value_5 = fields.Float(related='company_id.share_value_5', readonly=False)
    share_value_6 = fields.Float(related='company_id.share_value_6', readonly=False)
    share_value_7 = fields.Float(related='company_id.share_value_7', readonly=False)
    share_value_8 = fields.Float(related='company_id.share_value_8', readonly=False)
    share_value_9 = fields.Float(related='company_id.share_value_9', readonly=False)
    share_value_10 = fields.Float(related='company_id.share_value_10', readonly=False)

    total_share_1 = fields.Float(related='company_id.total_share_1', readonly=True)
    total_share_2 = fields.Float(related='company_id.total_share_2', readonly=True)
    total_share_3 = fields.Float(related='company_id.total_share_3', readonly=True)
    total_share_4 = fields.Float(related='company_id.total_share_4', readonly=True)
    total_share_5 = fields.Float(related='company_id.total_share_5', readonly=True)
    total_share_6 = fields.Float(related='company_id.total_share_6', readonly=True)
    total_share_7 = fields.Float(related='company_id.total_share_7', readonly=True)
    total_share_8 = fields.Float(related='company_id.total_share_8', readonly=True)
    total_share_9 = fields.Float(related='company_id.total_share_9', readonly=True)
    total_share_10 = fields.Float(related='company_id.total_share_10', readonly=True)
    auditor_type = fields.Selection(
        [
            ('default', 'Default'),
            ('ifza', 'IFZA'),
            ('dmcc', 'DMCC'),
        ],
        string='Freezone City',
        required=True,
        default='default',
    )
    report_type = fields.Selection(
        [
            ('period', 'Financial Statements for the Period Ended'),
            ('year', 'Financial Statements for the Year Ended'),
            ('management', 'Management Accounts for the Period Ended'),
        ],
        string='Report Type',
        required=True,
        default='period',
    )
    use_previous_settings = fields.Boolean(
        string='Use Previous Settings',
        default=True,
    )
    audit_period_category = fields.Selection(
        [
            ('cessation_2y', '2 Years Cessation'),
            ('cessation_1y', '1 Year Cessation'),
            ('normal_1y', '1 Year Normal'),
            ('normal_2y', '2 Years Normal'),
            ('dormant_1y', '1 Year Dormant'),
            ('dormant_2y', '2 Years Dormant'),
        ],
        string='Audit Period Category',
        default='normal_2y',
    )
    prior_year_mode = fields.Selection(
        [
            ('auto', 'Auto (1 year back)'),
            ('manual', 'Manual selection'),
        ],
        string='Prior Year Dates',
        required=True,
        default='auto',
    )
    prior_date_start = fields.Date(string='Prior Date Start')
    prior_date_end = fields.Date(string='Prior Date End')

    def _previous_settings_key(self):
        return (
            f'audit_report_wizard.prev_settings.user_{self.env.user.id}.'
            f'company_{self.env.company.id}'
        )

    def _get_previous_settings(self):
        param = self.env['ir.config_parameter'].sudo()
        raw = param.get_param(self._previous_settings_key(), default='')
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except (TypeError, ValueError):
            return {}

    def _store_previous_settings(self):
        data = {
            'date_start': self.date_start.isoformat() if self.date_start else False,
            'date_end': self.date_end.isoformat() if self.date_end else False,
            'balance_sheet_date_mode': self.balance_sheet_date_mode,
            'prior_year_mode': self.prior_year_mode,
            'prior_date_start': self.prior_date_start.isoformat() if self.prior_date_start else False,
            'prior_date_end': self.prior_date_end.isoformat() if self.prior_date_end else False,
            'report_type': self.report_type,
            'auditor_type': self.auditor_type,
            'audit_period_category': self.audit_period_category,
        }
        self.env['ir.config_parameter'].sudo().set_param(
            self._previous_settings_key(),
            json.dumps(data),
        )

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        if not res.get('use_previous_settings', True):
            return res
        data = self._get_previous_settings()
        if not data:
            return res
        if 'date_start' in fields_list and data.get('date_start'):
            res['date_start'] = fields.Date.to_date(data['date_start'])
        if 'date_end' in fields_list and data.get('date_end'):
            res['date_end'] = fields.Date.to_date(data['date_end'])
        if 'balance_sheet_date_mode' in fields_list and data.get('balance_sheet_date_mode'):
            res['balance_sheet_date_mode'] = data['balance_sheet_date_mode']
        if 'prior_year_mode' in fields_list and data.get('prior_year_mode'):
            res['prior_year_mode'] = data['prior_year_mode']
        if 'prior_date_start' in fields_list and data.get('prior_date_start'):
            res['prior_date_start'] = fields.Date.to_date(data['prior_date_start'])
        if 'prior_date_end' in fields_list and data.get('prior_date_end'):
            res['prior_date_end'] = fields.Date.to_date(data['prior_date_end'])
        if 'report_type' in fields_list and data.get('report_type'):
            res['report_type'] = data['report_type']
        if 'auditor_type' in fields_list and data.get('auditor_type'):
            res['auditor_type'] = data['auditor_type']
        if 'audit_period_category' in fields_list and data.get('audit_period_category'):
            res['audit_period_category'] = data['audit_period_category']
        return res

    @api.onchange('use_previous_settings')
    def _onchange_use_previous_settings(self):
        if self.use_previous_settings:
            data = self._get_previous_settings()
            if data.get('date_start'):
                self.date_start = fields.Date.to_date(data['date_start'])
            if data.get('date_end'):
                self.date_end = fields.Date.to_date(data['date_end'])
            if data.get('balance_sheet_date_mode'):
                self.balance_sheet_date_mode = data['balance_sheet_date_mode']
            if data.get('prior_year_mode'):
                self.prior_year_mode = data['prior_year_mode']
            if data.get('prior_date_start'):
                self.prior_date_start = fields.Date.to_date(data['prior_date_start'])
            if data.get('prior_date_end'):
                self.prior_date_end = fields.Date.to_date(data['prior_date_end'])
            if data.get('report_type'):
                self.report_type = data['report_type']
            if data.get('auditor_type'):
                self.auditor_type = data['auditor_type']
            if data.get('audit_period_category'):
                self.audit_period_category = data['audit_period_category']
        else:
            self.date_start = False
            self.date_end = False
            self.balance_sheet_date_mode = 'end_only'
            self.prior_year_mode = 'auto'
            self.prior_date_start = False
            self.prior_date_end = False
            self.report_type = 'period'
            self.auditor_type = 'default'
            self.audit_period_category = 'normal_2y'
            self.company_id = self.env.company

    @api.onchange(
        'company_street',
        'company_free_zone',
        'company_license_number',
        'trade_license_activities',
        'incorporation_date',
        'corporate_tax_registration_number',
        'vat_registration_number',
        'corporate_tax_start_date',
        'corporate_tax_end_date',
        'implementing_regulations_freezone',
        'shareholder_1',
        'shareholder_2',
        'shareholder_3',
        'shareholder_4',
        'shareholder_5',
        'shareholder_6',
        'shareholder_7',
        'shareholder_8',
        'shareholder_9',
        'shareholder_10',
        'nationality_1',
        'nationality_2',
        'nationality_3',
        'nationality_4',
        'nationality_5',
        'nationality_6',
        'nationality_7',
        'nationality_8',
        'nationality_9',
        'nationality_10',
        'number_of_shares_1',
        'number_of_shares_2',
        'number_of_shares_3',
        'number_of_shares_4',
        'number_of_shares_5',
        'number_of_shares_6',
        'number_of_shares_7',
        'number_of_shares_8',
        'number_of_shares_9',
        'number_of_shares_10',
        'share_value_1',
        'share_value_2',
        'share_value_3',
        'share_value_4',
        'share_value_5',
        'share_value_6',
        'share_value_7',
        'share_value_8',
        'share_value_9',
        'share_value_10',
    )
    def _onchange_sync_company_info(self):
        if not self.company_id:
            return
        vals = {
            'street': self.company_street or False,
            'free_zone': self.company_free_zone or False,
            'company_license_number': self.company_license_number or False,
            'trade_license_activities': self.trade_license_activities or False,
            'incorporation_date': self.incorporation_date or False,
            'corporate_tax_registration_number': self.corporate_tax_registration_number or False,
            'vat_registration_number': self.vat_registration_number or False,
            'corporate_tax_start_date': self.corporate_tax_start_date or False,
            'corporate_tax_end_date': self.corporate_tax_end_date or False,
            'implementing_regulations_freezone': self.implementing_regulations_freezone or False,
            'shareholder_1': self.shareholder_1 or False,
            'shareholder_2': self.shareholder_2 or False,
            'shareholder_3': self.shareholder_3 or False,
            'shareholder_4': self.shareholder_4 or False,
            'shareholder_5': self.shareholder_5 or False,
            'shareholder_6': self.shareholder_6 or False,
            'shareholder_7': self.shareholder_7 or False,
            'shareholder_8': self.shareholder_8 or False,
            'shareholder_9': self.shareholder_9 or False,
            'shareholder_10': self.shareholder_10 or False,
            'nationality_1': self.nationality_1 or False,
            'nationality_2': self.nationality_2 or False,
            'nationality_3': self.nationality_3 or False,
            'nationality_4': self.nationality_4 or False,
            'nationality_5': self.nationality_5 or False,
            'nationality_6': self.nationality_6 or False,
            'nationality_7': self.nationality_7 or False,
            'nationality_8': self.nationality_8 or False,
            'nationality_9': self.nationality_9 or False,
            'nationality_10': self.nationality_10 or False,
            'number_of_shares_1': self.number_of_shares_1 or 0,
            'number_of_shares_2': self.number_of_shares_2 or 0,
            'number_of_shares_3': self.number_of_shares_3 or 0,
            'number_of_shares_4': self.number_of_shares_4 or 0,
            'number_of_shares_5': self.number_of_shares_5 or 0,
            'number_of_shares_6': self.number_of_shares_6 or 0,
            'number_of_shares_7': self.number_of_shares_7 or 0,
            'number_of_shares_8': self.number_of_shares_8 or 0,
            'number_of_shares_9': self.number_of_shares_9 or 0,
            'number_of_shares_10': self.number_of_shares_10 or 0,
            'share_value_1': self.share_value_1 or 0.0,
            'share_value_2': self.share_value_2 or 0.0,
            'share_value_3': self.share_value_3 or 0.0,
            'share_value_4': self.share_value_4 or 0.0,
            'share_value_5': self.share_value_5 or 0.0,
            'share_value_6': self.share_value_6 or 0.0,
            'share_value_7': self.share_value_7 or 0.0,
            'share_value_8': self.share_value_8 or 0.0,
            'share_value_9': self.share_value_9 or 0.0,
            'share_value_10': self.share_value_10 or 0.0,
        }
        self.company_id.write(vals)

    def _get_report_data(self):
        """Get report data for the template"""
        date_start = fields.Date.to_date(self.date_start)
        date_end = fields.Date.to_date(self.date_end)
        period_category = (self.audit_period_category or '').lower()
        show_prior_year = not period_category.endswith('_1y')
        if self.prior_year_mode == 'manual' and self.prior_date_start and self.prior_date_end:
            prior_date_start = fields.Date.to_date(self.prior_date_start)
            prior_date_end = fields.Date.to_date(self.prior_date_end)
        else:
            prior_date_start = date_start - relativedelta(years=1)
            prior_date_end = date_end - relativedelta(years=1)
        prior_prior_date_start = prior_date_start - relativedelta(years=1)
        prior_prior_date_end = prior_date_end - relativedelta(years=1)


        def _fetch_account_rows(date_start, date_end):
            def _normalize_code(code):
                return ''.join(ch for ch in code if ch.isdigit())

            if not date_end:
                return []
            domain = [
                ('date', '<=', date_end),
                ('company_id', '=', self.company_id.id),
                ('move_id.state', '=', 'posted'),
            ]
            if date_start:
                domain.insert(0, ('date', '>=', date_start))
            move_line_env = self.env['account.move.line'].with_context(
                allowed_company_ids=[self.company_id.id]
            )
            rows = move_line_env.read_group(
                domain=domain,
                fields=['debit', 'credit', 'balance'],
                groupby=['account_id']
            )

            account_ids = [row['account_id'][0] for row in rows if row.get('account_id')]
            account_env = self.env['account.account'].with_company(self.company_id).with_context(
                allowed_company_ids=[self.company_id.id]
            )
            account_map = {acc.id: acc for acc in account_env.browse(account_ids)}


            final_rows = []
            for row in rows:
                if not row.get('account_id'):
                    continue
                account_id = row['account_id'][0]
                account = account_map.get(account_id)
                if not account:
                    continue
                code_raw = (account.code or account.code_store or '').strip()
                if not code_raw:
                    continue
                code = _normalize_code(code_raw)
                if not code:
                    continue
                final_rows.append({
                    'id': account_id,
                    'code': code,
                    'code_raw': code_raw,
                    'name': account.name,
                    'type': account.account_type,
                    'debit': row['debit'],
                    'credit': row['credit'],
                    'balance': row['balance'],
                })
          
            return final_rows


        balance_sheet_date_start = date_start if self.balance_sheet_date_mode == 'range' else False
        prior_balance_sheet_date_start = (
            prior_date_start if self.balance_sheet_date_mode == 'range' else False
        )
        prior_prior_balance_sheet_date_start = (
            prior_prior_date_start if self.balance_sheet_date_mode == 'range' else False
        )

        def _sum_by_prefix(rows, length):
            totals = {}
            for row in rows:
                code = row.get('code') or ''
                if len(code) < length:
                    continue
                key = code[:length]
                totals[key] = totals.get(key, 0.0) + row.get('balance', 0.0)
            return totals


        def _build_section_totals(group_totals, mapping):
            totals = {}
            for label, codes in mapping.items():
                total = 0.0
                for code in codes:
                    total += group_totals.get(code, 0.0)
                totals[label] = total
            return totals

        def _build_group_label_map(mappings):
            labels = {}
            for mapping in mappings:
                for label, codes in mapping.items():
                    for code in codes:
                        labels[code] = label
            return labels

        def _annotate_rows(rows, group_labels):
            annotated = []
            for row in rows:
                code = row.get('code', '')
                group_code = code[:4] if len(code) >= 4 else ''
                data = dict(row)
                data['group_code'] = group_code
                data['sub_group_code'] = code[:6] if len(code) >= 6 else ''
                data['two_digit_code'] = code[:2] if len(code) >= 2 else ''
                data['one_digit_code'] = code[:1] if len(code) >= 1 else ''
                data['section'] = group_labels.get(group_code, 'Other')
                annotated.append(data)
            return annotated

        def _build_subhead_groups(prefix_totals, subhead_labels):
            grouped = {}
            for code in sorted(prefix_totals):
                name = subhead_labels.get(code)
                if not name:
                    continue
                group_code = code[:4]
                grouped.setdefault(group_code, []).append({
                    'code': code,
                    'name': name,
                    'balance': prefix_totals[code],
                })
            return grouped

        def _build_account_head_map(rows):
            accounts = {}
            for row in rows:
                code = row.get('code') or ''
                if len(code) < 8:
                    continue
                group_code = code[:4]
                accounts.setdefault(group_code, {})
                accounts[group_code][code] = {
                    'code': code,
                    'name': row.get('name') or '',
                    'balance': row.get('balance', 0.0),
                }
            return accounts

        def _account_head_balance(account_heads, account_code):
            group_code = account_code[:4]
            return account_heads.get(group_code, {}).get(account_code, {}).get('balance', 0.0)

        def _equity_head_balance(account_heads, account_code):
            # Equity accounts are credit-balanced in Odoo (negative); invert for display.
            return -_account_head_balance(account_heads, account_code)

        def _collect_note_lines(group_codes, current_map, prev_map):
            if len(group_codes) == 1 and group_codes[0] == '1204':
                cash_prefix = '120401'
                bank_prefix = '120402'

                def _sum_prefix(prefix, account_map):
                    total = 0.0
                    for code, info in account_map.get('1204', {}).items():
                        if code.startswith(prefix):
                            total += info.get('balance', 0.0)
                    return total

                current_bank = _sum_prefix(bank_prefix, current_map)
                prev_bank = _sum_prefix(bank_prefix, prev_map)
                current_cash = _sum_prefix(cash_prefix, current_map)
                prev_cash = _sum_prefix(cash_prefix, prev_map)

                lines = []
                if current_bank or prev_bank:
                    lines.append({
                        'code': bank_prefix,
                        'name': 'Cash in bank',
                        'current': current_bank,
                        'prev': prev_bank,
                    })
                if current_cash or prev_cash:
                    lines.append({
                        'code': cash_prefix,
                        'name': 'Cash in hand',
                        'current': current_cash,
                        'prev': prev_cash,
                    })
                if lines:
                    return lines

            account_codes = set()
            for group_code in group_codes:
                account_codes.update(current_map.get(group_code, {}).keys())
                account_codes.update(prev_map.get(group_code, {}).keys())

            lines = []
            for account_code in sorted(account_codes):
                group_code = account_code[:4]
                current_info = current_map.get(group_code, {}).get(account_code, {})
                prev_info = prev_map.get(group_code, {}).get(account_code, {})
                current_balance = current_info.get('balance', 0.0)
                prev_balance = prev_info.get('balance', 0.0)
                if not (current_balance or prev_balance):
                    continue
                lines.append({
                    'code': account_code,
                    'name': current_info.get('name') or prev_info.get('name') or '',
                    'current': current_balance,
                    'prev': prev_balance,
                })
            return lines

        def _label_group_totals(group_totals, labels):
            totals = {}
            for code, label in labels.items():
                totals[label] = totals.get(label, 0.0) + group_totals.get(code, 0.0)
            return totals

        NON_CURRENT_ASSET_GROUPS = {
            'Property and equipment': ['1101'],
            'Right of use of assets': ['1102'],
            'Capital work in progress': ['1103'],
            'Long term investment': ['1104', '1108'],
            'Long term deposits': ['1105'],
            'Long term loans receivable': ['1106'],
            'Intangible assets': ['1107'],
            'Deferred tax': ['1109'],
        }
        CURRENT_ASSET_GROUPS = {
            'Inventory': ['1201'],
            'Accounts receivable': ['1202'],
            'Prepayment, deposits, advances and other receivables': ['1203'],
            'Cash and bank balances': ['1204'],
            'Stripe and other wallets': ['1205'],
            'Interbank transfer': ['1206'],
        }
        NON_CURRENT_LIABILITY_GROUPS = {
            'Long term loan': ['2101'],
            'Long term loans payable - related parties': ['2102'],
            'Deferred tax': ['2103'],
            'Employee benefits': ['2104'],
        }
        CURRENT_LIABILITY_GROUPS = {
            'Short term borrowings': ['2201'],
            'Trade payables': ['2202'],
            'Other payables': ['2203'],
            'Corporate tax liability': ['2204'],
        }
        EQUITY_GROUPS = {
            'Equity': ['3101'],
        }
        REVENUE_GROUPS = {
            'Revenue': ['4101', '4102'],
        }
        OTHER_INCOME_GROUPS = {
            'Other income': ['4103'],
        }
        COST_OF_REVENUE_GROUPS = {
            'Cost of revenue': ['5101'],
        }
        DEPRECIATION_GROUPS = {
            'Depreciation': ['5114'],
        }

        MAIN_HEAD_LABELS = {
            '1101': 'Property Plant And Equipment',
            '1102': 'Right of Use of Assets',
            '1103': 'Capital Work in Progress',
            '1104': 'Long Term Investment',
            '1105': 'Long Term Deposits',
            '1106': 'Long Term Loans Receivable',
            '1107': 'Intangible Assets',
            '1108': 'Long Term Investment',
            '1109': 'Deferred Tax',
            '1201': 'Inventory',
            '1202': 'Account Receivables',
            '1203': 'Prepayments, Deposits, Advances & Other Receivables',
            '1204': 'Cash And Bank Balances',
            '1205': 'Stripe & Other Wallets',
            '1206': 'Interbank Transfer',
            '2101': 'Long term loan',
            '2102': 'Long Term Loans Payable - Related Parties',
            '2103': 'Deferred Tax',
            '2104': 'Employee Benefits',
            '2201': 'Short Term Borrowings',
            '2202': 'Trade Payables',
            '2203': 'Other Payables',
            '2204': 'Corporate Tax Liability',
            '3101': 'Equity',
            '4101': 'Revenue',
            '4102': 'Revenue - Related Party',
            '4103': 'Other Income',
            '5101': 'Direct Cost',
            '5102': 'Marketing & Advertisement Expenses',
            '5103': 'IT Expenses',
            '5104': 'Telephone & Internet',
            '5105': 'Professional Fee & Consultancy',
            '5106': 'Legal & Government Fee',
            '5107': "Director's Salary",
            '5108': 'Salaries & Wages',
            '5109': 'Audit & Accounting Expense',
            '5110': 'Rent Expense',
            '5111': 'Utilities',
            '5112': 'Printing & Stationary Expense',
            '5113': 'Travel & Accommodation Expense',
            '5114': 'Depreciation & Amortization',
            '5115': 'Courier Expenses',
            '5116': 'Commission Expense',
            '5117': 'Cleaning Expense',
            '5118': 'Repair & Maintenance',
            '5119': 'Other expenses',
            '5120': 'Penalties & Fines',
            '5121': 'Donation & Charity',
            '5122': 'Other expenses',
            '5123': 'Bank Charges',
            '5124': 'Finance Cost',
            '5125': 'Insurance Expense',
            '5126': 'Fees & Subscriptions',
            '5127': 'Tax expense',
            '5128': 'Office Expense',
        }

        SUBHEAD_LABELS = {
            '110101': 'Land & Buildings',
            '110102': 'Furnitures & Fixtures',
            '110103': 'Leasehold Improvements',
            '110104': 'Vehicles',
            '110105': 'IT Equipments',
            '110106': 'Office Equipments',
            '110201': 'ROU Property',
            '110202': 'ROU Vehicles',
            '110203': 'ROU Equipment',
            '110204': 'ROU Property',
            '110205': 'ROU Vehicles',
            '110206': 'ROU Equipment',
            '110301': 'Capital Work in Progress',
            '110401': 'Investments in funds',
            '110501': 'Long Term Deposits',
            '110601': 'Related Parties',
            '110701': 'Software & Licences',
            '110702': 'Website & Blogs',
            '110703': 'Other Intangible Assets',
            '110801': 'Group Investments',
            '110901': 'Deferred Tax',
            '120101': 'Inventory',
            '120201': 'Trade Receivables',
            '120202': 'Retention Receivables',
            '120301': 'Advances',
            '120302': 'Prepaid Expenses',
            '120303': 'Other Receivables',
            '120304': 'VAT Receivable',
            '120401': 'Cash',
            '120402': 'Bank Accounts',
            '120501': 'Payment Gateways',
            '120502': 'Other Wallet',
            '120601': 'Interbank Transfer',
            '210101': 'Bank Loans',
            '210102': 'Related Party Loan',
            '210103': 'Lease Liabilities',
            '210201': 'Long Term Loans Payable - Related Parties',
            '210301': 'Deferred Tax',
            '210401': 'End of Service Benefits',
            '220101': 'Bank Overdraft',
            '220102': 'Short term loan',
            '220103': 'Credit Card Payable',
            '220104': 'Lease Liability',
            '220201': 'Trade Payables',
            '220301': 'Other Payables',
            '220302': 'VAT Payable',
            '220303': 'Accrued Expenses',
            '220401': 'Corporate Tax Liability',
            '310101': 'Share Capital',
            '310102': 'Retained Earnings',
            '310103': 'Reserves',
            '310104': 'Fund Balances',
            '410101': 'Revenue',
            '410201': 'Revenue - Related Party',
            '410301': 'Interest income',
            '410302': 'Dividend income',
            '410303': 'Rental Income',
            '410304': 'Miscellaneous Income',
            '410305': 'Foreign Exchange Gain',
            '410306': 'Fair Value Gains',
            '410307': 'Endowment Income',
            '410308': 'Donations',
            '410309': 'Grants',
            '410310': 'Write Back',
            '510101': 'Cost of Sales',
            '510102': 'Cost of Goods',
            '510103': 'Cost of Sales',
            '510104': 'Event Fee',
            '510201': 'Marketing & Advertisement Expenses',
            '510301': 'IT & Software Expenses',
            '510401': 'Telephone & Internet',
            '510501': 'Professional Fee & Consultancy',
            '510601': 'Legal & Government Fee',
            '510701': "Director's Salary",
            '510801': 'Office Staff Salaries',
            '510802': 'Coaching Staff Salaries',
            '510803': 'Employee Benefits & Allowances',
            '510804': 'Bonus & Incentives',
            '510805': 'Staff Welfare',
            '510901': 'Audit Fee',
            '510902': 'Accounting & Bookkeeping Fee',
            '511001': 'Office Rent',
            '511002': 'Miscellaneous Rent',
            '511101': 'Office Utilities',
            '511201': 'Printing Cost',
            '511202': 'Stationary',
            '511301': 'Travel & Accommodation Expense',
            '511302': 'Local Accommodation Expense',
            '511401': 'Depreciation Expense',
            '511402': 'Amortization Expense',
            '511501': 'Courier Expenses',
            '511601': 'Commission Expense',
            '511701': 'Cleaning Expense',
            '511801': 'Repair & Maintenance',
            '511901': 'Other Expenses',
            '512001': 'Penalties & Fines',
            '512101': 'Donation & Charity',
            '512201': 'Other Expenses',
            '512202': 'Charitable Activities',
            '512301': 'Bank Charges & Fees',
            '512401': 'Interest Expense',
            '512501': 'Business Insurance',
            '512601': 'Trade License',
            '512602': 'Establishment Card',
            '512603': 'Visa Fee',
            '512701': 'Corporate Tax Expense',
            '512801': 'Office Expense',
        }

        group_labels = _build_group_label_map([
            NON_CURRENT_ASSET_GROUPS,
            CURRENT_ASSET_GROUPS,
            NON_CURRENT_LIABILITY_GROUPS,
            CURRENT_LIABILITY_GROUPS,
            EQUITY_GROUPS,
            REVENUE_GROUPS,
            OTHER_INCOME_GROUPS,
            COST_OF_REVENUE_GROUPS,
            DEPRECIATION_GROUPS,
        ])

        # Current year balances (as of date_end)
        current_rows = _fetch_account_rows(balance_sheet_date_start, date_end)
        current_account_heads = _build_account_head_map(current_rows)
        current_prefix_totals = {
            1: _sum_by_prefix(current_rows, 1),
            2: _sum_by_prefix(current_rows, 2),
            4: _sum_by_prefix(current_rows, 4),
            6: _sum_by_prefix(current_rows, 6),
            8: _sum_by_prefix(current_rows, 8),
        }
        current_group_totals = current_prefix_totals[4]
        current_main_heads = _label_group_totals(current_group_totals, MAIN_HEAD_LABELS)
        current_subheads_by_group = _build_subhead_groups(
            current_prefix_totals[6],
            SUBHEAD_LABELS,
        )
        current_ppe_subheads = {
            row['name']: row['balance']
            for row in current_subheads_by_group.get('1101', [])
        }
        current_ppe_total = sum(current_ppe_subheads.values())

        annotated_rows = _annotate_rows(current_rows, group_labels)
        balance_rows = [row for row in annotated_rows if row['one_digit_code'] in ('1', '2', '3')]
        period_rows = _fetch_account_rows(date_start, date_end)
        period_account_heads = _build_account_head_map(period_rows)
        period_prefix_totals = {
            1: _sum_by_prefix(period_rows, 1),
            2: _sum_by_prefix(period_rows, 2),
            4: _sum_by_prefix(period_rows, 4),
            6: _sum_by_prefix(period_rows, 6),
            8: _sum_by_prefix(period_rows, 8),
        }
        period_group_totals = period_prefix_totals[4]
        period_annotated_rows = _annotate_rows(period_rows, group_labels)
        profit_loss_accounts = [
            row for row in period_annotated_rows
            if row['one_digit_code'] in ('4', '5')
        ]



        current_assets = _build_section_totals(current_group_totals, CURRENT_ASSET_GROUPS)
        non_current_assets = _build_section_totals(current_group_totals, NON_CURRENT_ASSET_GROUPS)
        current_liabilities = _build_section_totals(current_group_totals, CURRENT_LIABILITY_GROUPS)
        non_current_liabilities = _build_section_totals(current_group_totals, NON_CURRENT_LIABILITY_GROUPS)
        equity = _build_section_totals(current_group_totals, EQUITY_GROUPS)

        current_assets_total = sum(current_assets.values())
        non_current_assets_total = sum(non_current_assets.values())
        total_assets = current_assets_total + non_current_assets_total


        current_liabilities_total = sum(current_liabilities.values())
        non_current_liabilities_total = sum(non_current_liabilities.values())
        total_liabilities = -(current_liabilities_total + non_current_liabilities_total)

        total_equity = sum(equity.values())
        total_of_equity_and_liabilities = total_equity + total_liabilities

        # PnL (current year)
        revenue_total = sum(
            period_group_totals.get(code, 0.0)
            for code in REVENUE_GROUPS['Revenue']
        )
        revenue_total = -(revenue_total)
        other_income_total = sum(
            period_group_totals.get(code, 0.0)
            for code in OTHER_INCOME_GROUPS['Other income']
        )
        other_income_total = -(other_income_total)
        cost_of_revenue_total = sum(
            period_group_totals.get(code, 0.0)
            for code in COST_OF_REVENUE_GROUPS['Cost of revenue']
        )
        depreciation_total = sum(
            period_group_totals.get(code, 0.0)
            for code in DEPRECIATION_GROUPS['Depreciation']
        )
        expense_total = period_prefix_totals[2].get('51', 0.0)
        tax_expense_ledger = period_group_totals.get('5127', 0.0)
        operating_expenses_total = expense_total - cost_of_revenue_total - tax_expense_ledger

        gross_profit = revenue_total - cost_of_revenue_total
        net_profit_before_tax = gross_profit - operating_expenses_total + other_income_total
        tax_amount = 0.0
        net_profit_after_tax = net_profit_before_tax

        if net_profit_before_tax > 375000:
            tax_amount = (net_profit_before_tax - 375000) * 0.09
            net_profit_after_tax = net_profit_before_tax - tax_amount

        if tax_amount:
            current_group_totals = dict(current_group_totals)
            current_group_totals['2204'] = current_group_totals.get('2204', 0.0) - tax_amount
            current_liabilities = _build_section_totals(current_group_totals, CURRENT_LIABILITY_GROUPS)
            current_liabilities_total = sum(current_liabilities.values())
            total_liabilities = -(current_liabilities_total + non_current_liabilities_total)

        def _calc_margin(amount, base):
            if not base:
                return 0.0
            return (amount / base) * 100.0

        def _net_label(current, prev, suffix):
            if (current or 0.0) < 0 or (prev or 0.0) < 0:
                return f"Net profit/(loss) for the year {suffix}"
            return f"Net profit for the year {suffix}"

        gross_profit_margin = _calc_margin(gross_profit, revenue_total)
        net_profit_margin = _calc_margin(net_profit_after_tax, revenue_total)

        # Prior year balances (as of prior_date_end)
        prev_rows = _fetch_account_rows(prior_balance_sheet_date_start, prior_date_end)
        prev_account_heads = _build_account_head_map(prev_rows)
        prev_prefix_totals = {
            1: _sum_by_prefix(prev_rows, 1),
            2: _sum_by_prefix(prev_rows, 2),
            4: _sum_by_prefix(prev_rows, 4),
            6: _sum_by_prefix(prev_rows, 6),
            8: _sum_by_prefix(prev_rows, 8),
        }
        prev_group_totals = prev_prefix_totals[4]

        def _sum_prefix_group(prefix_totals, prefixes):
            return sum(prefix_totals.get(code, 0.0) for code in prefixes)

        def _sum_other_receivables(prefix_totals):
            return sum(
                value
                for code, value in prefix_totals.items()
                if code.startswith('1203') and code not in ('120301', '120302')
            )

        def _has_amount(*values):
            return any(abs(value) > 0.0 for value in values)

        advances_current = _sum_prefix_group(current_prefix_totals[6], ['120301'])
        advances_prev = _sum_prefix_group(prev_prefix_totals[6], ['120301'])
        prepaid_current = _sum_prefix_group(current_prefix_totals[6], ['120302'])
        prepaid_prev = _sum_prefix_group(prev_prefix_totals[6], ['120302'])
        other_receivables_current = _sum_other_receivables(current_prefix_totals[6])
        other_receivables_prev = _sum_other_receivables(prev_prefix_totals[6])

        receivable_parts = []
        if _has_amount(prepaid_current, prepaid_prev):
            receivable_parts.append('Prepayments')
        if _has_amount(advances_current, advances_prev):
            receivable_parts.append('Advances')
        if _has_amount(other_receivables_current, other_receivables_prev):
            receivable_parts.append('Other receivables')

        receivable_label = None
        if receivable_parts:
            if len(receivable_parts) == 1:
                receivable_label = receivable_parts[0]
            elif len(receivable_parts) == 2:
                receivable_label = f"{receivable_parts[0]} and {receivable_parts[1]}"
            else:
                receivable_label = f"{receivable_parts[0]}, {receivable_parts[1]} and {receivable_parts[2]}"
            MAIN_HEAD_LABELS['1203'] = receivable_label

        prev_prev_rows = _fetch_account_rows(prior_prior_balance_sheet_date_start, prior_prior_date_end)
        prev_prev_account_heads = _build_account_head_map(prev_prev_rows)
        prev_prev_prefix_totals = {
            1: _sum_by_prefix(prev_prev_rows, 1),
            2: _sum_by_prefix(prev_prev_rows, 2),
            4: _sum_by_prefix(prev_prev_rows, 4),
            6: _sum_by_prefix(prev_prev_rows, 6),
            8: _sum_by_prefix(prev_prev_rows, 8),
        }
        prev_prev_group_totals = prev_prev_prefix_totals[4]
        prev_period_rows = _fetch_account_rows(prior_date_start, prior_date_end)
        prev_period_account_heads = _build_account_head_map(prev_period_rows)
        prev_period_prefix_totals = {
            1: _sum_by_prefix(prev_period_rows, 1),
            2: _sum_by_prefix(prev_period_rows, 2),
            4: _sum_by_prefix(prev_period_rows, 4),
            6: _sum_by_prefix(prev_period_rows, 6),
            8: _sum_by_prefix(prev_period_rows, 8),
        }
        prev_period_group_totals = prev_period_prefix_totals[4]
        prev_prev_period_rows = _fetch_account_rows(prior_prior_date_start, prior_prior_date_end)
        prev_prev_period_account_heads = _build_account_head_map(prev_prev_period_rows)
        prev_prev_period_prefix_totals = {
            1: _sum_by_prefix(prev_prev_period_rows, 1),
            2: _sum_by_prefix(prev_prev_period_rows, 2),
            4: _sum_by_prefix(prev_prev_period_rows, 4),
            6: _sum_by_prefix(prev_prev_period_rows, 6),
            8: _sum_by_prefix(prev_prev_period_rows, 8),
        }
        prev_prev_period_group_totals = prev_prev_period_prefix_totals[4]
        prev_main_heads = _label_group_totals(prev_group_totals, MAIN_HEAD_LABELS)
        prev_subheads_by_group = _build_subhead_groups(
            prev_prefix_totals[6],
            SUBHEAD_LABELS,
        )
        prev_ppe_subheads = {
            row['name']: row['balance']
            for row in prev_subheads_by_group.get('1101', [])
        }
        prev_ppe_total = sum(prev_ppe_subheads.values())

        prev_current_assets = _build_section_totals(prev_group_totals, CURRENT_ASSET_GROUPS)
        prev_non_current_assets = _build_section_totals(prev_group_totals, NON_CURRENT_ASSET_GROUPS)
        prev_current_liabilities = _build_section_totals(prev_group_totals, CURRENT_LIABILITY_GROUPS)
        prev_non_current_liabilities = _build_section_totals(prev_group_totals, NON_CURRENT_LIABILITY_GROUPS)
        prev_equity = _build_section_totals(prev_group_totals, EQUITY_GROUPS)
        prev_prev_current_assets = _build_section_totals(prev_prev_group_totals, CURRENT_ASSET_GROUPS)

        prev_current_assets_total = sum(prev_current_assets.values())
        prev_non_current_assets_total = sum(prev_non_current_assets.values())
        prev_total_assets = prev_current_assets_total + prev_non_current_assets_total

        prev_current_liabilities_total = sum(prev_current_liabilities.values())
        prev_non_current_liabilities_total = sum(prev_non_current_liabilities.values())
        prev_total_liabilities = -(prev_current_liabilities_total + prev_non_current_liabilities_total)

        prev_equity_total = sum(prev_equity.values())
        prev_total_equity = prev_equity_total
        prev_total_of_equity_and_liabilities = prev_total_equity + prev_total_liabilities

        prev_revenue_total = sum(
            prev_period_group_totals.get(code, 0.0)
            for code in REVENUE_GROUPS['Revenue']
        )
        prev_revenue_total = -(prev_revenue_total)
        prev_other_income_total = sum(
            prev_period_group_totals.get(code, 0.0)
            for code in OTHER_INCOME_GROUPS['Other income']
        )
        prev_other_income_total = -(prev_other_income_total)
        prev_cost_of_revenue_total = sum(
            prev_period_group_totals.get(code, 0.0)
            for code in COST_OF_REVENUE_GROUPS['Cost of revenue']
        )
        prev_depreciation_total = sum(
            prev_period_group_totals.get(code, 0.0)
            for code in DEPRECIATION_GROUPS['Depreciation']
        )
        prev_expense_total = prev_period_prefix_totals[2].get('51', 0.0)
        prev_tax_expense_ledger = prev_period_group_totals.get('5127', 0.0)
        prev_operating_expenses_total = (
            prev_expense_total - prev_cost_of_revenue_total - prev_tax_expense_ledger
        )

        prev_gross_profit = prev_revenue_total - prev_cost_of_revenue_total
        prev_net_profit_before_tax = (
            prev_gross_profit - prev_operating_expenses_total + prev_other_income_total
        )
        prev_tax_amount = 0.0
        prev_net_profit_after_tax = prev_net_profit_before_tax

        if prev_net_profit_before_tax > 375000:
            prev_tax_amount = (prev_net_profit_before_tax - 375000) * 0.09
            prev_net_profit_after_tax = prev_net_profit_before_tax - prev_tax_amount

        if prev_tax_amount:
            prev_group_totals = dict(prev_group_totals)
            prev_group_totals['2204'] = prev_group_totals.get('2204', 0.0) - prev_tax_amount
            prev_current_liabilities = _build_section_totals(prev_group_totals, CURRENT_LIABILITY_GROUPS)
            prev_current_liabilities_total = sum(prev_current_liabilities.values())
            prev_total_liabilities = -(prev_current_liabilities_total + prev_non_current_liabilities_total)

        prev_gross_profit_margin = _calc_margin(prev_gross_profit, prev_revenue_total)
        prev_net_profit_margin = _calc_margin(prev_net_profit_after_tax, prev_revenue_total)

        label_prev_net_profit_before_tax = prev_net_profit_before_tax if show_prior_year else 0.0
        label_prev_net_profit_after_tax = prev_net_profit_after_tax if show_prior_year else 0.0
        net_profit_before_tax_label = _net_label(
            net_profit_before_tax,
            label_prev_net_profit_before_tax,
            "before tax",
        )
        net_profit_after_tax_label = _net_label(
            net_profit_after_tax,
            label_prev_net_profit_after_tax,
            "after tax",
        )

        prev_prev_revenue_total = sum(
            prev_prev_period_group_totals.get(code, 0.0)
            for code in REVENUE_GROUPS['Revenue']
        )
        prev_prev_revenue_total = -(prev_prev_revenue_total)
        prev_prev_other_income_total = sum(
            prev_prev_period_group_totals.get(code, 0.0)
            for code in OTHER_INCOME_GROUPS['Other income']
        )
        prev_prev_other_income_total = -(prev_prev_other_income_total)
        prev_prev_cost_of_revenue_total = sum(
            prev_prev_period_group_totals.get(code, 0.0)
            for code in COST_OF_REVENUE_GROUPS['Cost of revenue']
        )
        prev_prev_depreciation_total = sum(
            prev_prev_period_group_totals.get(code, 0.0)
            for code in DEPRECIATION_GROUPS['Depreciation']
        )
        prev_prev_expense_total = prev_prev_period_prefix_totals[2].get('51', 0.0)
        prev_prev_tax_expense_ledger = prev_prev_period_group_totals.get('5127', 0.0)
        prev_prev_operating_expenses_total = (
            prev_prev_expense_total - prev_prev_cost_of_revenue_total - prev_prev_tax_expense_ledger
        )
        prev_prev_gross_profit = prev_prev_revenue_total - prev_prev_cost_of_revenue_total
        prev_prev_net_profit_before_tax = (
            prev_prev_gross_profit
            - prev_prev_operating_expenses_total
            + prev_prev_other_income_total
        )
        prev_prev_tax_amount = 0.0
        prev_prev_net_profit_after_tax = prev_prev_net_profit_before_tax

        if prev_prev_net_profit_before_tax > 375000:
            prev_prev_tax_amount = (prev_prev_net_profit_before_tax - 375000) * 0.09
            prev_prev_net_profit_after_tax = prev_prev_net_profit_before_tax - prev_prev_tax_amount

        note_number = 5
        note_numbers = {}
        note_sections = []
        note_labels = dict(MAIN_HEAD_LABELS)
        if receivable_label:
            note_labels['1203'] = receivable_label

        note_prev_account_heads = prev_account_heads if show_prior_year else {}
        note_prev_group_totals = prev_group_totals if show_prior_year else {}
        note_prev_period_account_heads = prev_period_account_heads if show_prior_year else {}
        note_prev_period_group_totals = prev_period_group_totals if show_prior_year else {}

        def _add_note(key, label, group_codes, current_total, prev_total, current_map=None, prev_map=None):
            nonlocal note_number
            lines = _collect_note_lines(
                group_codes,
                current_map or current_account_heads,
                prev_map or note_prev_account_heads,
            )
            if not lines:
                return
            note_numbers[key] = note_number
            note_sections.append({
                'number': note_number,
                'label': label,
                'lines': lines,
                'total_current': current_total,
                'total_prev': prev_total,
            })
            note_number += 1

        non_current_codes = ['1101', '1102', '1103', '1104', '1105', '1106', '1107', '1108', '1109']
        current_codes = ['1201', '1202', '1203', '1204', '1205', '1206']
        equity_codes = ['3101']
        non_current_liability_codes = ['2101', '2102', '2103', '2104']
        current_liability_codes = ['2201', '2202', '2203', '2204']
        aggregated_payables_codes = set(current_liability_codes)
        for code in non_current_codes + current_codes + equity_codes + non_current_liability_codes + current_liability_codes:
            if code in aggregated_payables_codes:
                continue
            current_total = current_group_totals.get(code, 0.0)
            prev_total = note_prev_group_totals.get(code, 0.0)
            if not (current_total or prev_total):
                if code == '3101':
                    if code not in note_numbers:
                        note_numbers[code] = note_number
                        note_sections.append({
                            'number': note_number,
                            'label': note_labels.get(code, code),
                            'lines': [],
                            'total_current': 0.0,
                            'total_prev': 0.0,
                        })
                        note_number += 1
                    if 'retained_earnings' not in note_numbers:
                        note_numbers['retained_earnings'] = note_number
                        note_sections.append({
                            'number': note_number,
                            'label': 'Retained earnings',
                            'lines': [],
                            'total_current': 0.0,
                            'total_prev': 0.0,
                        })
                        note_number += 1
                continue
            _add_note(code, note_labels.get(code, code), [code], current_total, prev_total)
            if code == '3101' and 'retained_earnings' not in note_numbers:
                note_numbers['retained_earnings'] = note_number
                note_sections.append({
                    'number': note_number,
                    'label': 'Retained earnings',
                    'lines': [],
                    'total_current': 0.0,
                    'total_prev': 0.0,
                })
                note_number += 1

        aggregated_payables_current = sum(
            current_group_totals.get(code, 0.0)
            for code in aggregated_payables_codes
        )
        aggregated_payables_prev = sum(
            note_prev_group_totals.get(code, 0.0)
            for code in aggregated_payables_codes
        )
        if aggregated_payables_current or aggregated_payables_prev:
            _add_note(
                'other_payables',
                'Other payables',
                sorted(aggregated_payables_codes),
                aggregated_payables_current,
                aggregated_payables_prev,
            )

        expense_group_codes = sorted({
            code for code in current_group_totals
            if code.startswith('51')
        } | {
            code for code in note_prev_group_totals
            if code.startswith('51')
        })
        cost_codes = set(COST_OF_REVENUE_GROUPS['Cost of revenue'])
        depreciation_codes = set(DEPRECIATION_GROUPS['Depreciation'])
        tax_codes = {'5127'}
        operating_expense_codes = [
            code
            for code in expense_group_codes
            if code not in cost_codes | depreciation_codes | tax_codes
        ]

        note_prev_revenue_total = prev_revenue_total if show_prior_year else 0.0
        note_prev_cost_of_revenue_total = prev_cost_of_revenue_total if show_prior_year else 0.0
        note_prev_operating_expenses_total = prev_operating_expenses_total if show_prior_year else 0.0
        if revenue_total or note_prev_revenue_total:
            _add_note(
                'pl_revenue',
                'Revenue',
                REVENUE_GROUPS['Revenue'],
                revenue_total,
                note_prev_revenue_total,
                current_map=period_account_heads,
                prev_map=note_prev_period_account_heads,
            )
        if cost_of_revenue_total or note_prev_cost_of_revenue_total:
            _add_note(
                'pl_cost',
                'Cost of revenue',
                COST_OF_REVENUE_GROUPS['Cost of revenue'],
                cost_of_revenue_total,
                note_prev_cost_of_revenue_total,
                current_map=period_account_heads,
                prev_map=note_prev_period_account_heads,
            )
        if operating_expenses_total or note_prev_operating_expenses_total:
            current_total = sum(period_group_totals.get(code, 0.0) for code in operating_expense_codes)
            prev_total = sum(note_prev_period_group_totals.get(code, 0.0) for code in operating_expense_codes)
            _add_note(
                'pl_opex',
                'Operating expenses',
                operating_expense_codes,
                current_total,
                prev_total,
                current_map=period_account_heads,
                prev_map=note_prev_period_account_heads,
            )

        post_table_note_keys = [
            'related_parties',
            'risk_management',
            'financial_assets_liabilities',
            'contingent_liabilities',
            'general_notes',
        ]
        for key in post_table_note_keys:
            note_numbers[key] = note_number
            note_number += 1

        ###### Variables for Cash Flow Statement ######
        eosb_liability_code = '21040101'
        owner_current_account_code = '12040102'
        dividend_paid_code = '31010202'
        tax_liability_code = '2204'
        tax_expense_code = '512701'

        def _liability_to_positive(value):
            return -value

        current_depreciation_total = period_group_totals.get('5114', 0.0)
        prior_depreciation_total = prev_period_group_totals.get('5114', 0.0)

        eosb_movement = _liability_to_positive(period_prefix_totals[8].get(eosb_liability_code, 0.0))
        prior_eosb_movement = _liability_to_positive(prev_period_prefix_totals[8].get(eosb_liability_code, 0.0))

        end_service_benefits_adjustment = max(eosb_movement, 0.0)
        prior_end_service_benefits_adjustment = max(prior_eosb_movement, 0.0)
        end_service_benefits_paid = -max(-eosb_movement, 0.0)
        prior_end_service_benefits_paid = -max(-prior_eosb_movement, 0.0)

        operating_cashflow_before_working_capital = (
            net_profit_before_tax
            + current_depreciation_total
            + end_service_benefits_adjustment
        )
        prior_operating_cashflow_before_working_capital = (
            prev_net_profit_before_tax
            + prior_depreciation_total
            + prior_end_service_benefits_adjustment
        )

        current_wc_assets = (
            current_group_totals.get('1201', 0.0)
            + current_group_totals.get('1202', 0.0)
            + current_group_totals.get('1203', 0.0)
        )
        prior_wc_assets = (
            prev_group_totals.get('1201', 0.0)
            + prev_group_totals.get('1202', 0.0)
            + prev_group_totals.get('1203', 0.0)
        )
        prev_prev_wc_assets = (
            prev_prev_group_totals.get('1201', 0.0)
            + prev_prev_group_totals.get('1202', 0.0)
            + prev_prev_group_totals.get('1203', 0.0)
        )

        change_in_current_assets = -(current_wc_assets - prior_wc_assets)
        prior_change_in_current_assets = -(prior_wc_assets - prev_prev_wc_assets)

        current_wc_liabilities = _liability_to_positive(
            current_group_totals.get('2202', 0.0) + current_group_totals.get('2203', 0.0)
        )
        prior_wc_liabilities = _liability_to_positive(
            prev_group_totals.get('2202', 0.0) + prev_group_totals.get('2203', 0.0)
        )
        prev_prev_wc_liabilities = _liability_to_positive(
            prev_prev_group_totals.get('2202', 0.0) + prev_prev_group_totals.get('2203', 0.0)
        )

        change_in_current_liabilities = current_wc_liabilities - prior_wc_liabilities
        prior_change_in_current_liabilities = prior_wc_liabilities - prev_prev_wc_liabilities

        current_tax_liability = _liability_to_positive(current_group_totals.get(tax_liability_code, 0.0))
        prior_tax_liability = _liability_to_positive(prev_group_totals.get(tax_liability_code, 0.0))
        prev_prev_tax_liability = _liability_to_positive(prev_prev_group_totals.get(tax_liability_code, 0.0))
        current_tax_expense = period_prefix_totals[6].get(tax_expense_code, 0.0)
        prior_tax_expense = prev_period_prefix_totals[6].get(tax_expense_code, 0.0)

        corporate_tax_paid = -(prior_tax_liability + current_tax_expense - current_tax_liability)
        prior_corporate_tax_paid = -(prev_prev_tax_liability + prior_tax_expense - prior_tax_liability)

        net_cash_generated_from_operations = (
            operating_cashflow_before_working_capital
            + change_in_current_assets
            + change_in_current_liabilities
            + corporate_tax_paid
            + end_service_benefits_paid
        )
        prior_net_cash_generated_from_operations = (
            prior_operating_cashflow_before_working_capital
            + prior_change_in_current_assets
            + prior_change_in_current_liabilities
            + prior_corporate_tax_paid
            + prior_end_service_benefits_paid
        )

        current_property = -(period_group_totals.get('1101', 0.0))
        prior_property = -(prev_period_group_totals.get('1101', 0.0))
        net_cash_generated_from_investing_activities = current_property
        prior_net_cash_generated_from_investing_activities = prior_property

        company = self.company_id
        company_share_capital_total = sum(
            (getattr(company, f'total_share_{i}', 0.0) or 0.0)
            for i in range(1, 11)
        )
        paid_up_capital = company_share_capital_total
        prior_paid_up_capital = company_share_capital_total if show_prior_year else 0.0

        current_dividend = current_prefix_totals[8].get(dividend_paid_code, 0.0)
        prior_dividend = prev_prefix_totals[8].get(dividend_paid_code, 0.0)
        prev_prev_dividend = prev_prev_prefix_totals[8].get(dividend_paid_code, 0.0)
        dividend_paid = -(current_dividend - prior_dividend)
        prior_dividend_paid = -(prior_dividend - prev_prev_dividend)

        current_owner_ca = current_prefix_totals[8].get(owner_current_account_code, 0.0)
        prior_owner_ca = prev_prefix_totals[8].get(owner_current_account_code, 0.0)
        prev_prev_owner_ca = prev_prev_prefix_totals[8].get(owner_current_account_code, 0.0)
        owner_current_account = -(current_owner_ca - prior_owner_ca)
        prior_owner_current_account = -(prior_owner_ca - prev_prev_owner_ca)

        net_cash_generated_from_financing_activities = (
            paid_up_capital + dividend_paid + owner_current_account
        )
        prior_net_cash_generated_from_financing_activities = (
            prior_paid_up_capital + prior_dividend_paid + prior_owner_current_account
        )

        current_cash_and_bank = current_group_totals.get('1204', 0.0)
        current_wallets = current_group_totals.get('1205', 0.0)
        current_interbank = current_group_totals.get('1206', 0.0)
        prior_cash_and_bank = prev_group_totals.get('1204', 0.0)
        prior_wallets = prev_group_totals.get('1205', 0.0)
        prior_interbank = prev_group_totals.get('1206', 0.0)
        prev_prev_cash_and_bank = prev_prev_group_totals.get('1204', 0.0)
        prev_prev_wallets = prev_prev_group_totals.get('1205', 0.0)
        prev_prev_interbank = prev_prev_group_totals.get('1206', 0.0)

        current_cash_equivalents = (
            current_cash_and_bank + current_wallets - current_interbank - current_owner_ca
        )
        prior_cash_equivalents = (
            prior_cash_and_bank + prior_wallets - prior_interbank - prior_owner_ca
        )
        prev_prev_cash_equivalents = (
            prev_prev_cash_and_bank + prev_prev_wallets - prev_prev_interbank - prev_prev_owner_ca
        )

        net_cash_and_cash_equivalents = (
            net_cash_generated_from_operations
            + net_cash_generated_from_investing_activities
            + net_cash_generated_from_financing_activities
        )
        cash_beginning_year = prior_cash_equivalents
        cash_end_of_year = current_cash_equivalents

        prior_net_cash_and_cash_equivalents = (
            prior_net_cash_generated_from_operations
            + prior_net_cash_generated_from_investing_activities
            + prior_net_cash_generated_from_financing_activities
        )
        prior_cash_beginning_year = prev_prev_cash_equivalents
        prior_cash_end_of_year = prior_cash_equivalents


        ##############################################################################################

        ############# Shareholders Section #############


        # Shareholders START #
        #########################################################################################################
        company = self.company_id
        # Shareholders (explicit variables)
        sh_name_1 = company.shareholder_1
        sh_nat_1 = company.nationality_1
        sh_shares_1 = company.number_of_shares_1
        sh_value_1 = company.share_value_1
        sh_total_1 = company.total_share_1

        sh_name_2 = company.shareholder_2
        sh_nat_2 = company.nationality_2
        sh_shares_2 = company.number_of_shares_2
        sh_value_2 = company.share_value_2
        sh_total_2 = company.total_share_2

        sh_name_3 = company.shareholder_3
        sh_nat_3 = company.nationality_3
        sh_shares_3 = company.number_of_shares_3
        sh_value_3 = company.share_value_3
        sh_total_3 = company.total_share_3

        sh_name_4 = company.shareholder_4
        sh_nat_4 = company.nationality_4
        sh_shares_4 = company.number_of_shares_4
        sh_value_4 = company.share_value_4
        sh_total_4 = company.total_share_4

        sh_name_5 = company.shareholder_5
        sh_nat_5 = company.nationality_5
        sh_shares_5 = company.number_of_shares_5
        sh_value_5 = company.share_value_5
        sh_total_5 = company.total_share_5

        sh_name_6 = company.shareholder_6
        sh_nat_6 = company.nationality_6
        sh_shares_6 = company.number_of_shares_6
        sh_value_6 = company.share_value_6
        sh_total_6 = company.total_share_6

        sh_name_7 = company.shareholder_7
        sh_nat_7 = company.nationality_7
        sh_shares_7 = company.number_of_shares_7
        sh_value_7 = company.share_value_7
        sh_total_7 = company.total_share_7

        sh_name_8 = company.shareholder_8
        sh_nat_8 = company.nationality_8
        sh_shares_8 = company.number_of_shares_8
        sh_value_8 = company.share_value_8
        sh_total_8 = company.total_share_8

        sh_name_9 = company.shareholder_9
        sh_nat_9 = company.nationality_9
        sh_shares_9 = company.number_of_shares_9
        sh_value_9 = company.share_value_9
        sh_total_9 = company.total_share_9

        sh_name_10 = company.shareholder_10
        sh_nat_10 = company.nationality_10
        sh_shares_10 = company.number_of_shares_10
        sh_value_10 = company.share_value_10
        sh_total_10 = company.total_share_10

        share_rows = []
        for i in range(1, 11):
            name = getattr(company, f'shareholder_{i}', False)
            if not name:
                continue
            share_rows.append({
                'name': name,
                'value': getattr(company, f'share_value_{i}', 0.0) or 0.0,
                'shares': getattr(company, f'number_of_shares_{i}', 0) or 0,
                'total': getattr(company, f'total_share_{i}', 0.0) or 0.0,
            })

        authorized_share_capital = sum(row['total'] for row in share_rows)
        total_shares_count = sum(row['shares'] for row in share_rows)
        share_value_default = share_rows[0]['value'] if share_rows else 0.0

        signature_names = [
            name.strip()
            for name in (
                sh_name_1,
                sh_name_2,
                sh_name_3,
                sh_name_4,
                sh_name_5,
                sh_name_6,
                sh_name_7,
                sh_name_8,
                sh_name_9,
                sh_name_10,
            )
            if name and name.strip()
        ]
        generated_date = fields.Date.context_today(self)
        generated_date_display = generated_date.strftime("%d/%m/%Y") if generated_date else ''



        # Shareholders END #
        #########################################################################################################

        # Changes in Equity START #
        #########################################################################################################
        total_shares = company_share_capital_total

        retained_earnings_code = '31010203'
        prior_retained_earnings_balance = _equity_head_balance(prev_account_heads, retained_earnings_code)
        prev_prev_retained_earnings_balance = _equity_head_balance(prev_prev_account_heads, retained_earnings_code)
        retained_earnings = net_profit_after_tax
        prev_retained_earnings = prev_net_profit_after_tax
        prev_prev_retained_earnings = prev_prev_net_profit_after_tax
        prev_retained_earnings_balance = prior_retained_earnings_balance
        retained_earnings_balance = prior_retained_earnings_balance + retained_earnings

        equity_total_display = total_shares + retained_earnings_balance
        prev_equity_total_display = total_shares + prev_retained_earnings_balance
        prev_prev_equity_total_display = total_shares + prev_prev_retained_earnings_balance

        # Total Equity to show on the statement of changes in equity
        total_soce = equity_total_display
        prev_total_soce = prev_equity_total_display
        prev_prev_total_soce = prev_prev_equity_total_display
        total_of_equity_and_liabilities = equity_total_display + total_liabilities
        prev_total_of_equity_and_liabilities = prev_equity_total_display + prev_total_liabilities
        show_current_year_profit_line = True
        soce_rows = []
        if show_prior_year and prior_prior_date_end:
            soce_rows.append({
                'label': f"Balance as at {prior_prior_date_end.strftime('%d %B %Y')}",
                'share_capital': total_shares,
                'retained_earnings': prev_prev_retained_earnings_balance,
                'total_equity': prev_prev_equity_total_display,
                'is_balance': True,
            })
        if prior_date_end:
            if show_prior_year:
                soce_rows.append({
                    'label': "Total comprehensive profit for the year",
                    'share_capital': None,
                    'retained_earnings': prev_retained_earnings,
                    'total_equity': prev_retained_earnings,
                    'is_balance': False,
                })
            soce_rows.append({
                'label': f"Balance as at {prior_date_end.strftime('%d %B %Y')}",
                'share_capital': total_shares,
                'retained_earnings': prev_retained_earnings_balance,
                'total_equity': prev_equity_total_display,
                'is_balance': True,
            })
        if show_current_year_profit_line:
            soce_rows.append({
                'label': "Total comprehensive profit for the year",
                'share_capital': None,
                'retained_earnings': retained_earnings,
                'total_equity': retained_earnings,
                'is_balance': False,
            })
        if date_end:
            soce_rows.append({
                'label': f"Balance as at {date_end.strftime('%d %B %Y')}",
                'share_capital': total_shares,
                'retained_earnings': retained_earnings_balance,
                'total_equity': equity_total_display,
                'is_balance': True,
            })

        # Changes in Equity END #
        #########################################################################################################

        # Statement of Cash Flows START #
        #########################################################################################################


        


        # Statement of Cash Flows END #
        #########################################################################################################

        return {

            # Balance Sheet
            'balance_rows': balance_rows,
            'profit_loss_accounts': profit_loss_accounts,
            'total_assets': total_assets,
            'total_liabilities': total_liabilities,
            'total_equity': equity_total_display,
            'current_assets': current_assets,
            'current_liabilities': current_liabilities,
            'equity': equity,
            'non_current_assets': non_current_assets,
            'non_current_liabilities': non_current_liabilities,
            'current_liabilities_total': current_liabilities_total,
            'non_current_liabilities_total': non_current_liabilities_total,
            'current_assets_total': current_assets_total,
            'non_current_assets_total': non_current_assets_total,
            'total_of_equity_and_liabilities': total_of_equity_and_liabilities,
            'prev_current_assets_total': prev_current_assets_total,
            'prev_non_current_assets_total': prev_non_current_assets_total,
            'prev_total_assets': prev_total_assets,
            'prev_current_liabilities_total': prev_current_liabilities_total,
            'prev_non_current_liabilities_total': prev_non_current_liabilities_total,
            'prev_total_liabilities': prev_total_liabilities,
            'prev_total_equity': prev_equity_total_display,
            'prev_total_of_equity_and_liabilities': prev_total_of_equity_and_liabilities,

            # PnL
             'cost_of_revenue_total':cost_of_revenue_total,
             'depreciation_total':depreciation_total,
             'operating_expenses_total':operating_expenses_total,
             'revenue_total':revenue_total,
             'gross_profit':gross_profit,
             'net_profit_before_tax':net_profit_before_tax,
             'net_profit_after_tax':net_profit_after_tax,
             'other_income_total': other_income_total,
             'gross_profit_margin': gross_profit_margin,
             'net_profit_margin': net_profit_margin,
             'tax_amount':tax_amount,
             'prev_revenue_total': prev_revenue_total,
             'prev_cost_of_revenue_total': prev_cost_of_revenue_total,
             'prev_gross_profit': prev_gross_profit,
             'prev_operating_expenses_total': prev_operating_expenses_total,
             'prev_net_profit_before_tax': prev_net_profit_before_tax,
             'prev_tax_amount': prev_tax_amount,
             'prev_net_profit_after_tax': prev_net_profit_after_tax,
             'prev_other_income_total': prev_other_income_total,
             'prev_gross_profit_margin': prev_gross_profit_margin,
             'prev_net_profit_margin': prev_net_profit_margin,
             'net_profit_before_tax_label': net_profit_before_tax_label,
             'net_profit_after_tax_label': net_profit_after_tax_label,

             # Statement of Changes in Equity
             'retained_earnings':retained_earnings,
            'total_soce':total_soce,
            'prev_retained_earnings': prev_retained_earnings,
            'prev_total_soce': prev_total_soce,
            'prev_prev_retained_earnings': prev_prev_retained_earnings,
            'prev_prev_total_soce': prev_prev_total_soce,
            'share_capital_total': total_shares,
            'prev_share_capital_total': total_shares,
            'retained_earnings_balance': retained_earnings_balance,
            'prev_retained_earnings_balance': prev_retained_earnings_balance,
            'prev_prev_retained_earnings_balance': prev_prev_retained_earnings_balance,
            'equity_total_display': equity_total_display,
            'prev_equity_total_display': prev_equity_total_display,
            'prev_prev_equity_total_display': prev_prev_equity_total_display,
            'soce_rows': soce_rows,
            'signature_names': signature_names,
            'generated_date_display': generated_date_display,
            'share_rows': share_rows,
            'authorized_share_capital': authorized_share_capital,
            'total_shares_count': total_shares_count,
            'share_value_default': share_value_default,

            # Shareholders
            'sh_name_1':sh_name_1,
             'sh_nat_1':sh_nat_1,
             'sh_shares_1':sh_shares_1,
             'sh_value_1':sh_value_1,
             'sh_total_1':sh_total_1,
             'sh_name_2':sh_name_2,
             'sh_nat_2':sh_nat_2,
             'sh_shares_2':sh_shares_2,
             'sh_value_2':sh_value_2,
             'sh_total_2':sh_total_2,
             'sh_name_3':sh_name_3,
             'sh_nat_3':sh_nat_3,
             'sh_shares_3':sh_shares_3,
             'sh_value_3':sh_value_3,
             'sh_total_3':sh_total_3,

             # Property and equipment subheads
             'current_ppe_subheads': current_ppe_subheads,
             'current_ppe_total': current_ppe_total,
             'prev_ppe_subheads': prev_ppe_subheads,
             'prev_ppe_total': prev_ppe_total,
             'current_subheads_by_group': current_subheads_by_group,
             'prev_subheads_by_group': prev_subheads_by_group,
             'current_main_heads': current_main_heads,
             'prev_main_heads': prev_main_heads,
             'main_head_labels': MAIN_HEAD_LABELS,
            'current_group_totals': current_group_totals,
            'prev_group_totals': prev_group_totals,
            'show_prior_year': show_prior_year,

            # Cash flow
            'current_depreciation_total': current_depreciation_total,
            'prior_depreciation_total': prior_depreciation_total,
            'end_service_benefits_adjustment': end_service_benefits_adjustment,
            'prior_end_service_benefits_adjustment': prior_end_service_benefits_adjustment,
            'operating_cashflow_before_working_capital': operating_cashflow_before_working_capital,
            'prior_operating_cashflow_before_working_capital': prior_operating_cashflow_before_working_capital,
            'change_in_current_assets': change_in_current_assets,
            'prior_change_in_current_assets': prior_change_in_current_assets,
            'change_in_current_liabilities': change_in_current_liabilities,
            'prior_change_in_current_liabilities': prior_change_in_current_liabilities,
            'corporate_tax_paid': corporate_tax_paid,
            'prior_corporate_tax_paid': prior_corporate_tax_paid,
            'end_service_benefits_paid': end_service_benefits_paid,
            'prior_end_service_benefits_paid': prior_end_service_benefits_paid,
            'net_cash_generated_from_operations': net_cash_generated_from_operations,
            'prior_net_cash_generated_from_operations': prior_net_cash_generated_from_operations,
            'current_property': current_property,
            'prior_property': prior_property,
            'net_cash_generated_from_investing_activities': net_cash_generated_from_investing_activities,
            'prior_net_cash_generated_from_investing_activities': prior_net_cash_generated_from_investing_activities,
            'paid_up_capital': paid_up_capital,
            'prior_paid_up_capital': prior_paid_up_capital,
            'dividend_paid': dividend_paid,
            'prior_dividend_paid': prior_dividend_paid,
            'owner_current_account': owner_current_account,
            'prior_owner_current_account': prior_owner_current_account,
            'net_cash_generated_from_financing_activities': net_cash_generated_from_financing_activities,
            'prior_net_cash_generated_from_financing_activities': prior_net_cash_generated_from_financing_activities,
            'net_cash_and_cash_equivalents': net_cash_and_cash_equivalents,
            'prior_net_cash_and_cash_equivalents': prior_net_cash_and_cash_equivalents,
            'cash_beginning_year': cash_beginning_year,
            'cash_end_of_year': cash_end_of_year,
            'prior_cash_beginning_year': prior_cash_beginning_year,
            'prior_cash_end_of_year': prior_cash_end_of_year,

            # Notes
            'note_numbers': note_numbers,
            'note_sections': note_sections,
            }



    def action_print_account_report_lines(self):
        """Generate and display report"""
        self.ensure_one()

        if self.use_previous_settings:
            self._store_previous_settings()

        # report_data = self._get_report_data()
        # You can now pass `report_data` to your Word/PDF renderer

        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/view/{self.id}',
            'target': 'new',
        } 

    def action_print_account_report_pdf(self):
        """Generate and display report as server-side PDF (headless Chrome)."""
        self.ensure_one()

        if self.use_previous_settings:
            self._store_previous_settings()

        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/pdf/{self.id}',
            'target': 'new',
        }

    
    

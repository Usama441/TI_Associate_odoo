from odoo import http
from odoo.http import request
from jinja2 import Environment, FileSystemLoader
import os
import re
import logging

_logger = logging.getLogger(__name__)


class AuditReportController(http.Controller):
    def _html_to_pdf(self, html_content, base_url=None):
        """Render HTML+CSS to PDF server-side.

        WeasyPrint supports CSS paged media (@page, counters, margin boxes) and
        matches browser print output better than wkhtmltopdf in most cases.
        """
        try:
            from weasyprint import HTML
        except Exception as e:
            raise RuntimeError(f"WeasyPrint is not available in this Odoo environment: {e}")

        return HTML(string=html_content, base_url=base_url).write_pdf()

    def _html_to_pdf_doc(self, html_content, base_url=None):
        """Render HTML to a WeasyPrint document for page counting."""
        try:
            from weasyprint import HTML
        except Exception as e:
            raise RuntimeError(f"WeasyPrint is not available in this Odoo environment: {e}")

        return HTML(string=html_content, base_url=base_url).render()

    def _default_toc_entries(self, report, data):
        signature_names = data.get('signature_names') or []
        director_label_lower = 'director' if len(signature_names) == 1 else 'directors'
        return [
            {'label': 'Entity information', 'page_range': '1'},
            {'label': f'Report of {director_label_lower}', 'page_range': '2-3'},
            {'label': 'Independent auditor report', 'page_range': '4-5'},
            {'label': 'Statement of financial position', 'page_range': '6'},
            {'label': 'Statement of profit and loss and other comprehensive income', 'page_range': '7'},
            {'label': 'Statement of changes in equity', 'page_range': '8'},
            {'label': 'Statement of cash flows', 'page_range': '9'},
            {'label': 'Notes to the financial statements', 'page_range': '10-22'},
        ]

    def _compute_toc_entries(self, report):
        module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        data = report._get_report_data()
        signature_names = data.get('signature_names') or []
        director_label_lower = 'director' if len(signature_names) == 1 else 'directors'
        sections = [
            ('entity_information', 'Entity information'),
            ('report_of_directors', f'Report of {director_label_lower}'),
            ('independent_auditor_report', 'Independent auditor report'),
            ('balance_sheet_page', 'Statement of financial position'),
            ('profit_loss', 'Statement of profit and loss and other comprehensive income'),
            ('changes_in_equity', 'Statement of changes in equity'),
            ('cash_flows', 'Statement of cash flows'),
            ('notes_to_financial_statements', 'Notes to the financial statements'),
        ]

        toc_entries = []
        current_page = 1
        for section_key, label in sections:
            html_with_style = self._render_report_html(
                report,
                sections_to_render=[section_key],
                toc_entries=self._default_toc_entries(report, data),
            )
            doc = self._html_to_pdf_doc(html_with_style, base_url=module_path)
            page_count = len(doc.pages)
            if page_count <= 0:
                continue
            end_page = current_page + page_count - 1
            page_range = str(current_page) if page_count == 1 else f"{current_page}-{end_page}"
            toc_entries.append({'label': label, 'page_range': page_range})
            current_page = end_page + 1

        return toc_entries

    def _render_report_html(self, report, sections_to_render=None, toc_entries=None):
        company = report.company_id
        if not report.exists():
            return None

        module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        templates_path = os.path.join(module_path, 'templates')
        env = Environment(loader=FileSystemLoader(templates_path))
        default_format = env.filters.get('format')

        def format_filter(fmt, *args, **kwargs):
            # Ensure consistent accounting formatting:
            # - thousands separators (12,345.67)
            # - negatives in parentheses ((12,345.67))
            # Applies to printf-style float formats like "%.2f", "%.0f", etc.
            if isinstance(fmt, str) and args:
                m = re.fullmatch(r"%\.(\d+)f", fmt)
            else:
                m = None
            if m and args:
                # Round to whole numbers for all figures in the report.
                decimals = 0
                value = args[0] or 0.0
                try:
                    number = float(value)
                except (TypeError, ValueError):
                    return default_format(fmt, *args, **kwargs) if default_format else fmt % args
                if number < 0:
                    return f"({abs(number):,.{decimals}f})"
                return f"{number:,.{decimals}f}"
            return default_format(fmt, *args, **kwargs) if default_format else fmt % args

        def format_percent(fmt, *args, **kwargs):
            """Format percentages with the requested decimals (no rounding to whole)."""
            if isinstance(fmt, str) and args:
                m = re.fullmatch(r"%\.(\d+)f", fmt)
            else:
                m = None
            if m and args:
                decimals = int(m.group(1))
                value = args[0] or 0.0
                try:
                    number = float(value)
                except (TypeError, ValueError):
                    return default_format(fmt, *args, **kwargs) if default_format else fmt % args
                formatted = f"{abs(number):,.{decimals}f}"
                if decimals:
                    formatted = formatted.rstrip('0').rstrip('.')
                if number < 0:
                    return f"({formatted})"
                return formatted
            return default_format(fmt, *args, **kwargs) if default_format else fmt % args

        def running_case_filter(value):
            """Convert headings/labels to sentence case while keeping acronyms (VAT/IFRS/UAE/ROU/etc)."""
            if value is None:
                return ''
            text = str(value).strip()
            if not text:
                return ''

            parts = re.split(r'(\s+)', text)
            out = []
            for part in parts:
                if not part or part.isspace():
                    out.append(part)
                    continue
                token = part
                # Keep acronyms and codes (all-caps), and anything containing digits.
                if token.isupper() or any(ch.isdigit() for ch in token):
                    out.append(token)
                else:
                    out.append(token.lower())

            # Capitalize the first alphabetic character (if the first token isn't an acronym).
            for i, part in enumerate(out):
                if not part or part.isspace():
                    continue
                if part.isupper():  # acronym in first position
                    break
                for j, ch in enumerate(part):
                    if ch.isalpha():
                        out[i] = part[:j] + ch.upper() + part[j + 1:]
                        break
                break
            return ''.join(out)

        env.filters['format'] = format_filter
        env.filters['format_percent'] = format_percent
        env.filters['rcase'] = running_case_filter
        template = env.get_template('audit_report_template.html')

        data = report._get_report_data()
        report_type_label = dict(report._fields['report_type'].selection).get(report.report_type, '')
        report_period_end = report.date_end.strftime("%d %B %Y") if report.date_end else ''
        report_title = f"{report_type_label} {report_period_end}".strip()
        activity = getattr(company, 'trade_license_activities', '') or ''
        implementing_regulations_freezone = getattr(company, 'implementing_regulations_freezone', '') or ''
        if not implementing_regulations_freezone and hasattr(company, '_get_free_zone_implementing_regulations'):
            implementing_regulations_freezone = (
                company._get_free_zone_implementing_regulations(getattr(company, 'free_zone', '')) or ''
            )

        context = {
            'company': company,
            'company_name': getattr(company, 'name', ''),
            'freezone': getattr(company, 'free_zone', ''),
            'implementing_regulations_freezone': implementing_regulations_freezone,
            'license': getattr(company, 'company_license_number', ''),
            'owner': getattr(company, 'owner', ''),
            'business_activity': activity.lower(),
            'date_start': report.date_start,
            'date_end': report.date_end,
            'freezone_selection': report.auditor_type,
            'report_title': report_title,
            'report_type': report.report_type,
            'report_period_end': report_period_end,
            'sections_to_render': sections_to_render,
        }
        context.update(data)
        if toc_entries is None:
            toc_entries = self._default_toc_entries(report, data)
        context['toc_entries'] = toc_entries

        html_content = template.render(**context)
        css_path = os.path.join(templates_path, 'audit_report_style.css')
        with open(css_path, 'r') as f:
            css_content = f.read()

        return html_content.replace('</head>', f'<style>{css_content}</style></head>')
    
    @http.route('/audit_report/view/<int:report_id>', type='http', auth='user')
    def view_report(self, report_id, **kwargs):
        report = request.env['audit.report'].browse(report_id)
        html_with_style = self._render_report_html(report)
        if not html_with_style:
            return request.not_found()
        
        return request.make_response(
            html_with_style,
            headers=[
                ('Content-Type', 'text/html; charset=utf-8'),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ]
        )

    @http.route('/audit_report/pdf/<int:report_id>', type='http', auth='user')
    def view_report_pdf(self, report_id, **kwargs):
        report = request.env['audit.report'].browse(report_id)
        try:
            toc_entries = self._compute_toc_entries(report)
        except Exception as e:
            _logger.exception("Audit report TOC generation failed: %s", e)
            toc_entries = None
        html_with_style = self._render_report_html(report, toc_entries=toc_entries)
        if not html_with_style:
            return request.not_found()

        try:
            module_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            pdf_content = self._html_to_pdf(html_with_style, base_url=module_path)
        except Exception as e:
            _logger.exception("Audit report PDF generation failed: %s", e)
            return request.make_response(
                f"Audit report PDF generation failed.\n\n{e}\n",
                headers=[('Content-Type', 'text/plain; charset=utf-8')],
                status=500,
            )
        filename = f'Audit_Report_{report.id}.pdf'
        return request.make_response(
            pdf_content,
            headers=[
                ('Content-Type', 'application/pdf'),
                ('Content-Disposition', f'inline; filename="{filename}"'),
                ('Content-Length', str(len(pdf_content))),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ]
        )

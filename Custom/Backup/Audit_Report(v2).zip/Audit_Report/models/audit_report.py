from odoo import models, fields


class AuditReport(models.TransientModel):
    _name = 'audit.report'
    _description = 'Audit Report'


    date_start = fields.Date(string='Date Start', required=True)
    date_end = fields.Date(string='Date End', required=True)
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company,
    )

    def _get_report_data(self):
        """Get report data for the template"""


        # Get account move lines grouped by account
        accounts = self.env['account.move.line'].read_group(
            domain=[
                ('date', '>=', self.date_start),
                ('date', '<=', self.date_end),
                ('company_id', '=', self.company_id.id),
                ('move_id.state', '=', 'posted'),
            ],
            fields=['debit', 'credit', 'balance'],
            groupby=['account_id']
        )

        account_ids = [row['account_id'][0] for row in accounts]
        account_map = {acc.id: acc for acc in self.env['account.account'].browse(account_ids)}

        final_rows = []
        for row in accounts:
            account_id = row['account_id'][0]
            account = account_map.get(account_id)

            if account:
                final_data = {
                    'id': account_id,
                    'name': account.name,
                    'type': account.account_type,
                    'debit': row['debit'],
                    'credit': row['credit'],
                    'balance': row['balance'],
                }
                final_rows.append(final_data)

        # Separate balance sheet and P&L accounts
        balance_sheet_accounts = []

        profit_loss_accounts = [] # P&L accounts
        for row in final_rows:
            if row['type'].startswith(('asset', 'liability', 'equity')):
                balance_sheet_accounts.append(row)
            else:
                profit_loss_accounts.append(row)

        # Map account types to readable sections
        BS_MAP = {
            'asset_receivable': 'Receivable',
            'asset_cash': 'Bank and Cash',
            'asset_current': 'Current Assets',
            'asset_non_current': 'Non-Current Assets',
            'asset_prepayments': 'Prepayments',
            'asset_fixed': 'Fixed Assets',
            'liability_payable': 'Payable',
            'liability_credit_card': 'Credit Card',
            'liability_current': 'Current Liabilities',
            'liability_non_current': 'Non-Current Liabilities',
            'equity': 'Equity',
            # 'equity_unaffected': 'Current Year Earnings',
        }

        # Attach section to balance sheet accounts
        balance_rows = []
        for row in balance_sheet_accounts:
            section = BS_MAP.get(row['type'], 'Other')
            row['section'] = section
            balance_rows.append(row)
        

        # print(balance_rows)

        # 1) First build section totals
        section_totals = {}
        for row in balance_rows:
            section = row["section"]
            section_totals[section] = section_totals.get(section, 0.0) + row.get("balance", 0.0)


        # 2) Now build each parent separately

        # Assets
        current_assets = {
            "Bank and Cash": section_totals.get("Bank and Cash", 0.0),
            "Receivable": section_totals.get("Receivable", 0.0),
            "Prepayments": section_totals.get("Prepayments", 0.0),
            "Current Assets": section_totals.get("Current Assets", 0.0),
        }

        current_assets_total = 0.0
        for name, balance in current_assets.items():
            current_assets_total += balance

        non_current_assets = {
            "Fixed Assets": section_totals.get("Fixed Assets", 0.0),
            "Non-Current Assets": section_totals.get("Non-Current Assets", 0.0),
        }

        non_current_assets_total = 0.0
        for name, balance in non_current_assets.items():
            non_current_assets_total += balance

        total_assets = current_assets_total + non_current_assets_total



        # Liabilities
        current_liabilities = {
            "Payable": section_totals.get("Payable", 0.0),
            "Credit Card": section_totals.get("Credit Card", 0.0),
            "Current Liabilities": section_totals.get("Current Liabilities", 0.0),
        }

        current_liabilities_total = 0.0
        for name, balance in current_liabilities.items():
            current_liabilities_total += balance

        non_current_liabilities = {
            "Non-Current Liabilities": section_totals.get("Non-Current Liabilities", 0.0),
        }

        non_current_liabilities_total = 0.0
        for name, balance in non_current_liabilities.items():
            non_current_liabilities_total += balance

        total_liabilities = -(current_liabilities_total + non_current_liabilities_total)

        # Equity
        equity = {
            "Equity": section_totals.get("Equity", 0.0),
        }

        equity_total = 0.0
        for name, balance in equity.items():
            equity_total += balance

        total_equity = equity_total


        total_of_equity_and_liabilities = total_equity + total_liabilities
        # Balance Sheet END #
        #########################################################################################################



        # PnL START #
        PL_MAP = {
            'income': 'Revenue',
            'income_other': 'Other Income',
            'expense': 'Operating Expenses',
            'expense_other': 'Other Expenses',
            'expense_depreciation': 'Depreciation',
            'expense_direct_cost': 'Cost of Revenue',
        }

        pl_rows = []

        for row in profit_loss_accounts:
            section = PL_MAP.get(row['type'], 'Other')
            row['section'] = section
            pl_rows.append(row)

        pl_section_totals = {}
        for row in pl_rows:
            section = row["section"]
            pl_section_totals[section] = pl_section_totals.get(section, 0.0) + row.get("balance", 0.0)

        revenue = {
            "Revenue": pl_section_totals.get("Revenue", 0.0)
        }

        revenue_total = 0.0 
        for name, balance in revenue.items():
            revenue_total += balance

        revenue_total = -(revenue_total)        

        operating_expenses = {
            "Operating Expenses": pl_section_totals.get("Operating Expenses", 0.0),
            "Other Expenses": pl_section_totals.get("Other Expenses", 0.0),
        }
        operating_expenses_total = 0.0
        for name, balance in operating_expenses.items():
            operating_expenses_total += balance

        depreciation = {
            "Depreciation": pl_section_totals.get("Depreciation", 0.0)
        }
        depreciation_total = 0.0
        for name, balance in depreciation.items():
            depreciation_total += balance

        cost_of_revenue = {
            "Cost of Revenue": pl_section_totals.get("Cost of Revenue", 0.0),
        }
        cost_of_revenue_total = 0.0
        for name, balance in cost_of_revenue.items():
            cost_of_revenue_total += balance

        other_income = {
            "Other Income": pl_section_totals.get("Other Income", 0.0),
        }
        other_income_total = 0.0
        for name, balance in other_income.items():
            other_income_total += balance

        gross_profit = revenue_total - cost_of_revenue_total
        net_profit_before_tax = gross_profit - operating_expenses_total + other_income_total
        tax_amount = 0.0
        net_profit_after_tax = 0.0

        if net_profit_before_tax > 375000:
            tax_amount = (net_profit_before_tax - 375000) * 0.09
            net_profit_after_tax = net_profit_before_tax - tax_amount
        


        # PnL END #
        #########################################################################################################

        # Shareholders START #
        #########################################################################################################
        company = self.company_id
        # Shareholders (explicit variables)
        sh_name_1 = company.shareholder_1
        sh_nat_1 = company.nationality_1
        sh_shares_1 = company.number_of_shares_1
        sh_value_1 = company.share_value_1
        sh_total_1 = company.total_share_1

        sh_name_2 = company.shareholder_2
        sh_nat_2 = company.nationality_2
        sh_shares_2 = company.number_of_shares_2
        sh_value_2 = company.share_value_2
        sh_total_2 = company.total_share_2

        sh_name_3 = company.shareholder_3
        sh_nat_3 = company.nationality_3
        sh_shares_3 = company.number_of_shares_3
        sh_value_3 = company.share_value_3
        sh_total_3 = company.total_share_3

        sh_name_4 = company.shareholder_4
        sh_nat_4 = company.nationality_4
        sh_shares_4 = company.number_of_shares_4
        sh_value_4 = company.share_value_4
        sh_total_4 = company.total_share_4

        sh_name_5 = company.shareholder_5
        sh_nat_5 = company.nationality_5
        sh_shares_5 = company.number_of_shares_5
        sh_value_5 = company.share_value_5
        sh_total_5 = company.total_share_5

        sh_name_6 = company.shareholder_6
        sh_nat_6 = company.nationality_6
        sh_shares_6 = company.number_of_shares_6
        sh_value_6 = company.share_value_6
        sh_total_6 = company.total_share_6

        sh_name_7 = company.shareholder_7
        sh_nat_7 = company.nationality_7
        sh_shares_7 = company.number_of_shares_7
        sh_value_7 = company.share_value_7
        sh_total_7 = company.total_share_7

        sh_name_8 = company.shareholder_8
        sh_nat_8 = company.nationality_8
        sh_shares_8 = company.number_of_shares_8
        sh_value_8 = company.share_value_8
        sh_total_8 = company.total_share_8

        sh_name_9 = company.shareholder_9
        sh_nat_9 = company.nationality_9
        sh_shares_9 = company.number_of_shares_9
        sh_value_9 = company.share_value_9
        sh_total_9 = company.total_share_9

        sh_name_10 = company.shareholder_10
        sh_nat_10 = company.nationality_10
        sh_shares_10 = company.number_of_shares_10
        sh_value_10 = company.share_value_10
        sh_total_10 = company.total_share_10



        # Shareholders END #
        #########################################################################################################

        # Changes in Equity START #
        #########################################################################################################
        total_shares = sh_total_1 + sh_total_2 + sh_total_3 + sh_total_4 + sh_total_5 + sh_total_6 + sh_total_7 + sh_total_8 + sh_total_9 + sh_total_10

        retained_earnings = 0.0

        if net_profit_before_tax > 375000:
            retained_earnings = net_profit_after_tax
        else:
            retained_earnings = net_profit_before_tax

        # Total Equity to show on the statement of changes in equity
        total_soce = total_shares + retained_earnings

        # Changes in Equity END #
        #########################################################################################################

        # Statement of Cash Flows START #
        #########################################################################################################
        #NOT WORKING AS OF NOW.

        
        cf_accounts = self.env['account.account'].search([
            ('cash_flow_type', '!=', False),
        ])

        aml_domain = [
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('company_id', '=', self.company_id.id),
            ('move_id.state', '=', 'posted'),
            ('account_id', 'in', cf_accounts.ids),
        ]

        grouped_lines = self.env['account.move.line'].read_group(
            domain=aml_domain,
            fields=['balance', 'account_id'],
            groupby=['account_id'],
        )

        cf_rows = []

        for g in grouped_lines:
            account = self.env['account.account'].browse(g['account_id'][0])

            cf_rows.append({
                'account_id': account.id,
                'account_name': account.display_name,
                'balance': g['balance'],
                'cash_flow_type': account.cash_flow_type,
            })

        operating_cf = [r for r in cf_rows if r['cash_flow_type'] == 'operating']
        investing_cf = [r for r in cf_rows if r['cash_flow_type'] == 'investing']
        financing_cf = [r for r in cf_rows if r['cash_flow_type'] == 'financing']
        
        operating_cf_total = sum(r['balance'] for r in operating_cf)
        investing_cf_total = sum(r['balance'] for r in investing_cf)
        financing_cf_total = sum(r['balance'] for r in financing_cf)

        total_cash_flow = operating_cf_total + investing_cf_total + financing_cf_total





        # Cash FLow Part - 1
        #### Cash Flows from Operating Activities ####

        op_cash_flow_before_changes_in_capital = 0.0
        depreciation_of_property_plant_and_equipment = 0.0

        ## Need to get depreciation accounts and then sum them up.
        depreciation_accounts = self.env['account.account'].search([
                ('company_id', '=', self.company_id.id),
                ('name', 'ilike', 'depreciation%'),
            ])

        depreciation_data = self.env['account.move.line'].read_group(
                domain=[
                    ('date', '>=', self.date_start),
                    ('date', '<=', self.date_end),
                    ('company_id', '=', self.company_id.id),
                    ('move_id.state', '=', 'posted'),
                    ('account_id', 'in', depreciation_accounts.ids),
                ],
                fields=['balance'],
                groupby=[]
            )

        depreciation_of_property_plant_and_equipment = (
                depreciation_data[0]['balance'] if depreciation_data else 0.0
                )

        print(depreciation_of_property_plant_and_equipment)
        print("--------------------------------")

        op_cash_flow_before_changes_in_capital = net_profit_before_tax + depreciation_of_property_plant_and_equipment


        # Statement of Cash Flows END #
        #########################################################################################################





        # Statement of Cash Flows END #
        #########################################################################################################

        return {

            # Balance Sheet
            'balance_rows': balance_rows,
            'profit_loss_accounts': profit_loss_accounts,
            'total_assets': total_assets,
            'total_liabilities': total_liabilities,
            'total_equity': total_equity,
            'current_assets': current_assets,
            'current_liabilities': current_liabilities,
            'equity': equity,
            'non_current_assets': non_current_assets,
            'non_current_liabilities': non_current_liabilities,
            'current_liabilities_total': current_liabilities_total,
            'non_current_liabilities_total': non_current_liabilities_total,
            'current_assets_total': current_assets_total,
            'non_current_assets_total': non_current_assets_total,
            'total_of_equity_and_liabilities': total_of_equity_and_liabilities,

            # PnL
             'cost_of_revenue_total':cost_of_revenue_total,
             'depreciation_total':depreciation_total,
             'operating_expenses_total':operating_expenses_total,
             'revenue_total':revenue_total,
             'gross_profit':gross_profit,
             'net_profit_before_tax':net_profit_before_tax,
             'net_profit_after_tax':net_profit_after_tax,
             'tax_amount':tax_amount,

             # Statement of Changes in Equity
             'retained_earnings':retained_earnings,
             'total_soce':total_soce,

             # Shareholders
             'sh_name_1':sh_name_1,
             'sh_nat_1':sh_nat_1,
             'sh_shares_1':sh_shares_1,
             'sh_value_1':sh_value_1,
             'sh_total_1':sh_total_1,
             'sh_name_2':sh_name_2,
             'sh_nat_2':sh_nat_2,
             'sh_shares_2':sh_shares_2,
             'sh_value_2':sh_value_2,
             'sh_total_2':sh_total_2,
             'sh_name_3':sh_name_3,
             'sh_nat_3':sh_nat_3,
             'sh_shares_3':sh_shares_3,
             'sh_value_3':sh_value_3,
             'sh_total_3':sh_total_3,
            }



    def action_print_account_report_lines(self):
        """Generate and display report"""
        self.ensure_one()

        # report_data = self._get_report_data()
        # You can now pass `report_data` to your Word/PDF renderer

        return {
            'type': 'ir.actions.act_url',
            'url': f'/audit_report/view/{self.id}',
            'target': 'new',
        } 

from odoo import http, fields
from odoo.http import request
from odoo.exceptions import ValidationError
from jinja2 import Environment, FileSystemLoader
from functools import lru_cache
from datetime import datetime, timezone
from io import BytesIO
import json
import html as html_lib
import os
import re
import logging
import time
import xml.etree.ElementTree as ET
from urllib.parse import quote_plus
from zipfile import ZipFile, ZIP_DEFLATED

_logger = logging.getLogger(__name__)


@lru_cache(maxsize=8)
def _get_cached_template_env(templates_path):
    env = Environment(loader=FileSystemLoader(templates_path))
    default_format = env.filters.get('format')

    def _fallback_format(fmt, *args, **kwargs):
        if default_format:
            return default_format(fmt, *args, **kwargs)
        return fmt % args

    def format_filter(fmt, *args, **kwargs):
        # Ensure consistent accounting formatting:
        # - thousands separators (12,345.67)
        # - negatives in parentheses ((12,345.67))
        # Applies to printf-style float formats like "%.2f", "%.0f", etc.
        if isinstance(fmt, str) and args:
            match = re.fullmatch(r"%\.(\d+)f", fmt)
        else:
            match = None
        if match and args:
            decimals = 0
            value = args[0] or 0.0
            try:
                number = float(value)
            except (TypeError, ValueError):
                return _fallback_format(fmt, *args, **kwargs)
            rounded_number = round(number, decimals)
            if rounded_number == 0:
                return "-"
            if rounded_number < 0:
                return f"({abs(rounded_number):,.{decimals}f})"
            return f"{rounded_number:,.{decimals}f}"
        return _fallback_format(fmt, *args, **kwargs)

    def format_percent(fmt, *args, **kwargs):
        """Format percentages using the exact precision requested by fmt."""
        if isinstance(fmt, str) and args:
            match = re.fullmatch(r"%\.(\d+)f", fmt)
        else:
            match = None
        if match and args:
            decimals = int(match.group(1))
            value = args[0] or 0.0
            try:
                number = float(value)
            except (TypeError, ValueError):
                return _fallback_format(fmt, *args, **kwargs)
            formatted = f"{abs(number):,.{decimals}f}"
            if number < 0:
                return f"({formatted})"
            return formatted
        return _fallback_format(fmt, *args, **kwargs)

    def running_case_filter(value):
        """Convert headings/labels to sentence case while keeping acronyms (VAT/IFRS/UAE/ROU/etc)."""
        if value is None:
            return ''
        text = str(value).strip()
        if not text:
            return ''
        # Normalize ampersands in labels (e.g., "Revenue & other income" -> "Revenue and other income").
        text = re.sub(r'\s*&\s*', ' and ', text)
        text = re.sub(r'\s{2,}', ' ', text).strip()

        parts = re.split(r'(\s+)', text)
        out = []
        for part in parts:
            if not part or part.isspace():
                out.append(part)
                continue
            token = part
            # Keep acronyms and codes (all-caps), and anything containing digits.
            if token.isupper() or any(ch.isdigit() for ch in token):
                out.append(token)
            else:
                out.append(token.lower())

        # Capitalize the first alphabetic character (if the first token isn't an acronym).
        for i, part in enumerate(out):
            if not part or part.isspace():
                continue
            if part.isupper():  # acronym in first position
                break
            for j, ch in enumerate(part):
                if ch.isalpha():
                    out[i] = part[:j] + ch.upper() + part[j + 1:]
                    break
            break
        return ''.join(out)

    env.filters['format'] = format_filter
    env.filters['format_percent'] = format_percent
    env.filters['rcase'] = running_case_filter
    return env


@lru_cache(maxsize=32)
def _get_cached_text_file(path, mtime):
    with open(path, 'r', encoding='utf-8') as file_obj:
        return file_obj.read()


class AuditReportController(http.Controller):
    _DMCC_FREEZONE_NAME = 'Dubai Multi Commodities Centre Free Zone'

    def _is_dmcc_summary_enabled(self, report):
        return (getattr(report.company_id, 'free_zone', '') or '') == self._DMCC_FREEZONE_NAME

    def _module_path(self):
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def _templates_path(self):
        return os.path.join(self._module_path(), 'templates')

    def _css_path(self):
        return os.path.join(self._templates_path(), 'audit_report_style.css')

    def _lor_template_path(self):
        return os.path.join(self._templates_path(), 'LOR.html')

    def _lor_css_path(self):
        return os.path.join(self._templates_path(), 'LOR.css')

    def _get_template_env(self, templates_path=None):
        return _get_cached_template_env(templates_path or self._templates_path())

    def _get_cached_css_content(self, css_path=None):
        path = css_path or self._css_path()
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            return ''
        try:
            return _get_cached_text_file(path, mtime)
        except OSError:
            return ''

    def _get_cached_lor_template_content(self, lor_template_path=None):
        path = lor_template_path or self._lor_template_path()
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            return ''
        try:
            return _get_cached_text_file(path, mtime)
        except OSError:
            return ''

    def _get_cached_lor_css_content(self, lor_css_path=None):
        path = lor_css_path or self._lor_css_path()
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            return ''
        try:
            return _get_cached_text_file(path, mtime)
        except OSError:
            return ''

    @staticmethod
    def _get_lor_manager_name(report):
        company = getattr(report, 'company_id', False)
        company_shareholder_1 = (getattr(company, 'shareholder_1', '') or '').strip()
        if company_shareholder_1:
            return company_shareholder_1

        report_shareholder_1 = (getattr(report, 'shareholder_1', '') or '').strip()
        if report_shareholder_1:
            return report_shareholder_1
        return (getattr(report.env.user, 'name', '') or '').strip()

    @staticmethod
    def _get_lor_signature_date(report):
        signature_date_mode = (getattr(report, 'signature_date_mode', '') or 'today').strip().lower()
        if signature_date_mode == 'manual' and getattr(report, 'signature_manual_date', False):
            return fields.Date.to_date(report.signature_manual_date)
        if signature_date_mode == 'report_end' and getattr(report, 'date_end', False):
            return fields.Date.to_date(report.date_end)
        return fields.Date.context_today(report)

    def _build_lor_placeholder_values(self, report):
        signature_date = self._get_lor_signature_date(report)
        end_date = fields.Date.to_date(report.date_end) if report.date_end else False
        company = report.company_id
        free_zone_value = (
            getattr(report, 'company_free_zone', False)
            or getattr(company, 'free_zone', False)
            or ''
        )
        free_zone_selection = dict(company._fields['free_zone'].selection or [])
        free_zone_city = free_zone_selection.get(free_zone_value, free_zone_value)

        return {
            'COMPANYNAME': (company.name or '').strip(),
            'FREEZONECITY': (free_zone_city or '').strip(),
            'ENDDATE': end_date.strftime('%d %B %Y') if end_date else '',
            'MANAGER': self._get_lor_manager_name(report),
            'DATE': signature_date.strftime('%d/%m/%Y') if signature_date else '',
        }

    @staticmethod
    def _replace_lor_placeholders(template_text, placeholder_values):
        if not template_text:
            return ''

        values = placeholder_values or {}
        placeholder_pattern = re.compile(r'<<\s*([^<>]+?)\s*>>')

        def _replace(match):
            normalized_key = re.sub(r'\s+', '', match.group(1) or '').upper()
            value = values.get(normalized_key)
            if value is None:
                return match.group(0)
            return str(value)

        return placeholder_pattern.sub(_replace, template_text)

    def _render_lor_template_content(self, placeholder_values, extra_main_items=None):
        values = placeholder_values or {}
        context = {
            'company_name': values.get('COMPANYNAME', ''),
            'free_zone_city': values.get('FREEZONECITY', ''),
            'end_date': values.get('ENDDATE', ''),
            'manager_name': values.get('MANAGER', ''),
            'signature_date': values.get('DATE', ''),
            'placeholders': values,
        }

        rendered = self._get_cached_lor_template_content()
        try:
            env = self._get_template_env(self._templates_path())
            template = env.get_template('LOR.html')
            rendered = template.render(**context)
        except Exception:
            # Keep backward compatibility with plain-text placeholder templates.
            rendered = rendered or ''
        resolved_content = self._replace_lor_placeholders(rendered, values)
        return self._inject_lor_extra_main_items(
            resolved_content,
            extra_main_items,
        )

    @staticmethod
    def _normalize_lor_extra_items(extra_items):
        normalized = []
        for item in extra_items or []:
            item_text = str(item or '').strip()
            if item_text:
                normalized.append(item_text)
        return normalized

    def _inject_lor_extra_main_items(self, rendered_lor_html, extra_items):
        item_texts = self._normalize_lor_extra_items(extra_items)
        if not item_texts:
            return rendered_lor_html or ''

        raw_html = (rendered_lor_html or '').strip()
        if not raw_html:
            return rendered_lor_html or ''

        try:
            root = ET.fromstring(raw_html)
        except ET.ParseError:
            return rendered_lor_html or ''

        target_list = None
        for node in root.iter():
            if self._xml_tag_name(node) != 'ol':
                continue
            class_tokens = self._node_class_tokens(node)
            if 'list-level-0' in class_tokens:
                target_list = node
                break
            if target_list is None:
                target_list = node

        if target_list is None:
            return rendered_lor_html or ''

        for item_text in item_texts:
            li_node = ET.Element('li')
            li_node.text = item_text
            target_list.append(li_node)

        return ET.tostring(root, encoding='unicode')

    @staticmethod
    def _xml_tag_name(node):
        raw_tag = getattr(node, 'tag', '') or ''
        if '}' in raw_tag:
            return raw_tag.split('}', 1)[1].lower()
        return raw_tag.lower()

    @staticmethod
    def _node_class_tokens(node):
        class_attr = ((getattr(node, 'attrib', {}) or {}).get('class') or '').strip()
        if not class_attr:
            return set()
        return {token.strip().lower() for token in class_attr.split() if token.strip()}

    def _collect_lor_inline_runs(self, node, inherited_bold=False, skip_nested_lists=False):
        runs = []
        node_tag = self._xml_tag_name(node)
        is_bold = inherited_bold or node_tag in ('b', 'strong')

        if getattr(node, 'text', None):
            runs.append((node.text, is_bold))

        for child in list(node):
            child_tag = self._xml_tag_name(child)
            if skip_nested_lists and child_tag in ('ol', 'ul'):
                if getattr(child, 'tail', None):
                    runs.append((child.tail, is_bold))
                continue
            if child_tag == 'br':
                runs.append((' ', is_bold))
                if getattr(child, 'tail', None):
                    runs.append((child.tail, is_bold))
                continue

            runs.extend(
                self._collect_lor_inline_runs(
                    child,
                    inherited_bold=is_bold,
                    skip_nested_lists=False,
                )
            )
            if getattr(child, 'tail', None):
                runs.append((child.tail, is_bold))

        return runs

    @staticmethod
    def _runs_to_markdown_text(runs):
        chunks = []
        for text_value, is_bold in runs or []:
            if text_value is None:
                continue
            normalized = text_value.replace('\n', ' ').replace('\t', ' ')
            normalized = re.sub(r'\s+', ' ', normalized)
            if not normalized.strip():
                if chunks and not chunks[-1].endswith(' '):
                    chunks.append(' ')
                continue
            if is_bold:
                chunks.append(f'**{normalized}**')
            else:
                chunks.append(normalized)

        output = ''.join(chunks)
        output = re.sub(r'\s+([,.;:!?])', r'\1', output)
        output = re.sub(r'\(\s+', '(', output)
        output = re.sub(r'\s+\)', ')', output)
        return output.strip()

    def _append_lor_list_blocks(self, list_node, blocks, level=0):
        list_items = [
            child for child in list(list_node)
            if self._xml_tag_name(child) == 'li'
        ]
        last_index = len(list_items) - 1
        for item_index, child in enumerate(list_items):
            is_last_item = item_index == last_index

            line_text = self._runs_to_markdown_text(
                self._collect_lor_inline_runs(child, skip_nested_lists=True)
            )
            effective_level = int(level) if level is not None else 0
            style_key = 'list_item_level_0'
            if effective_level > 0:
                style_key = 'list_item_level_1_last' if is_last_item else 'list_item_level_1'
            blocks.append({
                'text': line_text,
                'title_style': False,
                'list_level': effective_level,
                'style_key': style_key,
                'preserve_empty': False,
            })

            for nested in list(child):
                nested_tag = self._xml_tag_name(nested)
                if nested_tag in ('ol', 'ul'):
                    self._append_lor_list_blocks(nested, blocks, level=level + 1)

    def _extract_lor_blocks_from_html(self, html_content):
        wrapped_html = (html_content or '').strip()
        if not wrapped_html:
            return []

        try:
            root = ET.fromstring(wrapped_html)
        except ET.ParseError:
            root = ET.fromstring(f'<root>{wrapped_html}</root>')

        blocks = []
        class_style_map = (
            ('address-line', 'address_line'),
            ('salutation', 'salutation'),
            ('intro', 'intro'),
            ('closing', 'closing'),
            ('signature-line', 'signature_line'),
            ('date-line', 'date_line'),
            ('spacer-lg', 'spacer_lg'),
            ('spacer-sm', 'spacer_sm'),
            ('paragraph', 'paragraph'),
        )

        def walk(node):
            for child in list(node):
                tag = self._xml_tag_name(child)
                if tag in ('h1', 'h2'):
                    text = self._runs_to_markdown_text(self._collect_lor_inline_runs(child))
                    blocks.append({
                        'text': text,
                        'title_style': True,
                        'list_level': None,
                        'style_key': 'title',
                        'preserve_empty': False,
                    })
                    continue
                if tag == 'p':
                    text = self._runs_to_markdown_text(self._collect_lor_inline_runs(child))
                    style_key = 'paragraph'
                    class_tokens = self._node_class_tokens(child)
                    for class_name, mapped_style in class_style_map:
                        if class_name in class_tokens:
                            style_key = mapped_style
                            break
                    preserve_empty = style_key in ('spacer_lg', 'spacer_sm') and not text
                    blocks.append({
                        'text': text,
                        'title_style': False,
                        'list_level': None,
                        'style_key': style_key,
                        'preserve_empty': preserve_empty,
                    })
                    continue
                if tag in ('ol', 'ul'):
                    self._append_lor_list_blocks(child, blocks, level=0)
                    continue
                walk(child)

        walk(root)
        return blocks

    def _extract_lor_blocks_from_text(self, body_text):
        lines = (body_text or '').split('\n')
        if not lines:
            return []

        blocks = []
        for line in lines:
            is_main_title = line.strip().upper() == 'AUDIT REPRESENTATION LETTER'
            top_level_match = re.match(r'^\s*\d+\.\s+(.*)$', line)
            sub_level_match = re.match(r'^\s*[A-Za-z]\.\s+(.*)$', line)

            list_level = None
            line_content = line
            if top_level_match:
                list_level = 0
                line_content = top_level_match.group(1)
            elif sub_level_match:
                list_level = 1
                line_content = sub_level_match.group(1)

            style_key = 'paragraph'
            if list_level == 0:
                style_key = 'list_item_level_0'
            elif list_level == 1:
                style_key = 'list_item_level_1'
            elif is_main_title:
                style_key = 'title'

            blocks.append({
                'text': line_content,
                'title_style': is_main_title,
                'list_level': list_level,
                'style_key': style_key,
                'preserve_empty': False,
            })
        return blocks

    def _extract_lor_blocks(self, body_content):
        raw = (body_content or '').strip()
        is_structured_html = bool(re.search(r'<\s*(html|body|h1|p|ol|li)\b', raw, flags=re.IGNORECASE))
        if is_structured_html:
            try:
                return self._extract_lor_blocks_from_html(raw)
            except Exception:
                pass
        return self._extract_lor_blocks_from_text(body_content)

    @staticmethod
    def _default_lor_docx_styles():
        return {
            'document': {
                'page_width': 12240,
                'page_height': 15840,
                'margin_top': 1440,
                'margin_right': 1440,
                'margin_bottom': 1440,
                'margin_left': 1440,
                'header': 720,
                'footer': 720,
                'gutter': 0,
                'column_space': 720,
                'line_pitch': 360,
                'default_header_text': 'ON COMPANY LETTERHEAD',
                'first_page_header_text': '',
                'header_font_family': 'Times New Roman',
                'header_font_size_half_points': 22,
                'header_bold': False,
                'header_text_align': 'center',
                'header_spacing_before': 0,
                'header_spacing_after': 120,
            },
            'body': {
                'font_family': 'Times New Roman',
                'font_size_half_points': 24,
                'bold': False,
                'line_height': 240,
            },
            'paragraph': {
                'text_align': 'left',
                'spacing_before': 0,
                'spacing_after': 80,
                'line_height': 240,
            },
            'address_line': {
                'text_align': 'left',
                'spacing_before': 0,
                'spacing_after': 0,
                'line_height': 240,
            },
            'salutation': {
                'text_align': 'left',
                'spacing_before': 120,
                'spacing_after': 120,
                'line_height': 240,
            },
            'intro': {
                'text_align': 'both',
                'spacing_before': 0,
                'spacing_after': 120,
                'line_height': 240,
            },
            'closing': {
                'text_align': 'left',
                'spacing_before': 120,
                'spacing_after': 0,
                'line_height': 240,
            },
            'signature_line': {
                'text_align': 'left',
                'spacing_before': 0,
                'spacing_after': 0,
                'line_height': 240,
            },
            'date_line': {
                'text_align': 'left',
                'spacing_before': 40,
                'spacing_after': 0,
                'line_height': 240,
            },
            'spacer_sm': {
                'spacing_before': 0,
                'spacing_after': 120,
                'line_height': 240,
            },
            'spacer_lg': {
                'spacing_before': 0,
                'spacing_after': 180,
                'line_height': 240,
            },
            'list_item_level_0': {
                'text_align': 'left',
                'spacing_before': 0,
                'spacing_after': 80,
                'line_height': 240,
            },
            'list_item_level_1': {
                'text_align': 'left',
                'spacing_before': 0,
                'spacing_after': 60,
                'line_height': 240,
            },
            'list_item_level_1_last': {
                'text_align': 'left',
                'spacing_before': 0,
                'spacing_after': 240,
                'line_height': 240,
            },
            'title': {
                'font_family': 'Times New Roman',
                'font_size_half_points': 24,
                'bold': True,
                'text_align': 'center',
                'spacing_before': 0,
                'spacing_after': 320,
                'line_height': 240,
            },
            'list_level_0': {
                'indent_left': 720,
                'indent_hanging': 360,
                'restart': False,
            },
            'list_level_1': {
                'indent_left': 1440,
                'indent_hanging': 360,
                'restart': True,
            },
        }

    @staticmethod
    def _parse_css_length_to_twips(value, default):
        raw = (value or '').strip().lower()
        if not raw:
            return int(default)
        match = re.fullmatch(r'(-?\d+(?:\.\d+)?)([a-z]*)', raw)
        if not match:
            return int(default)
        number = float(match.group(1))
        unit = match.group(2) or 'pt'
        unit_factors = {
            'twip': 1.0,
            'twips': 1.0,
            'pt': 20.0,
            'px': 15.0,
            'in': 1440.0,
            'cm': 566.929,
            'mm': 56.6929,
        }
        factor = unit_factors.get(unit)
        if factor is None:
            return int(default)
        return int(round(number * factor))

    @staticmethod
    def _parse_css_length_to_half_points(value, default):
        raw = (value or '').strip().lower()
        if not raw:
            return int(default)
        match = re.fullmatch(r'(-?\d+(?:\.\d+)?)([a-z]*)', raw)
        if not match:
            return int(default)
        number = float(match.group(1))
        unit = match.group(2) or 'pt'
        if unit in ('', 'pt'):
            return int(round(number * 2.0))
        if unit == 'px':
            return int(round(number * 1.5))
        if unit in ('twip', 'twips'):
            return int(round(number / 10.0))
        return int(default)

    @staticmethod
    def _parse_css_bool(value, default=False):
        normalized = (value or '').strip().lower()
        if normalized in ('1', 'true', 'yes', 'on', 'bold'):
            return True
        if normalized in ('0', 'false', 'no', 'off', 'normal'):
            return False
        return bool(default)

    @staticmethod
    def _normalize_docx_alignment(value, default='left'):
        normalized = (value or '').strip().lower()
        if normalized in ('left', 'center', 'right', 'both'):
            return normalized
        if normalized == 'justify':
            return 'both'
        return default

    @staticmethod
    def _parse_css_string(value, default=''):
        raw = (value or '').strip()
        if not raw:
            return default
        if (raw.startswith('"') and raw.endswith('"')) or (raw.startswith("'") and raw.endswith("'")):
            return raw[1:-1]
        return raw

    def _parse_lor_css_styles(self, css_text):
        style_map = {
            name: dict(values)
            for name, values in self._default_lor_docx_styles().items()
        }
        if not css_text:
            return style_map

        cleaned = re.sub(r'/\*.*?\*/', '', css_text, flags=re.DOTALL)
        selector_map = {
            'page': 'document',
            '@page': 'document',
            '.lor-page': 'document',
            'body': 'body',
            '.title': 'title',
            '.lor-title': 'title',
            'title': 'title',
            'p': 'paragraph',
            '.paragraph': 'paragraph',
            '.lor-paragraph': 'paragraph',
            '.address-line': 'address_line',
            '.salutation': 'salutation',
            '.intro': 'intro',
            '.closing': 'closing',
            '.signature-line': 'signature_line',
            '.date-line': 'date_line',
            '.spacer-sm': 'spacer_sm',
            '.spacer-lg': 'spacer_lg',
            '.list-level-0': 'list_level_0',
            'list-level-0': 'list_level_0',
            '.list-level-1': 'list_level_1',
            'list-level-1': 'list_level_1',
            '.list-item-0': 'list_item_level_0',
            '.list-item-1': 'list_item_level_1',
            '.list-item-1-last': 'list_item_level_1_last',
            '.list-level-0 li': 'list_item_level_0',
            '.list-level-1 li': 'list_item_level_1',
        }

        for selector_text, declarations in re.findall(r'([^{}]+)\{([^{}]*)\}', cleaned):
            selectors = [item.strip().lower() for item in selector_text.split(',') if item.strip()]
            if not selectors:
                continue
            mapped_targets = [selector_map.get(selector) for selector in selectors]
            mapped_targets = [target for target in mapped_targets if target]
            if not mapped_targets:
                continue

            properties = {}
            for declaration in declarations.split(';'):
                if ':' not in declaration:
                    continue
                key, value = declaration.split(':', 1)
                prop_name = key.strip().lower()
                prop_value = value.strip()
                if prop_name:
                    properties[prop_name] = prop_value
            if not properties:
                continue

            for target in mapped_targets:
                target_style = style_map.get(target)
                if target_style is None:
                    continue
                for prop_name, prop_value in properties.items():
                    if target == 'document':
                        document_prop_map = {
                            'page-width': 'page_width',
                            'page-height': 'page_height',
                            'margin-top': 'margin_top',
                            'margin-right': 'margin_right',
                            'margin-bottom': 'margin_bottom',
                            'margin-left': 'margin_left',
                            'header': 'header',
                            'footer': 'footer',
                            'gutter': 'gutter',
                            'column-space': 'column_space',
                            'line-pitch': 'line_pitch',
                        }
                        if prop_name in ('default-header-text', 'header-text'):
                            target_style['default_header_text'] = self._parse_css_string(
                                prop_value,
                                target_style.get('default_header_text', ''),
                            )
                            continue
                        if prop_name in ('first-page-header-text', 'first-header-text'):
                            target_style['first_page_header_text'] = self._parse_css_string(
                                prop_value,
                                target_style.get('first_page_header_text', ''),
                            )
                            continue
                        if prop_name == 'header-font-family':
                            target_style['header_font_family'] = self._parse_css_string(
                                prop_value,
                                target_style.get('header_font_family', 'Times New Roman'),
                            )
                            continue
                        if prop_name == 'header-font-size':
                            target_style['header_font_size_half_points'] = self._parse_css_length_to_half_points(
                                prop_value,
                                target_style.get('header_font_size_half_points', 22),
                            )
                            continue
                        if prop_name == 'header-font-weight':
                            target_style['header_bold'] = self._parse_css_bool(
                                prop_value,
                                target_style.get('header_bold', False),
                            )
                            continue
                        if prop_name == 'header-text-align':
                            target_style['header_text_align'] = self._normalize_docx_alignment(
                                prop_value,
                                target_style.get('header_text_align', 'center'),
                            )
                            continue
                        if prop_name == 'header-margin-top':
                            target_style['header_spacing_before'] = self._parse_css_length_to_twips(
                                prop_value,
                                target_style.get('header_spacing_before', 0),
                            )
                            continue
                        if prop_name == 'header-margin-bottom':
                            target_style['header_spacing_after'] = self._parse_css_length_to_twips(
                                prop_value,
                                target_style.get('header_spacing_after', 120),
                            )
                            continue
                        mapped_key = document_prop_map.get(prop_name)
                        if mapped_key:
                            target_style[mapped_key] = self._parse_css_length_to_twips(
                                prop_value,
                                target_style.get(mapped_key, 0),
                            )
                        continue

                    if prop_name == 'font-family':
                        target_style['font_family'] = prop_value.strip().strip('"').strip("'")
                    elif prop_name == 'font-size':
                        target_style['font_size_half_points'] = self._parse_css_length_to_half_points(
                            prop_value,
                            target_style.get('font_size_half_points', 24),
                        )
                    elif prop_name == 'font-weight':
                        target_style['bold'] = self._parse_css_bool(
                            prop_value,
                            target_style.get('bold', False),
                        )
                    elif prop_name == 'text-align':
                        target_style['text_align'] = self._normalize_docx_alignment(
                            prop_value,
                            target_style.get('text_align', 'left'),
                        )
                    elif prop_name == 'margin-top':
                        target_style['spacing_before'] = self._parse_css_length_to_twips(
                            prop_value,
                            target_style.get('spacing_before', 0),
                        )
                    elif prop_name == 'margin-bottom':
                        target_style['spacing_after'] = self._parse_css_length_to_twips(
                            prop_value,
                            target_style.get('spacing_after', 0),
                        )
                    elif prop_name == 'line-height':
                        target_style['line_height'] = self._parse_css_length_to_twips(
                            prop_value,
                            target_style.get('line_height', 0),
                        )
                    elif prop_name == 'margin-left':
                        target_style['indent_left'] = self._parse_css_length_to_twips(
                            prop_value,
                            target_style.get('indent_left', 0),
                        )
                    elif prop_name in ('hanging-indent', 'text-indent'):
                        parsed_indent = self._parse_css_length_to_twips(
                            prop_value,
                            target_style.get('indent_hanging', 0),
                        )
                        target_style['indent_hanging'] = abs(parsed_indent)
                    elif prop_name == 'restart':
                        target_style['restart'] = self._parse_css_bool(
                            prop_value,
                            target_style.get('restart', False),
                        )

        return style_map

    @staticmethod
    def _build_docx_run_xml(text_value, font_family='Times New Roman', bold=False, font_size_half_points=24):
        value = '' if text_value is None else str(text_value)
        escaped_text = html_lib.escape(value, quote=False)
        needs_preserve = (
            value.startswith(' ')
            or value.endswith(' ')
            or '  ' in value
        )
        preserve_attr = ' xml:space="preserve"' if needs_preserve else ''
        resolved_font = (font_family or 'Times New Roman').replace('"', '').replace("'", '')
        bold_xml = '<w:b/><w:bCs/>' if bold else ''
        return (
            '<w:r>'
            '<w:rPr>'
            f'<w:rFonts w:ascii="{resolved_font}" w:hAnsi="{resolved_font}" '
            f'w:eastAsia="{resolved_font}" w:cs="{resolved_font}"/>'
            f'{bold_xml}'
            f'<w:sz w:val="{int(font_size_half_points)}"/>'
            f'<w:szCs w:val="{int(font_size_half_points)}"/>'
            '</w:rPr>'
            f'<w:t{preserve_attr}>{escaped_text}</w:t>'
            '</w:r>'
        )

    def _build_docx_paragraph_xml(
        self,
        text_line,
        style_map,
        title_style=False,
        list_level=None,
        style_key=None,
        preserve_empty=False,
    ):
        text_value = '' if text_line is None else str(text_line)
        if not text_value and preserve_empty:
            text_value = ' '
        if not text_value:
            return '<w:p/>'

        body_style = style_map.get('body', {})
        paragraph_style = dict(style_map.get('paragraph', {}))
        style_overrides = style_map.get(style_key) if style_key else None
        if isinstance(style_overrides, dict):
            paragraph_style.update(style_overrides)
        title_block_style = style_map.get('title', {})

        run_style = {
            'font_family': body_style.get('font_family', 'Times New Roman'),
            'font_size_half_points': int(body_style.get('font_size_half_points', 24)),
            'bold': bool(body_style.get('bold', False)),
        }
        for key in ('font_family', 'font_size_half_points', 'bold'):
            if key in paragraph_style:
                run_style[key] = paragraph_style[key]
        if title_style:
            for key in ('font_family', 'font_size_half_points', 'bold'):
                if key in title_block_style:
                    run_style[key] = title_block_style[key]

        effective_paragraph_style = dict(paragraph_style)
        if title_style:
            effective_paragraph_style.update(title_block_style)

        effective_align = self._normalize_docx_alignment(
            effective_paragraph_style.get('text_align', 'left'),
            default='left',
        )
        spacing_before = int(effective_paragraph_style.get('spacing_before', 0))
        spacing_after = int(effective_paragraph_style.get('spacing_after', 0))
        line_height = int(effective_paragraph_style.get('line_height', body_style.get('line_height', 0)))

        paragraph_props = []
        paragraph_props.append(f'<w:jc w:val="{effective_align}"/>')
        spacing_attrs = [
            f'w:before="{spacing_before}"',
            f'w:after="{spacing_after}"',
        ]
        if line_height:
            spacing_attrs.append(f'w:line="{line_height}"')
            spacing_attrs.append('w:lineRule="auto"')
        paragraph_props.append(f"<w:spacing {' '.join(spacing_attrs)}/>")

        if list_level is not None:
            list_style = style_map.get(f'list_level_{int(list_level)}', {})
            indent_left = int(list_style.get('indent_left', 0))
            indent_hanging = int(list_style.get('indent_hanging', 0))
            paragraph_props.append(
                '<w:numPr>'
                f'<w:ilvl w:val="{int(list_level)}"/>'
                '<w:numId w:val="1"/>'
                '</w:numPr>'
            )
            paragraph_props.append(
                f'<w:ind w:left="{indent_left}" w:hanging="{indent_hanging}"/>'
            )

        ppr_xml = f"<w:pPr>{''.join(paragraph_props)}</w:pPr>" if paragraph_props else ''
        runs_xml = self._build_docx_runs_xml(text_value, run_style)
        return (
            '<w:p>'
            f'{ppr_xml}'
            f'{runs_xml}'
            '</w:p>'
        )

    def _build_docx_runs_xml(self, text_value, run_style):
        # Allow inline bold markers in template text: **bold part**
        segments = re.split(r'(\*\*.*?\*\*)', text_value or '')
        run_chunks = []
        for segment in segments:
            if not segment:
                continue
            is_bold_segment = segment.startswith('**') and segment.endswith('**') and len(segment) >= 4
            if is_bold_segment:
                chunk_text = segment[2:-2]
                if not chunk_text:
                    continue
                bold_style = dict(run_style)
                bold_style['bold'] = True
                run_chunks.append(self._build_docx_run_xml(chunk_text, **bold_style))
            else:
                run_chunks.append(self._build_docx_run_xml(segment, **run_style))
        return ''.join(run_chunks) if run_chunks else self._build_docx_run_xml(text_value, **run_style)

    def _build_docx_header_xml(self, header_text, document_style, body_style):
        run_style = {
            'font_family': document_style.get('header_font_family', body_style.get('font_family', 'Times New Roman')),
            'font_size_half_points': int(
                document_style.get('header_font_size_half_points', body_style.get('font_size_half_points', 24))
            ),
            'bold': bool(document_style.get('header_bold', False)),
        }
        align = self._normalize_docx_alignment(
            document_style.get('header_text_align', 'center'),
            default='center',
        )
        spacing_before = int(document_style.get('header_spacing_before', 0))
        spacing_after = int(document_style.get('header_spacing_after', 120))
        header_text_value = str(header_text or '')

        spacing_xml = (
            f'<w:spacing w:before="{spacing_before}" w:after="{spacing_after}"/>'
        )

        if header_text_value:
            runs_xml = self._build_docx_runs_xml(header_text_value, run_style)
            paragraph_xml = (
                '<w:p>'
                '<w:pPr>'
                f'<w:jc w:val="{align}"/>'
                f'{spacing_xml}'
                '</w:pPr>'
                f'{runs_xml}'
                '</w:p>'
            )
        else:
            paragraph_xml = '<w:p/>'

        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            f'{paragraph_xml}'
            '</w:hdr>'
        )

    def _build_docx_from_text(self, body_text, title='Audit Representation Letter', lor_styles=None):
        blocks = self._extract_lor_blocks(body_text)
        if not blocks:
            blocks = [{'text': '', 'title_style': False, 'list_level': None}]
        style_map = (
            {
                name: dict(values)
                for name, values in (lor_styles or self._default_lor_docx_styles()).items()
            }
        )

        paragraph_xml_parts = []
        for block in blocks:
            paragraph_xml_parts.append(
                self._build_docx_paragraph_xml(
                    block.get('text', ''),
                    style_map,
                    title_style=bool(block.get('title_style')),
                    list_level=block.get('list_level'),
                    style_key=block.get('style_key'),
                    preserve_empty=bool(block.get('preserve_empty', False)),
                )
            )
        paragraph_xml = ''.join(paragraph_xml_parts)
        document_style = style_map.get('document', {})
        default_header_text = str(document_style.get('default_header_text', '') or '')
        first_page_header_text = str(document_style.get('first_page_header_text', '') or '')
        header_enabled = bool(default_header_text or first_page_header_text)

        section_header_refs = ''
        if header_enabled:
            section_header_refs = (
                '<w:headerReference w:type="default" r:id="rId2"/>'
                '<w:headerReference w:type="first" r:id="rId3"/>'
                '<w:titlePg/>'
            )

        document_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<w:body>'
            f'{paragraph_xml}'
            '<w:sectPr>'
            f'{section_header_refs}'
            f'<w:pgSz w:w="{int(document_style.get("page_width", 12240))}" '
            f'w:h="{int(document_style.get("page_height", 15840))}"/>'
            f'<w:pgMar w:top="{int(document_style.get("margin_top", 1440))}" '
            f'w:right="{int(document_style.get("margin_right", 1440))}" '
            f'w:bottom="{int(document_style.get("margin_bottom", 1440))}" '
            f'w:left="{int(document_style.get("margin_left", 1440))}" '
            f'w:header="{int(document_style.get("header", 720))}" '
            f'w:footer="{int(document_style.get("footer", 720))}" '
            f'w:gutter="{int(document_style.get("gutter", 0))}"/>'
            f'<w:cols w:space="{int(document_style.get("column_space", 720))}"/>'
            f'<w:docGrid w:linePitch="{int(document_style.get("line_pitch", 360))}"/>'
            '</w:sectPr>'
            '</w:body>'
            '</w:document>'
        )

        generated_on = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
        escaped_title = html_lib.escape(title or 'Document', quote=False)
        core_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties '
            'xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" '
            'xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            f'<dc:title>{escaped_title}</dc:title>'
            '<dc:creator>Odoo Audit Report</dc:creator>'
            '<cp:lastModifiedBy>Odoo Audit Report</cp:lastModifiedBy>'
            f'<dcterms:created xsi:type="dcterms:W3CDTF">{generated_on}</dcterms:created>'
            f'<dcterms:modified xsi:type="dcterms:W3CDTF">{generated_on}</dcterms:modified>'
            '</cp:coreProperties>'
        )

        app_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
            'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
            '<Application>Odoo Audit Report</Application>'
            '</Properties>'
        )

        rels_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
            'Target="word/document.xml"/>'
            '<Relationship Id="rId2" '
            'Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" '
            'Target="docProps/core.xml"/>'
            '<Relationship Id="rId3" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" '
            'Target="docProps/app.xml"/>'
            '</Relationships>'
        )

        body_style = style_map.get('body', {})
        base_font = (body_style.get('font_family', 'Times New Roman') or 'Times New Roman')
        base_font = str(base_font).replace('"', '').replace("'", '')
        base_font_size = int(body_style.get('font_size_half_points', 24))
        list_level_0_style = style_map.get('list_level_0', {})
        list_level_1_style = style_map.get('list_level_1', {})
        list_0_indent_left = int(list_level_0_style.get('indent_left', 720))
        list_0_indent_hanging = int(list_level_0_style.get('indent_hanging', 360))
        list_1_indent_left = int(list_level_1_style.get('indent_left', 1440))
        list_1_indent_hanging = int(list_level_1_style.get('indent_hanging', 360))
        list_1_restart = bool(list_level_1_style.get('restart', True))
        list_1_restart_xml = '<w:lvlRestart w:val="1"/>' if list_1_restart else ''
        default_header_xml = ''
        first_page_header_xml = ''
        document_rels_parts = [
            '<Relationship Id="rId1" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" '
            'Target="numbering.xml"/>'
        ]
        if header_enabled:
            default_header_xml = self._build_docx_header_xml(
                default_header_text,
                document_style,
                body_style,
            )
            first_page_header_xml = self._build_docx_header_xml(
                first_page_header_text,
                document_style,
                body_style,
            )
            document_rels_parts.extend([
                '<Relationship Id="rId2" '
                'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" '
                'Target="header1.xml"/>',
                '<Relationship Id="rId3" '
                'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" '
                'Target="header2.xml"/>',
            ])

        document_rels_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            f'{"".join(document_rels_parts)}'
            '</Relationships>'
        )

        numbering_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            '<w:abstractNum w:abstractNumId="0">'
            '<w:multiLevelType w:val="multilevel"/>'
            '<w:lvl w:ilvl="0">'
            '<w:start w:val="1"/>'
            '<w:numFmt w:val="decimal"/>'
            '<w:lvlText w:val="%1."/>'
            '<w:lvlJc w:val="left"/>'
            f'<w:pPr><w:ind w:left="{list_0_indent_left}" w:hanging="{list_0_indent_hanging}"/></w:pPr>'
            '<w:rPr>'
            f'<w:rFonts w:ascii="{base_font}" w:hAnsi="{base_font}" '
            f'w:eastAsia="{base_font}" w:cs="{base_font}"/>'
            f'<w:sz w:val="{base_font_size}"/><w:szCs w:val="{base_font_size}"/>'
            '</w:rPr>'
            '</w:lvl>'
            '<w:lvl w:ilvl="1">'
            '<w:start w:val="1"/>'
            f'{list_1_restart_xml}'
            '<w:numFmt w:val="lowerLetter"/>'
            '<w:lvlText w:val="%2."/>'
            '<w:lvlJc w:val="left"/>'
            f'<w:pPr><w:ind w:left="{list_1_indent_left}" w:hanging="{list_1_indent_hanging}"/></w:pPr>'
            '<w:rPr>'
            f'<w:rFonts w:ascii="{base_font}" w:hAnsi="{base_font}" '
            f'w:eastAsia="{base_font}" w:cs="{base_font}"/>'
            f'<w:sz w:val="{base_font_size}"/><w:szCs w:val="{base_font_size}"/>'
            '</w:rPr>'
            '</w:lvl>'
            '</w:abstractNum>'
            '<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>'
            '</w:numbering>'
        )

        header_overrides_xml = ''
        if header_enabled:
            header_overrides_xml = (
                '<Override PartName="/word/header1.xml" '
                'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>'
                '<Override PartName="/word/header2.xml" '
                'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>'
            )

        content_types_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/word/document.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
            '<Override PartName="/word/numbering.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>'
            f'{header_overrides_xml}'
            '<Override PartName="/docProps/core.xml" '
            'ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            '<Override PartName="/docProps/app.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            '</Types>'
        )

        output_buffer = BytesIO()
        with ZipFile(output_buffer, mode='w', compression=ZIP_DEFLATED) as archive:
            archive.writestr('[Content_Types].xml', content_types_xml)
            archive.writestr('_rels/.rels', rels_xml)
            archive.writestr('docProps/app.xml', app_xml)
            archive.writestr('docProps/core.xml', core_xml)
            archive.writestr('word/document.xml', document_xml)
            archive.writestr('word/_rels/document.xml.rels', document_rels_xml)
            archive.writestr('word/numbering.xml', numbering_xml)
            if header_enabled:
                archive.writestr('word/header1.xml', default_header_xml)
                archive.writestr('word/header2.xml', first_page_header_xml)
        return output_buffer.getvalue()

    @staticmethod
    def _build_lor_filename(report):
        company_name = (getattr(report.company_id, 'name', '') or '').strip()
        safe_company_name = re.sub(r'[^A-Za-z0-9]+', '_', company_name).strip('_')
        if not safe_company_name:
            safe_company_name = f'company_{report.id}'
        return f'Audit_Representation_Letter_{safe_company_name}.docx'

    @staticmethod
    def _apply_usd_statement_overrides(report, html_content):
        if not html_content:
            return html_content
        usd_text_mode_enabled = bool(
            getattr(report, 'usd_statement', False)
            or getattr(report, 'tb_convert_balances_to_usd', False)
            or getattr(report, 'replace_aed_text_with_usd', False)
        )
        if not usd_text_mode_enabled:
            return html_content

        updated_html = html_content
        basis_replacement = (
            "These financial statements have been presented in United States Dollar (USD) "
            "which is the presentation currency of the Entity. The functional currency of the "
            "Entity is United Arab Emirates Dirhams (A&#69;D). Items included in these financial "
            "statements are measured using the currency of the primary economic environment in "
            "which the Entity operates (&quot;the functional currency&quot;)."
        )
        updated_html = re.sub(
            r'These financial statements have been presented in United Arab Emirates\s+Dirhams '
            r'\(AED\)\s+which is the functional and presentation currency of the\s+Entity\.\s+'
            r'Items included in these financial statements are measured using\s+the currency of '
            r'the primary economic environment in which the Entity\s+operates '
            r'\((?:&quot;|")the functional currency(?:&quot;|")\)\.',
            basis_replacement,
            updated_html,
            flags=re.IGNORECASE | re.DOTALL,
        )

        ct_replacement = (
            "These financial statements are presented in United States Dollars (USD), while the "
            "functional currency of the Entity is UAE Dirhams (UAE). Foreign currency "
            "transactions are initially recorded, in the functional currency by applying to the "
            "foreign currency amount the exchange rate between the functional currency and the "
            "foreign currency on the date of the transaction. At the end of the reporting period, "
            "foreign currency monetary items are reported using the closing rate. Exchange "
            "differences arising on the settlement of monetary items at rates different from those "
            "at which they were initially recorded during the reporting period or reported in "
            "previous financial statements are recognized as income or expense in the year in "
            "which they arise."
        )
        updated_html = re.sub(
            (
                r'(<p[^>]*>\s*)On December 09, 2022, the UAE\.\s*Ministry of Finance '
                r'\(MoF\) released Federal.*?(</p>)'
            ),
            lambda match: f"{match.group(1)}{ct_replacement}{match.group(2)}",
            updated_html,
            flags=re.IGNORECASE | re.DOTALL,
        )

        risk_replacement = (
            '<p class="gap">The Entity does not have any significant exposure to currency risk, '
            'as most of its assets and liabilities are denominated in United States Dollar. There '
            'are no assets and liabilities which expose it to interest rate risk and other price '
            'risks.</p>'
        )
        updated_html = re.sub(
            (
                r'<p class="gap">\s*The Entity monitors and manages the financial risks relating '
                r'to its\s+business and operations\. These risks include market, credit risk,\s+'
                r'liquidity risk\.\s*</p>\s*'
                r'<p class="gap">\s*It maintains timely reports about its risks management '
                r'function and\s+monitors risks and policies implemented to mitigate risk '
                r'exposures\.\s*</p>'
            ),
            risk_replacement,
            updated_html,
            flags=re.IGNORECASE | re.DOTALL,
        )
        updated_html = re.sub(
            r'most of its assets and liabilities are denominated in UAE Dirham\.',
            'most of its assets and liabilities are denominated in United States Dollar.',
            updated_html,
            flags=re.IGNORECASE,
        )
        return updated_html

    @staticmethod
    def _apply_currency_text_overrides(report, html_content):
        if not html_content:
            return html_content
        usd_text_mode_enabled = bool(
            getattr(report, 'replace_aed_text_with_usd', False)
            or getattr(report, 'usd_statement', False)
            or getattr(report, 'tb_convert_balances_to_usd', False)
        )
        if not usd_text_mode_enabled:
            return html_content
        return re.sub(r'\bAED\b', 'USD', html_content)

    @staticmethod
    def _apply_draft_watermark(report, html_content):
        if not html_content:
            return html_content
        if not bool(getattr(report, 'draft_watermark', False)):
            return html_content

        marker_class = 'audit-draft-enabled'
        watermark_node = '<div class="audit-draft-watermark" aria-hidden="true">DRAFT</div>'
        body_match = re.search(r'<body\b[^>]*>', html_content, flags=re.IGNORECASE)
        if not body_match:
            return html_content

        body_tag = body_match.group(0)
        updated_body_tag = body_tag
        class_match = re.search(
            r'class=(["\'])(.*?)\1',
            body_tag,
            flags=re.IGNORECASE | re.DOTALL,
        )
        if class_match:
            class_tokens = class_match.group(2).split()
            if marker_class not in class_tokens:
                existing_classes = class_match.group(2)
                merged_classes = f'{existing_classes} {marker_class}'.strip()
                updated_body_tag = (
                    body_tag[:class_match.start(2)]
                    + merged_classes
                    + body_tag[class_match.end(2):]
                )
        else:
            updated_body_tag = body_tag[:-1] + f' class="{marker_class}">'

        updated_html = (
            html_content[:body_match.start()]
            + updated_body_tag
            + html_content[body_match.end():]
        )
        if 'audit-draft-watermark' in updated_html:
            return updated_html

        watermark_insert_at = body_match.start() + len(updated_body_tag)
        return (
            updated_html[:watermark_insert_at]
            + watermark_node
            + updated_html[watermark_insert_at:]
        )

    @staticmethod
    def _extract_section_header_text(section_html, class_name, fallback=''):
        pattern = re.compile(
            rf'<[^>]*class=(["\'])([^"\']*\b{re.escape(class_name)}\b[^"\']*)\1[^>]*>(.*?)</[^>]+>',
            flags=re.IGNORECASE | re.DOTALL,
        )
        match = pattern.search(section_html or '')
        if not match:
            return fallback
        inner_html = match.group(3) or ''
        plain_text = re.sub(r'<[^>]+>', '', inner_html, flags=re.DOTALL)
        plain_text = html_lib.unescape(plain_text).strip()
        return plain_text or fallback

    @staticmethod
    def _build_blank_auditor_pages(section_html):
        section_open_match = re.match(r'\s*<section\b([^>]*)>', section_html or '', flags=re.IGNORECASE | re.DOTALL)
        classes = ['independent_auditor_report', 'page']
        if section_open_match:
            class_match = re.search(
                r'class=(["\'])(.*?)\1',
                section_open_match.group(0),
                flags=re.IGNORECASE | re.DOTALL,
            )
            if class_match:
                tokens = [token for token in class_match.group(2).split() if token]
                if tokens:
                    classes = tokens
        if 'independent_auditor_report' not in classes:
            classes.insert(0, 'independent_auditor_report')
        if 'page' not in classes:
            classes.append('page')
        if 'draft-auditor-blank-page' not in classes:
            classes.append('draft-auditor-blank-page')

        class_attr = ' '.join(classes)
        title_text = AuditReportController._extract_section_header_text(
            section_html,
            'auditor-header-title',
            fallback='Independent Auditor Report',
        )
        subtitle_text = AuditReportController._extract_section_header_text(
            section_html,
            'auditor-header-subtitle',
            fallback='',
        )
        title_html = html_lib.escape(title_text)
        subtitle_html = html_lib.escape(subtitle_text)
        header_source_html = (
            '<div class="draft-auditor-header-source" aria-hidden="true">'
            f'<p class="bold_ auditor-header-title">{title_html}</p>'
            f'<p class="auditor-header-subtitle">{subtitle_html}</p>'
            '</div>'
        )
        blank_label_html = '<p class="draft-auditor-blank-label">THIS PAGE LEFT BLANK</p>'
        section_block = (
            f'<section class="{class_attr}">{header_source_html}{blank_label_html}</section>'
        )
        return section_block + section_block

    @staticmethod
    def _apply_draft_auditor_blank_pages(report, html_content):
        if not html_content:
            return html_content
        if not bool(getattr(report, 'draft_watermark', False)):
            return html_content

        section_pattern = re.compile(
            r'<section\b[^>]*class=(["\'])[^"\']*\bindependent_auditor_report\b[^"\']*\1[^>]*>.*?</section>',
            flags=re.IGNORECASE | re.DOTALL,
        )
        return section_pattern.sub(
            lambda match: AuditReportController._build_blank_auditor_pages(match.group(0)),
            html_content,
        )

    def _html_to_pdf(self, html_content, base_url=None):
        """Render HTML+CSS to PDF server-side.

        WeasyPrint supports CSS paged media (@page, counters, margin boxes) and
        matches browser print output better than wkhtmltopdf in most cases.
        """
        try:
            from weasyprint import HTML
        except Exception as e:
            raise RuntimeError(f"WeasyPrint is not available in this Odoo environment: {e}")

        return HTML(string=html_content, base_url=base_url).write_pdf()

    def _html_to_pdf_doc(self, html_content, base_url=None):
        """Render HTML to a WeasyPrint document for page counting."""
        try:
            from weasyprint import HTML
        except Exception as e:
            raise RuntimeError(f"WeasyPrint is not available in this Odoo environment: {e}")

        return HTML(string=html_content, base_url=base_url).render()

    def _default_toc_entries(self, report, data):
        signature_names = data.get('signature_names') or []
        director_label_lower = 'director' if len(signature_names) == 1 else 'directors'
        entries = [
            {'label': 'Entity information', 'page_range': '1'},
            {'label': f'Report of {director_label_lower}', 'page_range': '2-3'},
            {'label': 'Independent auditor report', 'page_range': '4-5'},
            {'label': 'Statement of financial position', 'page_range': '6'},
            {'label': 'Statement of profit and loss and other comprehensive income', 'page_range': '7'},
            {'label': 'Statement of changes in equity', 'page_range': '8'},
            {'label': 'Statement of cash flows', 'page_range': '9'},
            {'label': 'Notes to the financial statements', 'page_range': '10-22'},
        ]
        if self._is_dmcc_summary_enabled(report):
            entries.append({'label': 'Summary sheet', 'page_range': '23'})
        return entries

    def _compute_toc_entries(self, report, report_data=None, template_env=None, css_content=None):
        module_path = self._module_path()
        data = report_data if report_data is not None else report._get_report_data()
        templates_path = self._templates_path()
        if template_env is None:
            template_env = self._get_template_env(templates_path)
        if css_content is None:
            css_content = self._get_cached_css_content(os.path.join(templates_path, 'audit_report_style.css'))
        signature_names = data.get('signature_names') or []
        director_label_lower = 'director' if len(signature_names) == 1 else 'directors'
        sections = [
            ('entity_information', 'Entity information'),
            ('report_of_directors', f'Report of {director_label_lower}'),
            ('independent_auditor_report', 'Independent auditor report'),
            ('balance_sheet_page', 'Statement of financial position'),
            ('profit_loss', 'Statement of profit and loss and other comprehensive income'),
            ('changes_in_equity', 'Statement of changes in equity'),
            ('cash_flows', 'Statement of cash flows'),
            ('notes_to_financial_statements', 'Notes to the financial statements'),
        ]
        if self._is_dmcc_summary_enabled(report):
            sections.append(('dmcc_sheet', 'Summary sheet'))

        default_toc_entries = self._default_toc_entries(report, data)
        toc_entries = []
        current_page = 1
        for section_key, label in sections:
            html_with_style = self._render_report_html(
                report,
                sections_to_render=[section_key],
                toc_entries=default_toc_entries,
                report_data=data,
                template_env=template_env,
                css_content=css_content,
            )
            doc = self._html_to_pdf_doc(html_with_style, base_url=module_path)
            page_count = len(doc.pages)
            if page_count <= 0:
                continue
            end_page = current_page + page_count - 1
            page_range = str(current_page) if page_count == 1 else f"{current_page}-{end_page}"
            toc_entries.append({'label': label, 'page_range': page_range})
            current_page = end_page + 1

        return toc_entries

    def _render_report_html(
        self,
        report,
        sections_to_render=None,
        toc_entries=None,
        report_data=None,
        template_env=None,
        css_content=None,
    ):
        company = report.company_id
        if not report.exists():
            return None

        templates_path = self._templates_path()
        env = template_env or self._get_template_env(templates_path)
        data = report_data if report_data is not None else report._get_report_data()
        period_category = (report.audit_period_category or '').lower()
        if period_category.startswith('dormant_'):
            template_name = (
                'audit_report_template_dormant_2y.html'
                if data.get('show_prior_year')
                else 'audit_report_template_dormant_1y.html'
            )
        elif period_category.startswith('cessation_'):
            template_name = (
                'audit_report_template_cessation_2y.html'
                if data.get('show_prior_year')
                else 'audit_report_template_cessation_1y.html'
            )
        else:
            template_name = (
                'audit_report_template_2y.html'
                if data.get('show_prior_year')
                else 'audit_report_template.html'
            )
        template = env.get_template(template_name)
        report_type_label = dict(report._fields['report_type'].selection).get(report.report_type, '')
        report_period_end = report.date_end.strftime("%d %B %Y") if report.date_end else ''
        report_title = f"{report_type_label} {report_period_end}".strip()
        report_ended_label = 'Year Ended' if report.report_type == 'year' else 'Period Ended'
        report_period_word = 'year' if report.report_type == 'year' else 'period'
        activity = getattr(company, 'trade_license_activities', '') or ''
        include_services_word = bool(getattr(report, 'business_activity_include_services', True))
        implementing_regulations_freezone = getattr(company, 'implementing_regulations_freezone', '') or ''
        if not implementing_regulations_freezone and hasattr(company, '_get_free_zone_implementing_regulations'):
            implementing_regulations_freezone = (
                company._get_free_zone_implementing_regulations(getattr(company, 'free_zone', '')) or ''
            )

        context = {
            'company': company,
            'company_name': getattr(company, 'name', ''),
            'freezone': getattr(company, 'free_zone', ''),
            'implementing_regulations_freezone': implementing_regulations_freezone,
            'license': getattr(company, 'company_license_number', ''),
            'owner': getattr(company, 'owner', ''),
            'business_activity': activity.lower(),
            'business_activity_services_suffix': ' services' if include_services_word else '',
            'date_start': report.date_start,
            'date_end': report.date_end,
            'freezone_selection': report.auditor_type,
            'report_title': report_title,
            'report_type': report.report_type,
            'report_period_end': report_period_end,
            'report_ended_label': report_ended_label,
            'report_period_word': report_period_word,
            'sections_to_render': sections_to_render,
        }
        context.update(data)
        if toc_entries is None:
            toc_entries = self._default_toc_entries(report, data)
        context['toc_entries'] = toc_entries

        html_content = template.render(**context)
        html_content = self._apply_usd_statement_overrides(report, html_content)
        html_content = self._apply_currency_text_overrides(report, html_content)
        html_content = self._apply_draft_auditor_blank_pages(report, html_content)
        html_content = self._apply_draft_watermark(report, html_content)
        if css_content is None:
            css_content = self._get_cached_css_content(os.path.join(templates_path, 'audit_report_style.css'))
        if not css_content:
            return html_content

        return html_content.replace('</head>', f'<style>{css_content}</style></head>')
    
    @http.route('/audit_report/view/<int:report_id>', type='http', auth='user')
    def view_report(self, report_id, **kwargs):
        report = request.env['audit.report'].browse(report_id)
        html_with_style = self._render_report_html(report)
        if not html_with_style:
            return request.not_found()
        
        return request.make_response(
            html_with_style,
            headers=[
                ('Content-Type', 'text/html; charset=utf-8'),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ]
        )

    @http.route('/audit_report/pdf/<int:report_id>', type='http', auth='user')
    def view_report_pdf(self, report_id, **kwargs):
        route_started = time.perf_counter()
        report = request.env['audit.report'].browse(report_id)
        report_data_started = time.perf_counter()
        report_data = report._get_report_data()
        report_data_elapsed_ms = (time.perf_counter() - report_data_started) * 1000.0
        _logger.debug(
            "AUDIT_PERF view_report_pdf report_id=%s stage=report_data elapsed_ms=%.2f",
            report.id,
            report_data_elapsed_ms,
        )
        templates_path = self._templates_path()
        template_env = self._get_template_env(templates_path)
        css_content = self._get_cached_css_content(os.path.join(templates_path, 'audit_report_style.css'))

        toc_started = time.perf_counter()
        try:
            toc_entries = self._compute_toc_entries(
                report,
                report_data=report_data,
                template_env=template_env,
                css_content=css_content,
            )
        except Exception as e:
            _logger.exception("Audit report TOC generation failed: %s", e)
            toc_entries = None
        toc_elapsed_ms = (time.perf_counter() - toc_started) * 1000.0
        _logger.debug(
            "AUDIT_PERF view_report_pdf report_id=%s stage=toc elapsed_ms=%.2f",
            report.id,
            toc_elapsed_ms,
        )

        html_started = time.perf_counter()
        html_with_style = self._render_report_html(
            report,
            toc_entries=toc_entries,
            report_data=report_data,
            template_env=template_env,
            css_content=css_content,
        )
        html_elapsed_ms = (time.perf_counter() - html_started) * 1000.0
        _logger.debug(
            "AUDIT_PERF view_report_pdf report_id=%s stage=html elapsed_ms=%.2f",
            report.id,
            html_elapsed_ms,
        )
        if not html_with_style:
            return request.not_found()

        pdf_started = time.perf_counter()
        try:
            module_path = self._module_path()
            pdf_content = self._html_to_pdf(html_with_style, base_url=module_path)
        except Exception as e:
            _logger.exception("Audit report PDF generation failed: %s", e)
            summary, issues = self._extract_error_summary_and_issues(
                e,
                'Unable to generate the audit report PDF.',
            )
            return self._render_editor_error_response(
                'Audit Report PDF Error',
                summary,
                issues,
                back_url=f'/web#id={report.id}&model=audit.report&view_type=form',
                status=500,
            )
        pdf_elapsed_ms = (time.perf_counter() - pdf_started) * 1000.0
        total_elapsed_ms = (time.perf_counter() - route_started) * 1000.0
        _logger.debug(
            "AUDIT_PERF view_report_pdf report_id=%s stage=pdf elapsed_ms=%.2f total_elapsed_ms=%.2f",
            report.id,
            pdf_elapsed_ms,
            total_elapsed_ms,
        )
        filename = f'Audit_Report_{report.id}.pdf'
        return request.make_response(
            pdf_content,
            headers=[
                ('Content-Type', 'application/pdf'),
                ('Content-Disposition', f'inline; filename="{filename}"'),
                ('Content-Length', str(len(pdf_content))),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ]
        )

    @http.route('/audit_report/lor/<int:report_id>', type='http', auth='user')
    def generate_lor_docx(self, report_id, **kwargs):
        report = request.env['audit.report'].browse(report_id)
        if not report.exists():
            return request.not_found()

        template_text = self._get_cached_lor_template_content()
        if not template_text:
            return self._render_editor_error_response(
                'Audit Representation Letter Error',
                'LOR template file was not found.',
                ['Expected file: templates/LOR.html'],
                back_url=f'/web#id={report.id}&model=audit.report&view_type=form',
                status=500,
            )
        lor_css_text = self._get_cached_lor_css_content()
        lor_styles = self._parse_lor_css_styles(lor_css_text)

        try:
            report._sync_lor_extra_items_json()
            extra_main_items = report._get_lor_extra_item_texts()
            placeholder_values = self._build_lor_placeholder_values(report)
            filled_lor_content = self._render_lor_template_content(
                placeholder_values,
                extra_main_items=extra_main_items,
            )
            docx_content = self._build_docx_from_text(
                filled_lor_content,
                title='Audit Representation Letter',
                lor_styles=lor_styles,
            )
        except Exception as error:
            _logger.exception("Audit representation letter DOCX generation failed: %s", error)
            summary, issues = self._extract_error_summary_and_issues(
                error,
                'Unable to generate the audit representation letter.',
            )
            return self._render_editor_error_response(
                'Audit Representation Letter Error',
                summary,
                issues,
                back_url=f'/web#id={report.id}&model=audit.report&view_type=form',
                status=500,
            )

        filename = self._build_lor_filename(report)
        return request.make_response(
            docx_content,
            headers=[
                (
                    'Content-Type',
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                ),
                ('Content-Disposition', f'attachment; filename="{filename}"'),
                ('Content-Length', str(len(docx_content))),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ],
        )

    def _forbidden_response(self, message='Forbidden'):
        return request.make_response(
            message,
            headers=[('Content-Type', 'text/plain; charset=utf-8')],
            status=403,
        )

    def _load_revision(self, revision_id, include_removed=True):
        revision = request.env['audit.report.revision'].browse(revision_id)
        if not revision.exists():
            return None
        user_company_ids = request.env.user.company_ids.ids
        if revision.company_id.id not in user_company_ids:
            return None
        if not include_removed and revision.is_removed:
            return None
        return revision

    def _render_editor_shell(self, title, body_html):
        title_escaped = html_lib.escape(title or 'Editor')
        return f"""
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>{title_escaped}</title>
    <style>
      body {{
        margin: 0;
        font-family: "Segoe UI", Tahoma, Arial, sans-serif;
        background: #e7e9ee;
        color: #1d2733;
      }}
      .page {{
        max-width: 1560px;
        margin: 0 auto;
        padding: 24px;
      }}
      .panel {{
        background: #fff;
        border: 1px solid #d5dbe6;
        border-radius: 10px;
        box-shadow: 0 4px 14px rgba(17, 24, 39, 0.05);
        padding: 16px;
        margin-bottom: 16px;
      }}
      .muted {{
        color: #6b7280;
        font-size: 13px;
      }}
      .ok {{
        background: #e8f7ec;
        border: 1px solid #9bd7ac;
        color: #0f5132;
        border-radius: 6px;
        padding: 10px 12px;
        margin-bottom: 12px;
      }}
      .error-panel {{
        background: #fff4f4;
        border: 1px solid #efb3b3;
        color: #7f1d1d;
      }}
      .error-list {{
        margin: 8px 0 0 20px;
        padding: 0;
      }}
      .error-list li {{
        margin: 0 0 4px 0;
      }}
      .btn {{
        display: inline-block;
        background: #1f5eff;
        color: #fff;
        border: none;
        border-radius: 6px;
        padding: 10px 14px;
        text-decoration: none;
        cursor: pointer;
        font-size: 14px;
      }}
      .btn-secondary {{
        background: #4b5563;
      }}
      .btn-danger {{
        background: #b91c1c;
      }}
      .btn-mini {{
        padding: 6px 8px;
        font-size: 12px;
        line-height: 1.2;
      }}
      .btn:disabled {{
        opacity: 0.5;
        cursor: not-allowed;
      }}
      .links a {{
        margin-right: 8px;
      }}
      table {{
        border-collapse: collapse;
        width: 100%;
      }}
      th, td {{
        border: 1px solid #d0d7e2;
        padding: 6px;
        vertical-align: top;
      }}
      input[type=\"text\"], textarea, select {{
        width: 100%;
        box-sizing: border-box;
        padding: 8px;
        border: 1px solid #c6cdd9;
        border-radius: 6px;
        font-size: 14px;
      }}
      textarea {{
        min-height: 65vh;
        font-family: monospace;
      }}
      .table-list {{
        display: grid;
        grid-template-columns: 320px 1fr;
        gap: 16px;
      }}
      .table-list ul {{
        list-style: none;
        margin: 0;
        padding: 0;
      }}
      .table-list li {{
        border: 1px solid #d9dee8;
        border-radius: 6px;
        margin-bottom: 8px;
        background: #fff;
      }}
      .table-list li a {{
        display: block;
        padding: 10px 12px;
        text-decoration: none;
        color: #1d2733;
      }}
      .table-list li.active {{
        background: #ecf2ff;
        border-color: #9cb6ff;
      }}
      .small {{
        font-size: 12px;
        color: #6b7280;
      }}
      .toolbar {{
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 12px;
        background: #f6f8fc;
        border: 1px solid #d5dbea;
        border-radius: 8px;
        padding: 10px;
      }}
      .toolbar .btn {{
        border: none;
        color: #fff;
      }}
      .toolbar .btn-secondary {{
        background: #4b5563;
      }}
      .toolbar .btn-danger {{
        background: #b91c1c;
      }}
      .toolbar button {{
        background: #eef2ff;
        border: 1px solid #bfccff;
        color: #243b85;
        border-radius: 6px;
        padding: 8px 10px;
        cursor: pointer;
      }}
      .toolbar button.btn {{
        border: none;
        color: #fff;
      }}
      .toolbar button.btn-secondary {{
        background: #4b5563;
      }}
      .toolbar button.btn-danger {{
        background: #b91c1c;
      }}
      .toolbar select,
      .toolbar input[type="color"] {{
        width: auto;
        min-width: 82px;
        padding: 6px 8px;
      }}
      .toolbar .toolbar-label {{
        font-size: 12px;
        color: #4b5563;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }}
      .structured-quickbar {{
        align-items: center;
        justify-content: space-between;
      }}
      .structured-col-grid {{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 8px;
        margin-bottom: 12px;
      }}
      .structured-col-card {{
        border: 1px solid #d5dbea;
        border-radius: 8px;
        background: #f8faff;
        padding: 8px;
      }}
      .structured-col-title {{
        font-size: 12px;
        color: #334155;
        margin-bottom: 6px;
        min-height: 16px;
      }}
      .structured-col-buttons {{
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
      }}
      .structured-table .row-actions {{
        width: 150px;
        min-width: 150px;
        background: #f8fafc;
      }}
      .structured-table .structured-body-row {{
        transition: background-color 0.12s ease;
      }}
      .structured-table .structured-body-row.is-dragging {{
        opacity: 0.55;
        background: #e5edff;
      }}
      .structured-table .structured-body-row.drop-before td,
      .structured-table .structured-body-row.drop-before th {{
        border-top: 2px solid #1f5eff;
      }}
      .structured-table .structured-body-row.drop-after td,
      .structured-table .structured-body-row.drop-after th {{
        border-bottom: 2px solid #1f5eff;
      }}
      .structured-table .row-actions-muted {{
        text-align: center;
      }}
      .structured-table .row-action-top {{
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        margin-bottom: 6px;
      }}
      .structured-table .row-drag-handle {{
        border: 1px solid #c5d2f8;
        background: #eef2ff;
        color: #1e3a8a;
        border-radius: 6px;
        padding: 4px 6px;
        font-size: 11px;
        cursor: grab;
      }}
      .structured-table .row-drag-handle:active {{
        cursor: grabbing;
      }}
      .structured-table .row-action-label {{
        font-weight: 600;
      }}
      .structured-table .row-action-buttons {{
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
      }}
      .visual-toolbar {{
        position: sticky;
        top: 10px;
        z-index: 20;
      }}
      .editor-stage {{
        background: #cdd3dc;
        border: 1px solid #b4becb;
        border-radius: 10px;
        padding: 18px;
        overflow-x: auto;
        overflow-y: visible;
        max-height: none;
      }}
      .editor-canvas {{
        width: 980px;
        max-width: 100%;
        margin: 0 auto;
        background: #fff;
        box-shadow: 0 14px 34px rgba(15, 23, 42, 0.35);
        border: 1px solid #c7d0dd;
        transform-origin: top center;
      }}
      .editor-frame {{
        width: 100%;
        height: 1280px;
        border: none;
        display: block;
        background: white;
      }}
      .editor-caption {{
        margin-top: 8px;
        color: #5a6474;
        font-size: 12px;
      }}
    </style>
  </head>
  <body>
    <div class=\"page\">
      {body_html}
    </div>
  </body>
</html>
"""

    def _extract_error_summary_and_issues(self, error, default_summary):
        raw = str(error or '').replace('\r', '\n')
        lines = [line.strip() for line in raw.split('\n') if line.strip()]
        if not lines:
            return default_summary, []

        summary = lines[0]
        issues = []
        for line in lines[1:]:
            cleaned = line.lstrip('-*• ').strip()
            if cleaned:
                issues.append(cleaned)

        if summary.startswith(('-', '*', '•')):
            cleaned_summary = summary.lstrip('-*• ').strip()
            summary = default_summary
            if cleaned_summary:
                issues.insert(0, cleaned_summary)

        return summary or default_summary, issues

    def _render_editor_error_response(self, title, summary, issues=None, back_url=None, status=400):
        safe_title = html_lib.escape(title or 'Error')
        safe_summary = html_lib.escape(summary or 'Something went wrong.')
        issue_items = ''.join(f"<li>{html_lib.escape(issue)}</li>" for issue in (issues or []))
        issue_list = f'<ul class="error-list">{issue_items}</ul>' if issue_items else ''
        back_link = (
            f'<a class="btn btn-secondary" href="{html_lib.escape(back_url)}">Back</a>'
            if back_url else ''
        )
        body = f"""
<div class="panel error-panel">
  <h2>{safe_title}</h2>
  <p>{safe_summary}</p>
  {issue_list}
  <br/>
  <div class="links">{back_link}</div>
</div>
"""
        page = self._render_editor_shell(title, body)
        return request.make_response(
            page,
            headers=[('Content-Type', 'text/html; charset=utf-8')],
            status=status,
        )

    def _persist_revision_edit(self, revision, prepared_html, force_new_revision=False):
        """Persist edited HTML with session-style revision behavior."""
        current_hash = revision._compute_html_hash()
        prepared_hash = revision._compute_html_hash(prepared_html)
        if prepared_hash == current_hash:
            return revision, 'unchanged'

        if force_new_revision:
            return revision.create_next_revision(prepared_html), 'new'

        # Session behavior:
        # - first save from a root revision creates one child revision
        # - subsequent saves on that child update it in place
        if revision.parent_revision_id:
            revision.write({'html_content': prepared_html})
            return revision, 'updated'

        return revision.create_next_revision(prepared_html), 'new'

    def _render_structured_editor_page(self, revision, selected_table_key=None, saved_state=''):
        tables = revision.get_table_index()
        if not tables:
            content = (
                "<div class='panel'><h2>Structured Table Editor</h2>"
                "<p class='muted'>No tables were found in this revision.</p></div>"
            )
            return self._render_editor_shell('Structured Table Editor', content)

        selected_table_key = selected_table_key or tables[0].get('key')
        if selected_table_key not in [table.get('key') for table in tables]:
            selected_table_key = tables[0].get('key')

        payload = revision.get_table_payload(selected_table_key)
        selected_table_meta = next(
            (table for table in tables if table.get('key') == selected_table_key),
            {}
        )
        is_soce_table = (selected_table_meta.get('section') or '') == 'changes_in_equity'
        has_nested_tables = bool(selected_table_meta.get('has_nested_tables'))
        csrf = request.csrf_token()
        if saved_state == 'new':
            saved_banner = "<div class='ok'>Saved as a new revision successfully.</div>"
        elif saved_state == 'updated':
            saved_banner = "<div class='ok'>Saved to the current revision session.</div>"
        elif saved_state == 'unchanged':
            saved_banner = "<div class='ok'>No changes detected; revision kept as-is.</div>"
        else:
            saved_banner = ""
        back_url = f"/web#id={revision.id}&model=audit.report.revision&view_type=form"
        preview_url = f"/audit_report/revision/{revision.id}/preview"
        freeform_url = f"/audit_report/revision/{revision.id}/edit/freeform"
        table_rows = payload.get('rows') or []
        body_row_indices = []
        for index in payload.get('body_row_indices') or []:
            try:
                body_row_indices.append(int(index))
            except (TypeError, ValueError):
                continue
        body_row_parent_groups = {}
        for raw_index, raw_group in (payload.get('body_row_parent_groups') or {}).items():
            try:
                row_index = int(raw_index)
                parent_group = int(raw_group)
            except (TypeError, ValueError):
                continue
            body_row_parent_groups[row_index] = parent_group
        body_row_index_set = set(body_row_indices)
        if not body_row_index_set and table_rows:
            body_row_indices = list(range(len(table_rows)))
            body_row_index_set = set(body_row_indices)
        if not body_row_parent_groups:
            for row_index in body_row_indices:
                body_row_parent_groups[row_index] = 1
        row_count = int(payload.get('body_row_count') or len(body_row_index_set) or 0)
        col_count = int(selected_table_meta.get('cols') or 0) or max((len(row) for row in table_rows), default=0)
        default_target_row = row_count or 1
        default_target_col = max(col_count or 1, 2 if is_soce_table else 1)
        default_row_order = ','.join(str(index) for index in body_row_indices)
        add_row_end_label = "Add First Row" if row_count == 0 else "Add Row at End"
        row_controls_html = (
            f"<div class=\"toolbar structured-quickbar\">"
            f"<span class=\"small\">Rows: drag body rows to reorder within each table block, then save. Add/remove buttons remain available.</span>"
            f"<button class=\"btn btn-secondary btn-mini\" type=\"submit\" name=\"table_action\" value=\"add_row_after\" "
            f"onclick=\"this.form.target_row.value='{default_target_row}'\">{add_row_end_label}</button>"
            f"</div>"
        )

        def _column_display_label(col_no):
            for row in table_rows:
                if col_no - 1 >= len(row):
                    continue
                raw = (row[col_no - 1].get('value') or '').strip()
                if raw:
                    compact = ' '.join(raw.split())
                    if len(compact) > 28:
                        return compact[:27].rstrip() + '...'
                    return compact
            return f"Column {col_no}"

        if col_count > 0:
            column_cards = []
            for col_no in range(1, col_count + 1):
                label = html_lib.escape(_column_display_label(col_no))
                disable_remove = col_count <= 1
                remove_hint = ''
                if is_soce_table:
                    if col_no == 1:
                        disable_remove = True
                        remove_hint = 'Description column cannot be removed.'
                    elif col_count <= 2:
                        disable_remove = True
                        remove_hint = 'SOCE must keep at least one amount column.'
                elif col_count <= 1:
                    remove_hint = 'A table must keep at least one column.'
                remove_attrs = ' disabled' if disable_remove else ''
                remove_title = html_lib.escape(remove_hint or 'Remove this column')
                add_label = 'Add After'
                remove_label = 'Remove'
                column_cards.append(
                    "<div class='structured-col-card'>"
                    f"<div class='structured-col-title'>C{col_no}: {label}</div>"
                    "<div class='structured-col-buttons'>"
                    f"<button class='btn btn-secondary btn-mini' type='submit' "
                    f"name='table_action' value='add_col_after' title='Add a new column after this one' "
                    f"onclick=\"this.form.target_col.value='{col_no}'\">{add_label}</button>"
                    f"<button class='btn btn-danger btn-mini' type='submit' "
                    f"name='table_action' value='remove_col' title='{remove_title}' "
                    f"onclick=\"this.form.target_col.value='{col_no}'; return confirm('Remove this column?');\"{remove_attrs}>{remove_label}</button>"
                    "</div>"
                    "</div>"
                )
            column_controls_html = f"<div class='structured-col-grid'>{''.join(column_cards)}</div>"
        else:
            column_controls_html = (
                "<div class='toolbar structured-quickbar'>"
                "<span class='small'>Columns: this table has no columns yet.</span>"
                "<button class='btn btn-secondary btn-mini' type='submit' name='table_action' value='add_col_after' "
                "onclick=\"this.form.target_col.value='1'\">Add First Column</button>"
                "</div>"
            )
        if is_soce_table:
            column_controls_html += (
                "<p class='small'><strong>SOCE rule:</strong> Column #1 is description and cannot be removed.</p>"
            )
        if has_nested_tables:
            table_limit_notice = (
                "<p class='small'><strong>Composite table:</strong> nested-table cells are locked in structured mode "
                "to protect layout. Row/column operations are available.</p>"
            )
        else:
            table_limit_notice = ""

        table_links = []
        for table in tables:
            key = table.get('key') or ''
            section = html_lib.escape(table.get('section') or 'section')
            preview = html_lib.escape(table.get('preview') or '')
            table_class = html_lib.escape(table.get('table_class') or '')
            rows = table.get('rows') or 0
            cols = table.get('cols') or 0
            table_type_bits = []
            if table.get('has_nested_tables'):
                table_type_bits.append('composite')
            if table.get('is_nested_within_table'):
                table_type_bits.append('nested')
            table_type = html_lib.escape(', '.join(table_type_bits)) if table_type_bits else 'leaf'
            active_class = 'active' if key == selected_table_key else ''
            url = f"/audit_report/revision/{revision.id}/edit/structured?table_key={quote_plus(key)}"
            table_links.append(
                "<li class='{active}'>"
                "<a href='{url}'><strong>{section} / {key}</strong><br>"
                "<span class='small'>type: {table_type}</span><br>"
                "<span class='small'>class: {table_class}</span><br>"
                "<span class='small'>{rows} rows x {cols} cols</span><br>"
                "<span class='small'>{preview}</span></a></li>".format(
                    active=active_class,
                    url=url,
                    section=section,
                    key=html_lib.escape(key),
                    table_type=table_type,
                    table_class=table_class or '-',
                    rows=rows,
                    cols=cols,
                    preview=preview,
                )
            )

        matrix_rows = []
        body_row_number = 0
        for row_index, row in enumerate(table_rows):
            cells = []
            is_body_row = row_index in body_row_index_set
            first_tag = (row[0].get('tag') or 'td').lower() if row else 'td'
            row_attrs = ''
            if is_body_row:
                body_row_number += 1
                parent_group = body_row_parent_groups.get(row_index, 1)
                row_attrs = (
                    f" class='structured-body-row' data-body-row='1' "
                    f"data-source-row='{row_index}' data-row-target='{body_row_number}' "
                    f"data-parent-group='{parent_group}'"
                )
                remove_row_disabled = row_count <= 1
                remove_row_attrs = ' disabled' if remove_row_disabled else ''
                remove_row_title = html_lib.escape(
                    'At least one row must remain in the table.'
                    if remove_row_disabled else
                    'Remove this row'
                )
                cells.append(
                    "<td class='row-actions'>"
                    "<div class='row-action-top'>"
                    "<button class='row-drag-handle' type='button' title='Drag this row up or down' draggable='true'>Drag</button>"
                    f"<div class='row-action-label small'>Row {body_row_number}</div>"
                    "</div>"
                    "<div class='row-action-buttons'>"
                    f"<button class='btn btn-secondary btn-mini' type='submit' "
                    f"name='table_action' value='add_row_after' "
                    f"title='Add a row below this row' "
                    f"data-row-target='{body_row_number}' "
                    "onclick=\"this.form.target_row.value=this.dataset.rowTarget;\">+ Below</button>"
                    f"<button class='btn btn-danger btn-mini' type='submit' "
                    f"name='table_action' value='remove_row' "
                    f"title='{remove_row_title}' "
                    f"data-row-target='{body_row_number}' "
                    f"onclick=\"this.form.target_row.value=this.dataset.rowTarget; return confirm('Remove this row?');\"{remove_row_attrs}>Remove</button>"
                    "</div>"
                    "</td>"
                )
            else:
                placeholder_tag = 'th' if first_tag == 'th' else 'td'
                row_attrs = " class='structured-nonbody-row'"
                cells.append(
                    f"<{placeholder_tag} class='row-actions row-actions-muted'><span class='small'>Header</span></{placeholder_tag}>"
                )
            for cell in row:
                value = html_lib.escape(cell.get('value') or '')
                field_name = html_lib.escape(cell.get('name') or '')
                tag = (cell.get('tag') or 'td').lower()
                editable = bool(cell.get('editable', True))
                readonly_attrs = ''
                if not editable:
                    readonly_attrs = (
                        " readonly title='Complex cell: use Freeform Editor for this content.'"
                    )
                if tag == 'th':
                    cells.append(
                        f"<th><input type='text' name='{field_name}' value='{value}'{readonly_attrs} /></th>"
                    )
                else:
                    cells.append(
                        f"<td><input type='text' name='{field_name}' value='{value}'{readonly_attrs} /></td>"
                    )
            matrix_rows.append(f"<tr{row_attrs}>{''.join(cells)}</tr>")
        if not matrix_rows:
            matrix_rows.append(
                "<tr>"
                "<td class='row-actions row-actions-muted'><span class='small'>Rows</span></td>"
                "<td><span class='small'>No rows yet. Use Add First Row.</span></td>"
                "</tr>"
            )
        row_drag_script = """
<script>
(function () {
  const form = document.getElementById('structuredEditorForm');
  if (!form) {
    return;
  }
  const table = form.querySelector('table.structured-table');
  const rowOrderInput = form.querySelector('input[name=\"row_order\"]');
  if (!table || !rowOrderInput) {
    return;
  }

  let draggedRow = null;

  function bodyRows() {
    return Array.from(table.querySelectorAll('tr[data-body-row=\"1\"]'));
  }

  function clearDropMarkers() {
    bodyRows().forEach((row) => {
      row.classList.remove('drop-before');
      row.classList.remove('drop-after');
    });
  }

  function syncRows() {
    const rows = bodyRows();
    rows.forEach((row, index) => {
      const rowNo = String(index + 1);
      row.dataset.rowTarget = rowNo;
      const label = row.querySelector('.row-action-label');
      if (label) {
        label.textContent = `Row ${rowNo}`;
      }
      row.querySelectorAll('[data-row-target]').forEach((button) => {
        button.dataset.rowTarget = rowNo;
      });
    });
    rowOrderInput.value = rows
      .map((row) => row.dataset.sourceRow || '')
      .filter((value) => value !== '')
      .join(',');
  }

  syncRows();

  table.addEventListener('dragstart', (event) => {
    const handle = event.target.closest('.row-drag-handle');
    if (!handle) {
      return;
    }
    const row = handle.closest('tr[data-body-row=\"1\"]');
    if (!row) {
      return;
    }

    draggedRow = row;
    row.classList.add('is-dragging');
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('text/plain', row.dataset.sourceRow || '');
    }
  });

  table.addEventListener('dragover', (event) => {
    if (!draggedRow) {
      return;
    }
    const target = event.target.closest('tr[data-body-row=\"1\"]');
    if (!target || target === draggedRow) {
      return;
    }
    const draggedGroup = draggedRow.dataset.parentGroup || '';
    const targetGroup = target.dataset.parentGroup || '';
    if (draggedGroup && targetGroup && draggedGroup !== targetGroup) {
      return;
    }

    event.preventDefault();
    clearDropMarkers();
    const rect = target.getBoundingClientRect();
    const insertAfter = event.clientY >= (rect.top + (rect.height / 2));
    target.classList.add(insertAfter ? 'drop-after' : 'drop-before');
    const parent = target.parentNode;
    if (!parent) {
      return;
    }
    if (insertAfter) {
      parent.insertBefore(draggedRow, target.nextSibling);
    } else {
      parent.insertBefore(draggedRow, target);
    }
  });

  table.addEventListener('drop', (event) => {
    if (!draggedRow) {
      return;
    }
    event.preventDefault();
    clearDropMarkers();
    syncRows();
  });

  table.addEventListener('dragend', () => {
    if (!draggedRow) {
      return;
    }
    draggedRow.classList.remove('is-dragging');
    draggedRow = null;
    clearDropMarkers();
    syncRows();
  });

  form.addEventListener('submit', () => {
    syncRows();
  });
})();
</script>
"""

        body = f"""
{saved_banner}
<div class=\"panel\">
  <h2>Structured Table Editor</h2>
  <p class=\"muted\">Revision v{revision.version_no} of {html_lib.escape(revision.document_id.name)}</p>
  <div class=\"links\">
    <a class=\"btn btn-secondary\" href=\"{back_url}\">Back to Revision</a>
    <a class=\"btn btn-secondary\" href=\"{preview_url}\" target=\"_blank\">Preview</a>
    <a class=\"btn\" href=\"{freeform_url}\" target=\"_blank\">Open Freeform Editor</a>
  </div>
</div>
<div class=\"table-list\">
  <div class=\"panel\">
    <h3>All Tables</h3>
    <p class=\"small\">Tables with nested content are listed. Nested-table cells are read-only in structured mode for safety.</p>
    <ul>{''.join(table_links)}</ul>
  </div>
  <div class=\"panel\">
    <h3>Editing: {html_lib.escape(selected_table_key)}</h3>
    <p class=\"muted\">Edit cell values directly. Use row and column action controls below without manually entering row/column numbers.</p>
    {table_limit_notice}
    <form id=\"structuredEditorForm\" method=\"post\" action=\"/audit_report/revision/{revision.id}/save/structured\">
      <input type=\"hidden\" name=\"csrf_token\" value=\"{html_lib.escape(csrf)}\" />
      <input type=\"hidden\" name=\"table_key\" value=\"{html_lib.escape(selected_table_key)}\" />
      <input type=\"hidden\" name=\"target_row\" value=\"{default_target_row}\" />
      <input type=\"hidden\" name=\"target_col\" value=\"{default_target_col}\" />
      <input type=\"hidden\" name=\"row_order\" value=\"{html_lib.escape(default_row_order)}\" />
      {row_controls_html}
      {column_controls_html}
      <table class=\"structured-table\">{''.join(matrix_rows)}</table>
      <br/>
      <input type=\"hidden\" name=\"save_mode\" value=\"session\" />
      <button class=\"btn\" type=\"submit\" name=\"table_action\" value=\"save\" onclick=\"this.form.save_mode.value='session'\">Save Changes</button>
      <button class=\"btn btn-secondary\" type=\"submit\" name=\"table_action\" value=\"save\" onclick=\"this.form.save_mode.value='new'\">Save as New Revision</button>
    </form>
    {row_drag_script}
  </div>
</div>
"""
        return self._render_editor_shell('Structured Table Editor', body)

    def _render_freeform_editor_page(self, revision, saved_state=''):
        csrf = request.csrf_token()
        if saved_state == 'new':
            saved_banner = "<div class='ok'>Saved as a new revision successfully.</div>"
        elif saved_state == 'updated':
            saved_banner = "<div class='ok'>Saved to the current revision session.</div>"
        elif saved_state == 'unchanged':
            saved_banner = "<div class='ok'>No changes detected; revision kept as-is.</div>"
        else:
            saved_banner = ""
        initial_html_js = json.dumps(revision.html_content or '')
        back_url = f"/web#id={revision.id}&model=audit.report.revision&view_type=form"
        preview_url = f"/audit_report/revision/{revision.id}/preview"
        structured_url = f"/audit_report/revision/{revision.id}/edit/structured"

        body = f"""
{saved_banner}
<div class=\"panel\">
  <h2>Visual Layout Editor</h2>
  <p class=\"muted\">Revision v{revision.version_no} of {html_lib.escape(revision.document_id.name)}</p>
  <p class=\"muted\">Edit directly on the report layout below (non-technical mode). Use Save Changes for this session, or Save as New Revision for a checkpoint.</p>
  <div class=\"links\">
    <a class=\"btn btn-secondary\" href=\"{back_url}\">Back to Revision</a>
    <a class=\"btn btn-secondary\" href=\"{preview_url}\" target=\"_blank\">Preview</a>
    <a class=\"btn\" href=\"{structured_url}\" target=\"_blank\">Open Structured Editor</a>
  </div>
</div>
<div class=\"panel\">
  <div class=\"toolbar visual-toolbar\">
    <button type=\"button\" data-cmd=\"bold\">Bold</button>
    <button type=\"button\" data-cmd=\"italic\">Italic</button>
    <button type=\"button\" data-cmd=\"underline\">Underline</button>
    <button type=\"button\" data-cmd=\"insertUnorderedList\">Bullet List</button>
    <button type=\"button\" data-cmd=\"justifyLeft\">Align Left</button>
    <button type=\"button\" data-cmd=\"justifyCenter\">Align Center</button>
    <button type=\"button\" data-cmd=\"justifyRight\">Align Right</button>
    <button type=\"button\" id=\"undoBtn\">Undo</button>
    <button type=\"button\" id=\"redoBtn\">Redo</button>
    <button type=\"button\" id=\"resetBtn\">Reset</button>
    <label class=\"toolbar-label\">Zoom
      <select id=\"editorZoom\">
        <option value=\"70\">70%</option>
        <option value=\"85\">85%</option>
        <option value=\"100\" selected>100%</option>
        <option value=\"115\">115%</option>
        <option value=\"130\">130%</option>
      </select>
    </label>
    <label class=\"toolbar-label\">Border width
      <select id=\"borderWidthInput\">
        <option value=\"0.5px\">0.5px</option>
        <option value=\"1px\" selected>1px</option>
        <option value=\"1.5px\">1.5px</option>
        <option value=\"2px\">2px</option>
        <option value=\"3px\">3px</option>
      </select>
    </label>
    <label class=\"toolbar-label\">Border style
      <select id=\"borderStyleInput\">
        <option value=\"solid\" selected>Solid</option>
        <option value=\"dashed\">Dashed</option>
        <option value=\"dotted\">Dotted</option>
        <option value=\"double\">Double</option>
      </select>
    </label>
    <label class=\"toolbar-label\">Border color
      <input type=\"color\" id=\"borderColorInput\" value=\"#000000\" />
    </label>
    <button type=\"button\" data-border=\"all\">Border All</button>
    <button type=\"button\" data-border=\"top\">Border Top</button>
    <button type=\"button\" data-border=\"right\">Border Right</button>
    <button type=\"button\" data-border=\"bottom\">Border Bottom</button>
    <button type=\"button\" data-border=\"left\">Border Left</button>
    <button type=\"button\" data-border=\"clear\">Clear Border</button>
  </div>
  <p class=\"small\">Border actions apply to the selected table cell when inside a table, otherwise to the selected block element.</p>
  <div class=\"editor-stage\">
    <div class=\"editor-canvas\" id=\"editorCanvas\">
      <iframe id=\"visualEditorFrame\" class=\"editor-frame\"></iframe>
    </div>
  </div>
  <p class=\"editor-caption\">Canvas view emulates a document page for cleaner editing (Acrobat-style).</p>
  <form method=\"post\" action=\"/audit_report/revision/{revision.id}/save/freeform\">
    <input type=\"hidden\" name=\"csrf_token\" value=\"{html_lib.escape(csrf)}\" />
    <input type=\"hidden\" id=\"visualHtmlPayload\" name=\"html_content\" value=\"\" />
    <input type=\"hidden\" id=\"visualSaveMode\" name=\"save_mode\" value=\"session\" />
    <br/><br/>
    <button class=\"btn\" type=\"button\" id=\"saveVisualBtn\" data-save-mode=\"session\">Save Changes</button>
    <button class=\"btn btn-secondary\" type=\"button\" id=\"saveVisualNewBtn\" data-save-mode=\"new\">Save as New Revision</button>
  </form>
</div>
<script>
  (function () {{
    const initialHtml = {initial_html_js};
    const iframe = document.getElementById('visualEditorFrame');
    const editorCanvas = document.getElementById('editorCanvas');
    const payload = document.getElementById('visualHtmlPayload');
    const saveBtn = document.getElementById('saveVisualBtn');
    const saveNewBtn = document.getElementById('saveVisualNewBtn');
    const saveModeInput = document.getElementById('visualSaveMode');
    const resetBtn = document.getElementById('resetBtn');
    const undoBtn = document.getElementById('undoBtn');
    const redoBtn = document.getElementById('redoBtn');
    const commandButtons = Array.from(document.querySelectorAll('.visual-toolbar button[data-cmd]'));
    const borderButtons = Array.from(document.querySelectorAll('.visual-toolbar button[data-border]'));
    const zoomInput = document.getElementById('editorZoom');
    const borderWidthInput = document.getElementById('borderWidthInput');
    const borderStyleInput = document.getElementById('borderStyleInput');
    const borderColorInput = document.getElementById('borderColorInput');

    function loadEditorContent() {{
      iframe.srcdoc = initialHtml || '<!doctype html><html><head><meta charset=\"utf-8\"></head><body></body></html>';
    }}

    function applyCanvasZoom() {{
      if (!editorCanvas || !zoomInput) {{
        return;
      }}
      const zoomPct = parseInt(zoomInput.value || '100', 10);
      const scale = Math.max(40, Math.min(200, zoomPct)) / 100;
      editorCanvas.style.transform = 'scale(' + scale + ')';
    }}

    function focusEditor() {{
      if (iframe.contentWindow) {{
        iframe.contentWindow.focus();
      }}
    }}

    function normalizeAuditBullets(doc) {{
      if (!doc || !doc.body) {{
        return;
      }}
      const lists = Array.from(doc.body.querySelectorAll('ul'));
      lists.forEach(function (list) {{
        if (!list.classList.contains('audit-bullets')) {{
          list.classList.add('audit-bullets');
        }}
        if (!list.classList.contains('tight')) {{
          list.classList.add('tight');
        }}
      }});
    }}

    let frameResizeObserver = null;

    function resizeEditorFrame() {{
      const doc = iframe.contentDocument;
      if (!doc || !doc.documentElement) {{
        return;
      }}
      const body = doc.body;
      const html = doc.documentElement;
      const contentHeight = Math.max(
        body ? body.scrollHeight : 0,
        body ? body.offsetHeight : 0,
        html.scrollHeight || 0,
        html.offsetHeight || 0,
        1280
      );
      iframe.style.height = (contentHeight + 12) + 'px';
    }}

    iframe.addEventListener('load', function () {{
      const doc = iframe.contentDocument;
      if (!doc) {{
        return;
      }}
      try {{
        doc.designMode = 'on';
      }} catch (e) {{
        // Fallback if designMode is restricted.
      }}
      if (doc.body) {{
        doc.body.setAttribute('contenteditable', 'true');
      }}
      if (doc.documentElement) {{
        doc.documentElement.style.overflowY = 'hidden';
      }}
      if (doc.body) {{
        doc.body.style.overflowY = 'hidden';
      }}
      normalizeAuditBullets(doc);

      const triggerResize = function () {{
        if (window.requestAnimationFrame) {{
          window.requestAnimationFrame(resizeEditorFrame);
        }} else {{
          resizeEditorFrame();
        }}
      }};

      if (frameResizeObserver) {{
        frameResizeObserver.disconnect();
      }}
      if (window.MutationObserver && doc.body) {{
        frameResizeObserver = new MutationObserver(triggerResize);
        frameResizeObserver.observe(doc.body, {{
          subtree: true,
          childList: true,
          characterData: true,
          attributes: true,
        }});
      }}

      doc.addEventListener('input', triggerResize, true);
      doc.addEventListener('keyup', triggerResize, true);
      triggerResize();
    }});

    commandButtons.forEach(function (button) {{
      button.addEventListener('click', function () {{
        const cmd = button.getAttribute('data-cmd');
        const doc = iframe.contentDocument;
        if (!doc) {{
          return;
        }}
        focusEditor();
        doc.execCommand(cmd, false, null);
        if (cmd === 'insertUnorderedList') {{
          normalizeAuditBullets(doc);
        }}
      }});
    }});

    function getSelectionElement(doc) {{
      const selection = doc.getSelection ? doc.getSelection() : null;
      if (selection && selection.rangeCount > 0) {{
        let node = selection.anchorNode || selection.getRangeAt(0).startContainer;
        if (node && node.nodeType === 3) {{
          node = node.parentElement;
        }}
        if (node && node.nodeType === 1) {{
          return node;
        }}
      }}
      if (doc.activeElement && doc.activeElement !== doc.body) {{
        return doc.activeElement;
      }}
      return doc.body;
    }}

    function resolveBorderTarget(element, doc) {{
      if (!element) {{
        return null;
      }}
      if (element.closest) {{
        const cell = element.closest('td, th');
        if (cell) {{
          return cell;
        }}
        const block = element.closest('p, div, section, table, tr, li, h1, h2, h3, h4, h5, h6');
        if (block && block !== doc.body) {{
          return block;
        }}
      }}
      return element === doc.body ? null : element;
    }}

    function buildBorderValue() {{
      const width = (borderWidthInput && borderWidthInput.value) || '1px';
      const style = (borderStyleInput && borderStyleInput.value) || 'solid';
      const color = (borderColorInput && borderColorInput.value) || '#000000';
      return width + ' ' + style + ' ' + color;
    }}

    function applyBorder(side) {{
      const doc = iframe.contentDocument;
      if (!doc) {{
        return;
      }}
      focusEditor();
      const selectedElement = getSelectionElement(doc);
      const target = resolveBorderTarget(selectedElement, doc);
      if (!target) {{
        alert('Place the cursor inside the element you want to style.');
        return;
      }}

      if (side === 'clear') {{
        target.style.border = '';
        target.style.borderTop = '';
        target.style.borderRight = '';
        target.style.borderBottom = '';
        target.style.borderLeft = '';
        return;
      }}

      const borderValue = buildBorderValue();
      if (side === 'all') {{
        target.style.border = borderValue;
        return;
      }}
      if (side === 'top') {{
        target.style.borderTop = borderValue;
        return;
      }}
      if (side === 'right') {{
        target.style.borderRight = borderValue;
        return;
      }}
      if (side === 'bottom') {{
        target.style.borderBottom = borderValue;
        return;
      }}
      if (side === 'left') {{
        target.style.borderLeft = borderValue;
      }}
    }}

    borderButtons.forEach(function (button) {{
      button.addEventListener('click', function () {{
        const side = button.getAttribute('data-border');
        if (!side) {{
          return;
        }}
        applyBorder(side);
      }});
    }});

    undoBtn.addEventListener('click', function () {{
      const doc = iframe.contentDocument;
      if (doc) {{
        focusEditor();
        doc.execCommand('undo', false, null);
      }}
    }});

    redoBtn.addEventListener('click', function () {{
      const doc = iframe.contentDocument;
      if (doc) {{
        focusEditor();
        doc.execCommand('redo', false, null);
      }}
    }});

    resetBtn.addEventListener('click', function () {{
      if (confirm('Reset editor to the revision start state? Unsaved changes will be lost.')) {{
        loadEditorContent();
      }}
    }});

    function submitEditor(saveMode) {{
      const doc = iframe.contentDocument;
      if (!doc || !doc.documentElement) {{
        alert('Editor is not ready yet. Please wait a second and try again.');
        return;
      }}
      normalizeAuditBullets(doc);
      payload.value = '<!doctype html>\\n' + doc.documentElement.outerHTML;
      saveModeInput.value = saveMode || 'session';
      saveBtn.form.submit();
    }}

    saveBtn.addEventListener('click', function () {{
      submitEditor(saveBtn.getAttribute('data-save-mode'));
    }});

    saveNewBtn.addEventListener('click', function () {{
      submitEditor(saveNewBtn.getAttribute('data-save-mode'));
    }});

    if (zoomInput) {{
      zoomInput.addEventListener('change', applyCanvasZoom);
      applyCanvasZoom();
    }}

    loadEditorContent();
  }})();
</script>
"""
        return self._render_editor_shell('Visual Layout Editor', body)

    @http.route('/audit_report/revision/<int:revision_id>/preview', type='http', auth='user')
    def view_revision_preview(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()
        try:
            html_content = revision._build_render_ready_html(refresh_toc=True)
        except ValidationError as e:
            summary, issues = self._extract_error_summary_and_issues(
                e,
                'Unable to render preview for this revision.',
            )
            return self._render_editor_error_response(
                'Preview Unavailable',
                summary,
                issues,
                back_url=f'/web#id={revision.id}&model=audit.report.revision&view_type=form',
                status=400,
            )
        except Exception as e:
            _logger.exception("Saved revision preview generation failed: %s", e)
            summary, issues = self._extract_error_summary_and_issues(
                e,
                'Unable to render preview for this revision.',
            )
            return self._render_editor_error_response(
                'Preview Unavailable',
                summary,
                issues,
                back_url=f'/web#id={revision.id}&model=audit.report.revision&view_type=form',
                status=500,
            )

        return request.make_response(
            html_content,
            headers=[
                ('Content-Type', 'text/html; charset=utf-8'),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ],
        )

    @http.route('/audit_report/revision/<int:revision_id>/pdf', type='http', auth='user')
    def view_revision_pdf(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()

        try:
            pdf_content = revision._get_pdf_content()
        except ValidationError as e:
            summary, issues = self._extract_error_summary_and_issues(
                e,
                'Unable to generate PDF for this revision.',
            )
            return self._render_editor_error_response(
                'Revision PDF Error',
                summary,
                issues,
                back_url=f'/web#id={revision.id}&model=audit.report.revision&view_type=form',
                status=400,
            )
        except Exception as e:
            _logger.exception("Saved revision PDF generation failed: %s", e)
            summary, issues = self._extract_error_summary_and_issues(
                e,
                'Unable to generate PDF for this revision.',
            )
            return self._render_editor_error_response(
                'Revision PDF Error',
                summary,
                issues,
                back_url=f'/web#id={revision.id}&model=audit.report.revision&view_type=form',
                status=500,
            )

        filename = f'Audit_Report_{revision.document_id.id}_v{revision.version_no}.pdf'
        return request.make_response(
            pdf_content,
            headers=[
                ('Content-Type', 'application/pdf'),
                ('Content-Disposition', f'inline; filename=\"{filename}\"'),
                ('Content-Length', str(len(pdf_content))),
                ('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'),
                ('Pragma', 'no-cache'),
                ('Expires', '0'),
            ],
        )

    @http.route('/audit_report/revision/<int:revision_id>/tables', type='http', auth='user')
    def list_revision_tables(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=True)
        if not revision:
            return request.not_found()
        payload = {
            'revision_id': revision.id,
            'version_no': revision.version_no,
            'company_id': revision.company_id.id,
            'tables': revision.get_table_index(),
        }
        return request.make_response(
            json.dumps(payload),
            headers=[('Content-Type', 'application/json; charset=utf-8')],
        )

    @http.route('/audit_report/revision/<int:revision_id>/edit/structured', type='http', auth='user')
    def edit_revision_structured(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()
        selected_table_key = kwargs.get('table_key')
        saved_state = str(kwargs.get('saved') or '').strip().lower()
        if saved_state in ('1', 'true', 'yes'):
            saved_state = 'new'
        page = self._render_structured_editor_page(
            revision,
            selected_table_key=selected_table_key,
            saved_state=saved_state,
        )
        return request.make_response(
            page,
            headers=[('Content-Type', 'text/html; charset=utf-8')],
        )

    @http.route(
        '/audit_report/revision/<int:revision_id>/save/structured',
        type='http',
        auth='user',
        methods=['POST'],
    )
    def save_revision_structured(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()

        table_key = kwargs.get('table_key') or ''
        table_action = kwargs.get('table_action') or 'save'
        save_mode = (kwargs.get('save_mode') or 'session').strip().lower()
        force_new_revision = save_mode == 'new'
        target_row = kwargs.get('target_row') or 0
        target_col = kwargs.get('target_col') or 0
        row_order = kwargs.get('row_order') or ''
        posted_cells = {
            key: value
            for key, value in kwargs.items()
            if key.startswith('cell_')
        }
        back_url = f'/audit_report/revision/{revision.id}/edit/structured'
        if table_key:
            back_url += f'?table_key={quote_plus(table_key)}'

        try:
            html_content = revision.apply_structured_table_changes(
                table_key,
                posted_cells,
                table_action=table_action,
                target_row=target_row,
                target_col=target_col,
                row_order=row_order,
            )
            prepared_html = revision.prepare_edited_html_for_storage(html_content)
            target_revision, save_state = self._persist_revision_edit(
                revision,
                prepared_html,
                force_new_revision=force_new_revision,
            )
        except ValidationError as e:
            _logger.warning("Structured table save blocked: %s", e)
            summary, issues = self._extract_error_summary_and_issues(
                e,
                'Could not save structured changes.',
            )
            return self._render_editor_error_response(
                'Structured Save Failed',
                summary,
                issues,
                back_url=back_url,
                status=400,
            )
        except Exception as e:
            _logger.exception("Structured table save failed: %s", e)
            summary, issues = self._extract_error_summary_and_issues(
                e,
                'Unexpected error while saving structured changes.',
            )
            return self._render_editor_error_response(
                'Structured Save Failed',
                summary,
                issues,
                back_url=back_url,
                status=500,
            )

        url = f'/audit_report/revision/{target_revision.id}/edit/structured?saved={save_state}'
        if table_key:
            url += f'&table_key={quote_plus(table_key)}'
        return request.redirect(url)

    @http.route('/audit_report/revision/<int:revision_id>/edit/freeform', type='http', auth='user')
    def edit_revision_freeform(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()

        saved_state = str(kwargs.get('saved') or '').strip().lower()
        if saved_state in ('1', 'true', 'yes'):
            saved_state = 'new'
        page = self._render_freeform_editor_page(revision, saved_state=saved_state)
        return request.make_response(
            page,
            headers=[('Content-Type', 'text/html; charset=utf-8')],
        )

    @http.route(
        '/audit_report/revision/<int:revision_id>/save/freeform',
        type='http',
        auth='user',
        methods=['POST'],
    )
    def save_revision_freeform(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=False)
        if not revision:
            return request.not_found()

        html_content = kwargs.get('html_content') or ''
        save_mode = (kwargs.get('save_mode') or 'session').strip().lower()
        force_new_revision = save_mode == 'new'
        back_url = f'/audit_report/revision/{revision.id}/edit/freeform'
        if not html_content.strip():
            return self._render_editor_error_response(
                'Freeform Save Failed',
                'Freeform HTML cannot be empty.',
                back_url=back_url,
                status=400,
            )
        try:
            prepared_html = revision.prepare_edited_html_for_storage(html_content)
            target_revision, save_state = self._persist_revision_edit(
                revision,
                prepared_html,
                force_new_revision=force_new_revision,
            )
        except ValidationError as e:
            _logger.warning("Freeform save blocked: %s", e)
            summary, issues = self._extract_error_summary_and_issues(
                e,
                'Could not save freeform changes.',
            )
            return self._render_editor_error_response(
                'Freeform Save Failed',
                summary,
                issues,
                back_url=back_url,
                status=400,
            )
        except Exception as e:
            _logger.exception("Freeform save failed: %s", e)
            summary, issues = self._extract_error_summary_and_issues(
                e,
                'Unexpected error while saving freeform changes.',
            )
            return self._render_editor_error_response(
                'Freeform Save Failed',
                summary,
                issues,
                back_url=back_url,
                status=500,
            )

        return request.redirect(f'/audit_report/revision/{target_revision.id}/edit/freeform?saved={save_state}')

    @http.route(
        '/audit_report/revision/<int:revision_id>/remove',
        type='http',
        auth='user',
        methods=['POST'],
    )
    def remove_revision(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=True)
        if not revision:
            return request.not_found()
        revision.action_soft_remove()
        next_url = kwargs.get('next') or (
            f'/web#id={revision.document_id.id}&model=audit.report.document&view_type=form'
        )
        return request.redirect(next_url)

    @http.route(
        '/audit_report/revision/<int:revision_id>/restore',
        type='http',
        auth='user',
        methods=['POST'],
    )
    def restore_revision(self, revision_id, **kwargs):
        revision = self._load_revision(revision_id, include_removed=True)
        if not revision:
            return request.not_found()
        revision.action_restore()
        next_url = kwargs.get('next') or (
            f'/web#id={revision.id}&model=audit.report.revision&view_type=form'
        )
        return request.redirect(next_url)

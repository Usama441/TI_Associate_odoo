from collections import defaultdict

from odoo import _, Command, api, fields, models
from odoo.exceptions import UserError


class AccountBankRecodeWizard(models.TransientModel):
    _name = 'account.bank.recode.wizard'
    _description = 'Bank Transaction Recode Wizard'

    statement_line_ids = fields.Many2many(
        'account.bank.statement.line',
        string='Transactions',
        readonly=True,
    )
    line_ids = fields.One2many(
        'account.bank.recode.wizard.line',
        'wizard_id',
        string='Counterpart Lines',
    )
    target_account_id = fields.Many2one(
        'account.account',
        string='Target Account',
        domain="[('active', '=', True), ('company_ids', 'parent_of', company_id)]",
    )
    mode = fields.Selection(
        [
            ('all', 'Recode All'),
            ('per_line', 'Per Line'),
        ],
        string='Mode',
        default='all',
        required=True,
    )
    line_count = fields.Integer(
        string='Selected Transactions',
        compute='_compute_line_count',
    )
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        readonly=True,
        default=lambda self: self.env.company,
    )

    @api.depends('statement_line_ids')
    def _compute_line_count(self):
        for wizard in self:
            wizard.line_count = len(wizard.statement_line_ids)

    @api.model
    def _prepare_wizard_line_commands(self, statement_lines):
        commands = []
        for statement_line in statement_lines:
            _liquidity_lines, _suspense_lines, other_lines = statement_line._seek_for_lines()
            for move_line in other_lines:
                commands.append(Command.create({
                    'statement_line_id': statement_line.id,
                    'move_line_id': move_line.id,
                }))
        return commands

    @api.model
    def default_get(self, fields_list):
        defaults = super().default_get(fields_list)
        active_ids = self.env.context.get('active_ids') or []
        active_model = self.env.context.get('active_model')

        if active_model != 'account.bank.statement.line' or not active_ids:
            return defaults

        statement_lines = self.env['account.bank.statement.line'].browse(active_ids).exists()
        if not statement_lines:
            return defaults
        if len(statement_lines.company_id) > 1:
            raise UserError(_('Please select transactions from a single company.'))

        defaults['company_id'] = statement_lines.company_id.id
        defaults['statement_line_ids'] = [Command.set(statement_lines.ids)]
        return defaults

    @api.onchange('mode')
    def _onchange_mode(self):
        for wizard in self:
            if wizard.mode == 'per_line':
                if not wizard.line_ids:
                    wizard.line_ids = wizard._prepare_wizard_line_commands(wizard.statement_line_ids)
            else:
                wizard.line_ids = [Command.clear()]

    def action_recode(self):
        self.ensure_one()

        if not self.statement_line_ids:
            raise UserError(_('No transactions were selected.'))
        if len(self.statement_line_ids.company_id) > 1:
            raise UserError(_('Please select transactions from a single company.'))
        if self.statement_line_ids.filtered(lambda line: not line.is_reconciled):
            raise UserError(_('Only reconciled transactions can be recoded.'))
        line_changes = []
        if self.mode == 'all':
            if not self.target_account_id:
                raise UserError(_('Select a target account before recoding.'))
            for statement_line in self.statement_line_ids:
                _liquidity_lines, _suspense_lines, other_lines = statement_line._seek_for_lines()
                for move_line in other_lines:
                    if move_line.account_id == self.target_account_id:
                        continue
                    line_changes.append({
                        'statement_line': statement_line,
                        'move_line': move_line,
                        'old_account': move_line.account_id,
                        'new_account': self.target_account_id,
                        'label': move_line.name or statement_line.display_name,
                    })
        else:
            valid_wizard_lines = self.line_ids.filtered(lambda line: line.statement_line_id and line.move_line_id)
            if not valid_wizard_lines:
                raise UserError(_('No counterpart journal items were found for the selected transactions.'))
            missing_targets = valid_wizard_lines.filtered(lambda line: not line.new_account_id)
            if missing_targets:
                raise UserError(_('Set a new account on every line before recoding.'))
            for wizard_line in valid_wizard_lines:
                if wizard_line.new_account_id == wizard_line.current_account_id:
                    continue
                line_changes.append({
                    'statement_line': wizard_line.statement_line_id,
                    'move_line': wizard_line.move_line_id,
                    'old_account': wizard_line.current_account_id,
                    'new_account': wizard_line.new_account_id,
                    'label': wizard_line.label or wizard_line.statement_line_id.display_name,
                })

        if not line_changes:
            raise UserError(_('Nothing to recode. The selected accounts are already set.'))

        changes_by_statement_line = defaultdict(list)
        moves = self.env['account.move']
        for change in line_changes:
            moves |= change['move_line'].move_id
            changes_by_statement_line[change['statement_line'].id].append({
                'label': change['label'],
                'old_account': change['old_account'].display_name,
                'new_account': change['new_account'].display_name,
            })

        posted_moves = moves.filtered(lambda move: move.state == 'posted')
        if posted_moves:
            posted_moves.button_draft()

        for change in line_changes:
            change['move_line'].with_context(skip_readonly_check=True).write({
                'account_id': change['new_account'].id,
            })

        if posted_moves:
            posted_moves.action_post()

        timestamp = fields.Datetime.to_string(fields.Datetime.context_timestamp(self, fields.Datetime.now()))
        statement_lines = self.env['account.bank.statement.line'].browse(list(changes_by_statement_line.keys()))
        for statement_line in statement_lines:
            changes = changes_by_statement_line[statement_line.id]
            changes_text = '\n'.join(
                _('%(label)s: %(old)s -> %(new)s',
                  label=change['label'],
                  old=change['old_account'],
                  new=change['new_account'])
                for change in changes
            )
            statement_line.message_post(body=_(
                'Recoded by %(user)s on %(date)s\n%(changes)s',
                user=self.env.user.display_name,
                date=timestamp,
                changes=changes_text,
            ))

        return {'type': 'ir.actions.act_window_close'}


class AccountBankRecodeWizardLine(models.TransientModel):
    _name = 'account.bank.recode.wizard.line'
    _description = 'Bank Transaction Recode Wizard Line'

    wizard_id = fields.Many2one(
        'account.bank.recode.wizard',
        required=True,
        ondelete='cascade',
    )
    company_id = fields.Many2one(
        'res.company',
        related='wizard_id.company_id',
        store=False,
        readonly=True,
    )
    statement_line_id = fields.Many2one(
        'account.bank.statement.line',
        string='Transaction',
        required=True,
        readonly=True,
    )
    move_line_id = fields.Many2one(
        'account.move.line',
        string='Journal Item',
        required=True,
        readonly=True,
    )
    date = fields.Date(
        related='statement_line_id.date',
        store=False,
        readonly=True,
    )
    label = fields.Char(
        related='move_line_id.name',
        store=False,
        readonly=True,
    )
    current_account_id = fields.Many2one(
        'account.account',
        string='Current Account',
        related='move_line_id.account_id',
        store=False,
        readonly=True,
    )
    company_currency_id = fields.Many2one(
        'res.currency',
        related='move_line_id.company_currency_id',
        store=False,
        readonly=True,
    )
    amount = fields.Monetary(
        related='move_line_id.balance',
        currency_field='company_currency_id',
        store=False,
        readonly=True,
    )
    new_account_id = fields.Many2one(
        'account.account',
        string='New Account',
        domain="[('active', '=', True), ('company_ids', 'parent_of', company_id)]",
    )

import json
from unittest.mock import patch

from odoo import fields
from odoo.tests import TransactionCase, tagged

from odoo.addons.Audit_Report.controllers.main import AuditReportController


@tagged('post_install', '-at_install')
class TestAuditReportRevisionSnapshot(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company = cls.env.company
        cls.AuditReportModel = type(cls.env['audit.report'])

    def _make_snapshot(self, **overrides):
        snapshot = {
            'company_id': self.company.id,
            'date_start': '2024-01-01',
            'date_end': '2024-12-31',
            'balance_sheet_date_mode': 'end_only',
            'prior_year_mode': 'auto',
            'prior_balance_sheet_date_mode': 'end_only',
            'report_type': 'period',
            'audit_period_category': 'normal_1y',
            'auditor_type': 'default',
            'signature_date_mode': 'today',
            'draft_watermark': False,
        }
        snapshot.update(overrides)
        return json.dumps(snapshot)

    def _create_document_with_revision(self, snapshot_json, html_content='<html><body><p>Base</p></body></html>'):
        document = self.env['audit.report.document'].create({
            'name': 'Snapshot Test Report',
            'company_id': self.company.id,
            'date_start': fields.Date.to_date('2024-01-01'),
            'date_end': fields.Date.to_date('2024-12-31'),
            'report_type': 'period',
            'audit_period_category': 'normal_1y',
            'source_wizard_json': snapshot_json,
        })
        revision = document.create_revision_from_html(html_content)
        return document, revision

    def _wizard_values(self, **overrides):
        values = {
            'company_id': self.company.id,
            'date_start': fields.Date.to_date('2024-01-01'),
            'date_end': fields.Date.to_date('2024-12-31'),
            'balance_sheet_date_mode': 'end_only',
            'prior_year_mode': 'auto',
            'prior_balance_sheet_date_mode': 'end_only',
            'report_type': 'period',
            'audit_period_category': 'normal_2y',
            'auditor_type': 'default',
            'signature_date_mode': 'today',
            'use_previous_settings': False,
        }
        values.update(overrides)
        return values

    def _create_wizard(self, **overrides):
        return self.env['audit.report'].create(self._wizard_values(**overrides))

    def test_reporting_periods_fallbacks_missing_soce_date(self):
        wizard = self._create_wizard(soce_prior_opening_label_date=False)

        periods = wizard._get_reporting_periods()

        self.assertEqual(
            periods['soce_prior_opening_label_date'],
            fields.Date.to_date('2023-01-01'),
        )
        self.assertTrue(wizard.soce_warning_message)
        self.assertIn('fallback', wizard.soce_warning_message.lower())

    def test_revision_wizard_uses_revision_snapshot_over_document_snapshot(self):
        initial_snapshot = self._make_snapshot(draft_watermark=False, signature_date_mode='today')
        updated_snapshot = self._make_snapshot(
            draft_watermark=True,
            signature_date_mode='manual',
            signature_manual_date='2024-12-31',
        )
        document, first_revision = self._create_document_with_revision(initial_snapshot)
        second_revision = document.create_revision_from_html(
            '<html><body><p>Second</p></body></html>',
            parent_revision=first_revision,
            wizard_snapshot_json=updated_snapshot,
        )

        with patch.object(self.AuditReportModel, '_load_tb_override_lines', lambda *args, **kwargs: None), \
                patch.object(self.AuditReportModel, '_apply_tb_overrides_from_serialized_payload', lambda *args, **kwargs: None), \
                patch.object(self.AuditReportModel, '_sync_tb_overrides_json', lambda *args, **kwargs: ''), \
                patch.object(self.AuditReportModel, '_apply_lor_extra_items_from_serialized_payload', lambda *args, **kwargs: None), \
                patch.object(self.AuditReportModel, '_get_report_data', lambda *args, **kwargs: {}):
            wizard = second_revision._build_audit_report_wizard_from_snapshot()

        self.assertEqual(document.source_wizard_json, initial_snapshot)
        self.assertEqual(first_revision.wizard_snapshot_json, initial_snapshot)
        self.assertEqual(second_revision.wizard_snapshot_json, updated_snapshot)
        self.assertTrue(wizard.draft_watermark)
        self.assertEqual(wizard.signature_date_mode, 'manual')
        self.assertEqual(wizard.signature_manual_date, fields.Date.to_date('2024-12-31'))

    def test_lor_apply_rerenders_revision_and_persists_snapshot(self):
        initial_snapshot = self._make_snapshot(draft_watermark=False, signature_date_mode='today')
        document, revision = self._create_document_with_revision(initial_snapshot)
        wizard = self.env['audit.report'].with_context(audit_target_revision_id=revision.id).create(
            self._wizard_values(
                audit_period_category='normal_1y',
                signature_date_mode='manual',
                signature_manual_date=fields.Date.to_date('2024-12-31'),
                draft_watermark=True,
                audit_target_revision_id=revision.id,
                audit_target_document_id=document.id,
            )
        )

        rendered_html = '<html><body><p>Updated company details</p></body></html>'
        with patch.object(self.AuditReportModel, '_validate_emphasis_options', lambda *args, **kwargs: None), \
                patch.object(self.AuditReportModel, '_get_report_data', lambda *args, **kwargs: {}), \
                patch.object(self.AuditReportModel, '_sync_tb_overrides_json', lambda *args, **kwargs: '{"rows": []}'), \
                patch.object(self.AuditReportModel, '_sync_lor_extra_items_json', lambda *args, **kwargs: '[{"item_text": "Updated"}]'), \
                patch.object(AuditReportController, '_templates_path', lambda *args, **kwargs: '/tmp'), \
                patch.object(AuditReportController, '_css_path', lambda *args, **kwargs: '/tmp/audit.css'), \
                patch.object(AuditReportController, '_get_template_env', lambda *args, **kwargs: object()), \
                patch.object(AuditReportController, '_get_cached_css_content', lambda *args, **kwargs: 'body{}'), \
                patch.object(AuditReportController, '_compute_toc_entries', lambda *args, **kwargs: None), \
                patch.object(AuditReportController, '_render_report_html', lambda *args, **kwargs: rendered_html):
            expected_snapshot = wizard._get_wizard_snapshot_json()
            action = wizard.action_apply_lor_overrides_to_revision()

        new_revision = self.env['audit.report.revision'].browse(action['res_id'])
        self.assertNotEqual(new_revision.id, revision.id)
        self.assertEqual(new_revision.parent_revision_id, revision)
        self.assertIn('Updated company details', new_revision.html_content)
        self.assertEqual(new_revision.wizard_snapshot_json, expected_snapshot)
